@echo off
setlocal
cd /d "%~dp0"
if not defined PORT set "PORT=3000"

echo.
echo ==========================================
echo    SmartJournal - Windows Local
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 goto :node_missing
for /f "delims=" %%v in ('node -v') do set "NODEV=%%v"
for /f "delims=" %%v in ('node -p "process.versions.node.split('.')[0]"') do set "NODEMAJOR=%%v"
if %NODEMAJOR% LSS 20 goto :node_old
echo [OK] Node %NODEV%

where npm >nul 2>nul
if errorlevel 1 goto :npm_missing

if exist "node_modules\express\package.json" goto :dependencies_ready
echo.
echo Installing dependencies for the first time. This may take a few minutes.
echo Internet access is needed for this first installation.
echo.
call npm ci --omit=dev --no-audit --no-fund
if errorlevel 1 goto :install_failed

:dependencies_ready
echo [OK] Dependencies ready.
echo.
echo Starting the local server...
start "SmartJournal server - do not close" cmd /k "set NODE_ENV=development&&set HOST=127.0.0.1&&set LOCAL_NO_PHONE=true&&set SEED_DEMO_DATA=false&&set PORT=%PORT%&&npm start"
echo Waiting for http://localhost:%PORT% ...
node scripts\wait-local-mode.js
if errorlevel 1 goto :server_failed

echo.
echo [OK] Server is running.
echo Site:    http://localhost:%PORT%
echo Journal: http://localhost:%PORT%/journal
echo Local accounts need no phone number or SMS.
echo Keep the server window open while using the site.
start "" "http://localhost:%PORT%"
pause
exit /b 0

:node_missing
echo [ERROR] Node.js is not installed.
echo Install Node.js 22 LTS from https://nodejs.org, then run start.bat again.
pause
exit /b 1

:node_old
echo [ERROR] Node.js 20 or newer is required. Detected: %NODEV%
echo Install Node.js 22 LTS from https://nodejs.org.
pause
exit /b 1

:npm_missing
echo [ERROR] npm was not found. Reinstall Node.js 22 LTS from https://nodejs.org.
pause
exit /b 1

:install_failed
echo.
echo [ERROR] npm could not install the required dependencies.
echo The actual npm error is shown above this message. Please send that error text.
echo If it is a network timeout, try these commands in this folder:
echo   npm config set registry https://registry.npmmirror.com
echo   npm ci --omit=dev --no-audit --no-fund
pause
exit /b 1

:server_failed
echo.
echo [ERROR] The server did not answer at http://localhost:%PORT%.
echo Check the other window titled SmartJournal server for the first error.
pause
exit /b 1
