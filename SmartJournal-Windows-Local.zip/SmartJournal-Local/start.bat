@echo off
REM ===========================================================================
REM  SmartJournal  --  Windows launcher
REM  روی این فایل دوبار کلیک کنید (Double-click this file)
REM ===========================================================================
setlocal enabledelayedexpansion
chcp 65001 >nul 2>nul
cd /d "%~dp0"
if "%PORT%"=="" set "PORT=3000"

echo.
echo ==========================================
echo    SmartJournal
echo ==========================================
echo.

REM ---------- 1) Node.js ----------
where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js is NOT installed.
  echo     Node.js نصب نیست.
  echo.
  echo     1^) https://nodejs.org  ^-^-^>  download LTS
  echo     2^) install it
  echo     3^) CLOSE this window and double-click start.bat again
  echo        ^(بعد از نصب، این پنجره را ببندید و دوباره اجرا کنید^)
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do set "NODEV=%%v"
for /f "delims=" %%v in ('node -p "process.versions.node.split('.')[0]"') do set "NODEMAJOR=%%v"
if !NODEMAJOR! LSS 20 (
  echo [X] Node.js 20 or newer is required. Current version: !NODEV!
  echo     لطفاً نسخه LTS 20 یا جدیدتر Node.js را نصب کنید.
  pause
  exit /b 1
)
echo [OK] Node !NODEV!

REM ---------- 2) dependencies ----------
if not exist "node_modules\express\package.json" (
  echo.
  echo Installing runtime dependencies - first run only, may take a few minutes.
  echo نصب وابستگی‌های لازم - فقط بار اول - چند دقیقه طول می‌کشد. صبر کنید.
  echo.
  call npm ci --omit=dev --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo [X] npm ci FAILED.  /  نصب ناموفق بود.
    echo     If it is a network/timeout error, run these commands:
    echo     اگر خطای شبکه بود، این دستورها را بزنید:
    echo.
    echo        npm config set registry https://registry.npmmirror.com
    echo        npm ci --omit=dev --no-audit --no-fund
    echo.
    pause
    exit /b 1
  )
)
echo [OK] dependencies ready

REM ---------- 3) start the server in its own window ----------
echo.
echo Starting server...  /  در حال اجرای سرور...
start "SmartJournal server - do not close" cmd /k "set NODE_ENV=development&& set HOST=127.0.0.1&& set LOCAL_NO_PHONE=true&& set SEED_DEMO_DATA=false&& set PORT=%PORT%&& npm start"

REM ---------- 4) wait until it really answers ----------
echo Waiting for http://localhost:%PORT% ...
node -e "var n=0;function retry(){n++;if(n===170)process.exit(1);setTimeout(p,700)}function p(){require('http').get({host:'127.0.0.1',port:%PORT%,path:'/local-mode.js'},function(r){var b='';r.setEncoding('utf8');r.on('data',function(c){b+=c});r.on('end',function(){if(r.statusCode===200&&b.indexOf('PA_LOCAL_MODE=true')>=0)process.exit(0);retry()})}).on('error',retry)}p()"
if errorlevel 1 (
  echo.
  echo [X] The server did not answer.
  echo     سرور بالا نیامد.
  echo.
  echo     Look at the other window titled "SmartJournal server"
  echo     and read the RED error text there.
  echo     متن خطا را در پنجره دیگر ببینید و برای من بفرستید.
  echo.
  pause
  exit /b 1
)

REM ---------- 5) open the browser ----------
echo [OK] server is UP
echo.
echo    Site        http://localhost:%PORT%
echo    Journal     http://localhost:%PORT%/journal
echo    Local mode  no phone / no SMS; data stays in this browser
echo.
start "" "http://localhost:%PORT%"
echo Browser opened. If it did not, copy the address above into your browser.
echo اگر مرورگر باز نشد، آدرس بالا را دستی در مرورگر بزنید.
echo.
echo To STOP the site: close the window titled "SmartJournal server".
echo برای توقف سایت: پنجره «SmartJournal server» را ببندید.
echo.
pause
