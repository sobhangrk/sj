'use strict';

/*
 * SmartJournal MT5 Bridge
 *
 * The EA never receives a user password and never gets a trading capability
 * from this API. A short-lived pairing code is exchanged for a scoped,
 * revocable journal-ingestion token. MT5 sends deal history; the server
 * aggregates entry/exit deals by POSITION_ID and materializes one journal
 * trade per closed position.
 */

const crypto = require('crypto');

function install({
  app, db, userCsrf, requireJournalSection, journalWriteGuard,
  id, iso, secureToken, tokenHash, clientIp, logUserActivity,
  bumpJournalVersion, journalAccessForUser, storeJournalImage
}) {
  const attempts = new Map();
  const MAX_BATCH = 80;
  const PAIRING_TTL_MS = 15 * 60 * 1000;
  /* Existing installations may already have the first version of the table. */
  for (const [column, type] of [['scope_symbol', 'TEXT'], ['scope_magic', 'TEXT']]) {
    try { db.prepare(`SELECT ${column} FROM mt5_connections LIMIT 1`).get(); }
    catch {
      try { db.exec(`ALTER TABLE mt5_connections ADD COLUMN ${column} ${type}`); } catch {}
    }
  }
  try {
    db.exec(`CREATE TABLE IF NOT EXISTS mt5_trade_annotations (
      id TEXT PRIMARY KEY,
      connection_id TEXT NOT NULL,
      symbol TEXT NOT NULL,
      annotation_type TEXT NOT NULL,
      position_id TEXT,
      payload_json TEXT NOT NULL,
      captured_at TEXT NOT NULL,
      event_key TEXT NOT NULL UNIQUE,
      received_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_mt5_annotations_lookup
      ON mt5_trade_annotations(connection_id,symbol,annotation_type,captured_at);
    CREATE INDEX IF NOT EXISTS idx_mt5_annotations_position
      ON mt5_trade_annotations(connection_id,position_id,annotation_type,captured_at);`);
  } catch {}

  const clean = (value, max = 200) => String(value == null ? '' : value)
    .replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max);
  const finite = (value, fallback = 0, max = 1e15) => {
    const n = Number(value);
    return Number.isFinite(n) && Math.abs(n) <= max ? n : fallback;
  };
  const validLogin = value => /^[0-9]{3,20}$/.test(clean(value, 20));
  const validSymbol = value => /^[A-Za-z0-9._#-]{1,40}$/.test(clean(value, 40));
  const validId = value => /^[A-Za-z0-9_-]{1,90}$/.test(clean(value, 90));
  const codeNormalize = value => clean(value, 64).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const makePairingCode = () => `SJ-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
  const accountHint = login => {
    const text = clean(login, 20);
    return text.length > 4 ? `••••${text.slice(-4)}` : text;
  };
  const rateLimit = (key, limit, windowMs) => {
    const now = Date.now();
    const current = attempts.get(key);
    if (!current || now >= current.resetAt) {
      attempts.set(key, { count: 1, resetAt: now + windowMs });
      return { ok: true };
    }
    current.count += 1;
    return { ok: current.count <= limit, retryAfter: Math.max(1, Math.ceil((current.resetAt - now) / 1000)) };
  };
  const bearer = req => {
    const header = String(req.get('authorization') || '');
    return /^Bearer\s+\S+$/i.test(header) ? header.replace(/^Bearer\s+/i, '').trim() : '';
  };
  const activeConnection = token => {
    if (!token || token.length < 24 || token.length > 200) return null;
    return db.prepare(`SELECT * FROM mt5_connections
      WHERE token_hash=? AND status='active' LIMIT 1`).get(tokenHash(token));
  };
  const userTradeLimit = userId => {
    const row = db.prepare(`SELECT p.max_trades FROM subscriptions s
      JOIN plans p ON p.id=s.plan_id
      WHERE s.user_id=? ORDER BY CASE s.status WHEN 'active' THEN 0 WHEN 'trial' THEN 1 ELSE 2 END,
      s.started_at DESC LIMIT 1`).get(userId);
    return Number(row?.max_trades || 100);
  };
  const parseEventTime = (event, offsetMinutes) => {
    const seconds = Number(event.deal_time_unix);
    if (Number.isFinite(seconds) && seconds > 0 && seconds < 1e12) {
      const offset = Number.isFinite(Number(offsetMinutes)) ? Number(offsetMinutes) : 0;
      return new Date((seconds - offset * 60) * 1000).toISOString();
    }
    const raw = new Date(String(event.deal_time || ''));
    return Number.isNaN(raw.getTime()) ? null : raw.toISOString();
  };
  const normalizeEvent = (raw, connection, body) => {
    if (!raw || typeof raw !== 'object') return null;
    const dealTicket = clean(raw.deal_ticket ?? raw.ticket, 40);
    if (!dealTicket || !validId(dealTicket)) return null;
    const symbol = clean(raw.symbol, 40).toUpperCase();
    if (!validSymbol(symbol)) return null;
    if (connection.scope_symbol && symbol !== String(connection.scope_symbol).toUpperCase()) return null;
    const type = ['buy', 'sell'].includes(String(raw.type).toLowerCase()) ? String(raw.type).toLowerCase() : null;
    const entry = ['in', 'out', 'inout', 'out_by'].includes(String(raw.entry).toLowerCase()) ? String(raw.entry).toLowerCase() : null;
    const dealTime = parseEventTime(raw, body.server_utc_offset_min);
    if (!type || !entry || !dealTime) return null;
    const orderTicket = clean(raw.order_ticket ?? raw.order, 40);
    const positionId = clean(raw.position_id ?? raw.position, 90) || dealTicket;
    const magic = clean(raw.magic, 40);
    if (connection.scope_magic && magic !== String(connection.scope_magic)) return null;
    return {
      dealTicket,
      orderTicket: validId(orderTicket) ? orderTicket : '',
      positionId: validId(positionId) ? positionId : dealTicket,
      symbol,
      type,
      entry,
      volume: Math.max(0, finite(raw.volume)),
      price: Math.max(0, finite(raw.price)),
      profit: finite(raw.profit),
      commission: finite(raw.commission),
      swap: finite(raw.swap),
      fee: finite(raw.fee),
      magic,
      comment: clean(raw.comment, 160),
      dealTime,
      serverTime: clean(raw.deal_time_text || raw.server_time, 40),
      serverOffsetMinutes: finite(body.server_utc_offset_min),
      symbolPeriod: clean(raw.period, 20),
      eaVersion: clean(body.ea_version, 40),
      raw
    };
  };
  const normalizeMindset = (raw, connection, body) => {
    if (raw == null || raw === '') return null;
    let value = raw;
    if (typeof value === 'string') {
      try { value = JSON.parse(value); } catch { return null; }
    }
    if (!value || typeof value !== 'object') return null;
    const score = Math.round(finite(value.score, -1, 100));
    if (score < 0 || score > 100) return null;
    const symbol = clean(value.symbol || connection.scope_symbol, 40).toUpperCase();
    if (!validSymbol(symbol) || (connection.scope_symbol && symbol !== String(connection.scope_symbol).toUpperCase())) return null;
    const answers = Array.isArray(value.answers) ? value.answers.slice(0, 12).map(item => Math.max(-1, Math.min(1, Math.round(Number(item) || 0)))) : [];
    const capturedAt = parseEventTime({ deal_time_unix: value.captured_unix, deal_time: value.captured_at }, body.server_utc_offset_min);
    if (!capturedAt) return null;
    const answersJson = JSON.stringify(answers);
    const eventKey = tokenHash(`${connection.id}|${capturedAt}|${score}|${answersJson}`);
    return { score, symbol, answersJson, gateEnabled: value.gate_enabled ? 1 : 0, capturedAt, eventKey };
  };

  const parseJsonObject = raw => {
    if (raw == null || raw === '') return null;
    if (typeof raw === 'string') {
      try { raw = JSON.parse(raw); } catch { return null; }
    }
    return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : null;
  };
  const normalizeTradePlan = (raw, connection, body) => {
    const value = parseJsonObject(raw);
    if (!value) return null;
    const symbol = clean(value.symbol || connection.scope_symbol, 40).toUpperCase();
    if (!validSymbol(symbol) || (connection.scope_symbol && symbol !== String(connection.scope_symbol).toUpperCase())) return null;
    const capturedAt = parseEventTime({ deal_time_unix: value.captured_unix, deal_time: value.captured_at }, body.server_utc_offset_min);
    if (!capturedAt) return null;
    const payload = {
      symbol,
      setupName: clean(value.setup_name || value.setupName, 120),
      riskPercent: Math.max(0, Math.min(100, finite(value.risk_percent ?? value.riskPercent))),
      plannedRR: Math.max(0, Math.min(100, finite(value.planned_rr ?? value.plannedRR))),
      note: clean(value.note, 800)
    };
    const eventKey = tokenHash(`${connection.id}|plan|${symbol}|${capturedAt}|${JSON.stringify(payload)}`);
    return { type: 'plan', symbol, positionId: '', payload, capturedAt, eventKey };
  };
  const normalizeTradeReview = (raw, connection, body) => {
    const value = parseJsonObject(raw);
    if (!value) return null;
    const symbol = clean(value.symbol || connection.scope_symbol, 40).toUpperCase();
    const positionId = clean(value.position_id || value.positionId, 90);
    if (!validSymbol(symbol) || !validId(positionId)
        || (connection.scope_symbol && symbol !== String(connection.scope_symbol).toUpperCase())) return null;
    const capturedAt = parseEventTime({ deal_time_unix: value.captured_unix, deal_time: value.captured_at }, body.server_utc_offset_min);
    if (!capturedAt) return null;
    const payload = {
      symbol,
      positionId,
      onPlan: value.on_plan === true || value.onPlan === true || String(value.on_plan) === 'true',
      mistake: clean(value.mistake, 800),
      emotionAfter: clean(value.emotion_after || value.emotionAfter, 80)
    };
    const eventKey = tokenHash(`${connection.id}|review|${symbol}|${positionId}|${capturedAt}|${JSON.stringify(payload)}`);
    return { type: 'review', symbol, positionId, payload, capturedAt, eventKey };
  };

  const positionTrade = (connection, positionId) => {
    const events = db.prepare(`SELECT * FROM mt5_deals
      WHERE connection_id=? AND position_id=? ORDER BY deal_time,deal_ticket`).all(connection.id, positionId);
    if (!events.length || !events.some(item => ['out', 'out_by', 'inout'].includes(item.entry_type))) return null;
    const entries = events.filter(item => ['in', 'inout'].includes(item.entry_type));
    const exits = events.filter(item => ['out', 'out_by', 'inout'].includes(item.entry_type));
    const firstEntry = entries[0] || events[0];
    const side = firstEntry.deal_type === 'sell' ? 'sell' : firstEntry.deal_type === 'buy' ? 'buy' : (exits[0]?.deal_type === 'sell' ? 'buy' : 'sell');
    const volume = entries.reduce((sum, item) => sum + Number(item.volume || 0), 0) || exits.reduce((sum, item) => sum + Number(item.volume || 0), 0);
    const weighted = (rows, field) => {
      const total = rows.reduce((sum, item) => sum + Number(item.volume || 0), 0);
      return total > 0 ? rows.reduce((sum, item) => sum + Number(item[field] || 0) * Number(item.volume || 0), 0) / total : 0;
    };
    const gross = events.reduce((sum, item) => sum + Number(item.profit || 0), 0);
    const commission = events.reduce((sum, item) => sum + Math.abs(Number(item.commission || 0)), 0);
    const fee = events.reduce((sum, item) => sum + Math.abs(Number(item.fee || 0)), 0);
    const swap = events.reduce((sum, item) => sum + Number(item.swap || 0), 0);
    const costs = commission + fee;
    const net = gross - costs + swap;
    const entryAt = (entries[0] || events[0]).deal_time;
    const exitAt = (exits[exits.length - 1] || events[events.length - 1]).deal_time;
    const comments = [...new Set(events.map(item => item.comment).filter(Boolean))];
    const magics = [...new Set(events.map(item => item.magic).filter(Boolean))];
    const symbols = [...new Set(events.map(item => item.symbol).filter(Boolean))];
    const symbol = symbols[0] || '';
    const tradeId = `mt5_${connection.id}_${positionId}`;
    const entryDateMs = new Date(entryAt).getTime();
    const planAnnotation = db.prepare(`SELECT payload_json,captured_at
      FROM mt5_trade_annotations WHERE connection_id=? AND symbol=?
      AND annotation_type='plan' AND captured_at<=? AND captured_at>=?
      ORDER BY captured_at DESC LIMIT 1`).get(
      connection.id, symbol, entryAt,
      new Date(entryDateMs - 4 * 60 * 60 * 1000).toISOString());
    const reviewAnnotation = db.prepare(`SELECT payload_json,captured_at
      FROM mt5_trade_annotations WHERE connection_id=? AND position_id=?
      AND annotation_type='review' ORDER BY captured_at DESC LIMIT 1`).get(connection.id, positionId);
    let plan = null;
    let review = null;
    try { plan = planAnnotation ? JSON.parse(planAnnotation.payload_json) : null; } catch {}
    try { review = reviewAnnotation ? JSON.parse(reviewAnnotation.payload_json) : null; } catch {}
    const setup = plan?.setupName || comments[0] || (magics[0] ? `Magic ${magics[0]}` : 'ScalpTrader');
    const screenshots = db.prepare(`SELECT id,original_name,mime_type,size_bytes,uploaded_at,scan_status
      FROM media_files WHERE user_id=? AND trade_ref=? AND status='active' ORDER BY uploaded_at`).all(connection.user_id, tradeId);
    /* Attach the latest pre-entry Mindset check to the imported journal trade.
       These keys intentionally mirror the site's new-trade psychology form. */
    const mindsetEvent = db.prepare(`SELECT score,gate_enabled,answers_json,captured_at
      FROM mt5_mindset_events WHERE connection_id=? AND symbol=?
      AND captured_at<=? AND captured_at>=?
      ORDER BY captured_at DESC LIMIT 1`).get(
      connection.id, symbol, entryAt,
      new Date(new Date(entryAt).getTime() - 4 * 60 * 60 * 1000).toISOString());
    let mindsetPre = {};
    let mindsetMeta = null;
    if (mindsetEvent) {
      let answers = [];
      try { answers = JSON.parse(mindsetEvent.answers_json); } catch {}
      const answer = index => Number.isFinite(Number(answers[index])) && Number(answers[index]) >= 0 ? Number(answers[index]) === 1 : null;
      const score = Math.max(0, Math.min(100, Number(mindsetEvent.score) || 0));
      mindsetPre = {
        matchesPlan: answer(0),
        rrAcceptable: answer(1),
        sizeMatchesRisk: answer(2),
        newsUpcoming: answer(3),
        checkedOtherTimeframes: answer(4),
        // Mindset is binary; map it to valid New Trade emotion values.
        emotionBefore: answers[5] === 1 ? 'آرام' : answers[5] === 0 ? 'مضطرب' : null,
        energyLevel: Math.max(1, Math.min(5, Math.round(score / 20))),
        setupConfidence: Math.max(1, Math.min(5, Math.round(score / 20)))
      };
      mindsetMeta = {
        source: 'mt5-mindset-site-questions-v1',
        score,
        gateEnabled: !!mindsetEvent.gate_enabled,
        answers,
        questionKeys: ['matchesPlan','rrAcceptable','sizeMatchesRisk','newsUpcoming','checkedOtherTimeframes','emotionBefore'],
        capturedAt: mindsetEvent.captured_at
      };
    }
    if (plan) {
      mindsetPre = {
        ...mindsetPre,
        plannedRR: plan.plannedRR || null,
        riskPercent: plan.riskPercent || null,
        planNote: plan.note || '',
        planCapturedAt: planAnnotation?.captured_at || null
      };
    }
    const post = {
      notes: 'همگام‌سازی زنده از MetaTrader 5',
      emotionAfter: '',
      executionQuality: null,
      mistakes: []
    };
    if (review) {
      post.reviewedAt = reviewAnnotation?.captured_at || null;
      post.onPlan = !!review.onPlan;
      post.mistake = review.mistake || '';
      post.emotionAfter = review.emotionAfter || '';
      post.executionQuality = review.onPlan ? 5 : 2;
      post.mistakes = review.mistake ? [review.mistake] : [];
      post.notes = review.mistake || 'بازبینی سریع از داخل اکسپرت SmartJournal';
    }
    return {
      id: tradeId,
      accountId: connection.account_id,
      symbol,
      direction: side,
      entryDate: entryAt,
      exitDate: exitAt,
      resultType: net >= 0 ? 'profit' : 'loss',
      amount: Math.abs(gross),
      commission: costs,
      swap,
      positionSize: volume > 0 ? String(Number(volume.toFixed(8))) : '',
      setupName: setup.slice(0, 120),
      riskPercent: plan?.riskPercent || '',
      plannedRR: plan?.plannedRR || '',
      riskFree: false,
      pre: mindsetPre,
      post,
      timeframe: events.find(item => item.symbol_period)?.symbol_period || '',
      createdAt: events[0].received_at,
      updatedAt: new Date().toISOString(),
      hasChart: screenshots.length > 0,
      hasDocumentation: screenshots.length > 0,
      importMeta: {
        source: 'mt5-live',
        format: 'MetaTrader 5 API',
        brokerServer: connection.broker_server,
        accountLoginHint: connection.login_hint,
        positionId,
        dealTickets: events.map(item => item.deal_ticket),
        orderTickets: [...new Set(events.map(item => item.order_ticket).filter(Boolean))],
        magicNumbers: magics,
        comments,
        entryPrice: weighted(entries, 'price'),
        exitPrice: weighted(exits, 'price'),
        grossPnl: gross,
        netPnl: net,
        totalCommission: commission,
        totalFee: fee,
        serverUtcOffsetMinutes: events.find(item => item.server_offset_minutes !== null)?.server_offset_minutes ?? 0,
        eaVersion: connection.ea_version || '',
        mindset: mindsetMeta,
        tradePlan: plan ? { ...plan, capturedAt: planAnnotation?.captured_at || null } : null,
        tradeReview: review ? { ...review, capturedAt: reviewAnnotation?.captured_at || null } : null,
        screenshots: screenshots.map(file => ({
          id: file.id,
          url: `/api/journal/media/${file.id}`,
          stage: String(file.original_name || '').includes('_entry') ? 'entry' : 'exit',
          mimeType: file.mime_type,
          sizeBytes: file.size_bytes,
          uploadedAt: file.uploaded_at,
          scanStatus: file.scan_status
        })),
        syncedAt: new Date().toISOString()
      }
    };
  };

  const materializePosition = (connection, positionId, now) => {
    const trade = positionTrade(connection, positionId);
    if (!trade) return 'ignored';
    const current = db.prepare('SELECT id,payload FROM journal_trades WHERE user_id=? AND id=?').get(connection.user_id, trade.id);
    const comparable = value => {
      const copy = JSON.parse(JSON.stringify(value));
      delete copy.updatedAt;
      if (copy.importMeta) delete copy.importMeta.syncedAt;
      return JSON.stringify(copy);
    };
    if (current) {
      const previous = (() => { try { return JSON.parse(current.payload); } catch { return null; } })();
      if (previous && comparable(previous) === comparable(trade)) return 'unchanged';
    } else {
      const activeCount = Number(db.prepare("SELECT COUNT(*) AS count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL").get(connection.user_id).count || 0);
      if (activeCount >= userTradeLimit(connection.user_id)) return 'quota';
    }
    const payload = JSON.stringify(trade);
    db.prepare(`INSERT INTO journal_trades
      (user_id,id,account_id,entry_at,symbol,direction,result_type,amount,payload,created_at,updated_at,deleted_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,NULL)
      ON CONFLICT(user_id,id) DO UPDATE SET account_id=excluded.account_id,
      entry_at=excluded.entry_at,symbol=excluded.symbol,direction=excluded.direction,
      result_type=excluded.result_type,amount=excluded.amount,payload=excluded.payload,
      updated_at=excluded.updated_at,deleted_at=NULL`)
      .run(connection.user_id, trade.id, trade.accountId, trade.entryDate, trade.symbol,
        trade.direction, trade.resultType, trade.amount, payload, trade.createdAt || now, now);
    return current ? 'updated' : 'created';
  };

  const refreshTradeCount = userId => {
    const count = db.prepare('SELECT COUNT(*) AS count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL').get(userId).count;
    db.prepare('UPDATE users SET trades_count=?,updated_at=? WHERE id=?').run(Number(count || 0), iso(), userId);
  };

  /* User-facing pairing endpoints. They are under /api/journal, which already
     has userAuth mounted globally in server.js. */
  app.get('/api/journal/mt5/connections', (req, res) => {
    const rows = db.prepare(`SELECT id,account_id,label,broker_server,login_hint,status,sync_mode,
      ea_version,currency,created_at,updated_at,last_seen_at,last_sync_at,last_ip,last_error
      FROM mt5_connections WHERE user_id=? ORDER BY created_at DESC`).all(req.user.id);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ rows });
  });

  app.get('/api/journal/mt5/mindset', (req, res) => {
    const rows = db.prepare(`SELECT m.connection_id,m.symbol,m.score,m.gate_enabled,m.answers_json,
      m.captured_at,m.received_at,c.label
      FROM mt5_mindset_events m JOIN mt5_connections c ON c.id=m.connection_id
      WHERE c.user_id=? ORDER BY m.captured_at DESC LIMIT 100`).all(req.user.id).map(row => ({
      ...row,
      gate_enabled: !!row.gate_enabled,
      answers: (() => { try { return JSON.parse(row.answers_json); } catch { return []; } })()
    }));
    res.setHeader('Cache-Control', 'no-store');
    res.json({ rows });
  });

  app.post('/api/journal/mt5/pairing', userCsrf, requireJournalSection('new'), journalWriteGuard, (req, res) => {
    const limit = rateLimit(`pairing:${req.user.id}`, 10, 15 * 60 * 1000);
    if (!limit.ok) return res.status(429).json({ error: 'تعداد درخواست‌های اتصال زیاد است.', retryAfter: limit.retryAfter });
    const now = iso();
    db.prepare('UPDATE mt5_pairing_codes SET consumed_at=? WHERE user_id=? AND consumed_at IS NULL').run(now, req.user.id);
    const code = makePairingCode();
    const rowId = id('mt5pair');
    db.prepare(`INSERT INTO mt5_pairing_codes
      (id,user_id,code_hash,code_hint,expires_at,created_at,consumed_at)
      VALUES (?,?,?,?,?,?,NULL)`).run(rowId, req.user.id, tokenHash(codeNormalize(code)), code.slice(-4), new Date(Date.now() + PAIRING_TTL_MS).toISOString(), now);
    logUserActivity({ userId: req.user.id, action: 'MT5_PAIRING_CODE_CREATED', entityType: 'mt5_pairing', entityId: rowId, details: { expiresAt: new Date(Date.now() + PAIRING_TTL_MS).toISOString() }, ip: clientIp(req) });
    res.status(201).json({ ok: true, code, expiresAt: new Date(Date.now() + PAIRING_TTL_MS).toISOString(), instructions: 'این کد را در تنظیمات SmartJournal اکسپرت وارد کنید.' });
  });

  app.delete('/api/journal/mt5/connections/:id', userCsrf, (req, res) => {
    const connection = db.prepare('SELECT id FROM mt5_connections WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
    if (!connection) return res.status(404).json({ error: 'اتصال MetaTrader پیدا نشد.' });
    const now = iso();
    db.prepare("UPDATE mt5_connections SET status='revoked',token_hash=?,updated_at=? WHERE id=? AND user_id=?")
      .run(`revoked_${crypto.randomBytes(16).toString('hex')}`, now, connection.id, req.user.id);
    logUserActivity({ userId: req.user.id, action: 'MT5_CONNECTION_REVOKED', entityType: 'mt5_connection', entityId: connection.id, ip: clientIp(req) });
    res.json({ ok: true, revokedAt: now });
  });

  /* EA-facing pairing endpoint. The code is single-use and expires quickly. */
  app.post('/api/integrations/mt5/pair', (req, res) => {
    const ipLimit = rateLimit(`pair-ip:${clientIp(req)}`, 20, 15 * 60 * 1000);
    if (!ipLimit.ok) return res.status(429).json({ error: 'تعداد تلاش‌های Pairing زیاد است.', retryAfter: ipLimit.retryAfter });
    const code = codeNormalize(req.body?.pairing_code || req.body?.pairingCode);
    if (code.length < 10) return res.status(400).json({ error: 'کد اتصال معتبر نیست.' });
    const pairing = db.prepare(`SELECT * FROM mt5_pairing_codes
      WHERE code_hash=? AND consumed_at IS NULL AND expires_at>? LIMIT 1`).get(tokenHash(code), iso());
    if (!pairing) return res.status(401).json({ error: 'کد اتصال نامعتبر یا منقضی است.' });
    const login = clean(req.body?.account_login || req.body?.login, 20);
    const brokerServer = clean(req.body?.broker_server || req.body?.server, 120);
    const currency = clean(req.body?.currency, 12).toUpperCase();
    const scopeSymbol = clean(req.body?.symbol, 40).toUpperCase();
    const scopeMagic = clean(req.body?.magic, 40);
    if (!validLogin(login) || brokerServer.length < 1 || brokerServer.length > 120
        || !validSymbol(scopeSymbol) || !/^-?[0-9]{1,20}$/.test(scopeMagic))
      return res.status(400).json({ error: 'اطلاعات حساب MT5 معتبر نیست.' });
    const now = iso();
    const connectionId = id('mt5');
    const accountId = `mt5_${connectionId}`;
    const token = secureToken(36);
    const balance = finite(req.body?.balance);
    const eaVersion = clean(req.body?.ea_version || req.body?.eaVersion, 40);
    const label = `MT5 · ${brokerServer} · ${accountHint(login)}`;
    const accountPayload = {
      id: accountId,
      name: label,
      startingBalance: balance,
      currency,
      source: 'mt5-live',
      brokerServer,
      accountLoginHint: accountHint(login),
      createdAt: now,
      updatedAt: now
    };
    try {
      db.transaction(() => {
        db.prepare('UPDATE mt5_pairing_codes SET consumed_at=? WHERE id=?').run(now, pairing.id);
        db.prepare(`INSERT INTO mt5_connections
          (id,user_id,account_id,label,broker_server,login_hint,login_hash,token_hash,token_prefix,status,sync_mode,ea_version,currency,scope_symbol,scope_magic,created_at,updated_at,last_seen_at,last_sync_at,last_ip,last_error)
          VALUES (?,?,?,?,?,?,?,?,?,'active','closed',?,?,?,?,?,?,?,?,?,NULL)`).run(
            connectionId, pairing.user_id, accountId, label, brokerServer, accountHint(login), tokenHash(login), tokenHash(token), token.slice(0, 8),
            eaVersion, currency, scopeSymbol, scopeMagic, now, now, now, null, clientIp(req));
        db.prepare(`INSERT INTO journal_accounts
          (user_id,id,name,starting_balance,payload,created_at,updated_at,deleted_at)
          VALUES (?,?,?,?,?,?,?,NULL)
          ON CONFLICT(user_id,id) DO UPDATE SET name=excluded.name,
          starting_balance=excluded.starting_balance,payload=excluded.payload,updated_at=excluded.updated_at,deleted_at=NULL`)
          .run(pairing.user_id, accountId, label, balance, JSON.stringify(accountPayload), now, now);
      })();
      bumpJournalVersion(pairing.user_id, 'pa-accounts', now);
      logUserActivity({ userId: pairing.user_id, action: 'MT5_CONNECTION_PAIRED', entityType: 'mt5_connection', entityId: connectionId, details: { brokerServer, accountLoginHint: accountHint(login), accountId }, ip: clientIp(req) });
      res.status(201).json({ ok: true, token, connectionId, accountId, accountLabel: label, syncMode: 'closed' });
    } catch (error) {
      if (error && /UNIQUE|constraint/i.test(String(error.message))) return res.status(409).json({ error: 'این اتصال از قبل ثبت شده یا کد دیگر معتبر نیست.' });
      throw error;
    }
  });

  /* EA-facing ingestion endpoint. */
  app.post('/api/integrations/mt5/sync', (req, res) => {
    const token = bearer(req);
    const connection = activeConnection(token);
    if (!connection) return res.status(401).json({ error: 'توکن اتصال MT5 نامعتبر یا لغوشده است.' });
    if (!connection.scope_symbol || !connection.scope_magic) return res.status(409).json({ error: 'این اتصال قدیمی است؛ برای اعمال محدودیت نماد و Magic دوباره Pair کن.' });
    const limit = rateLimit(`sync:${connection.id}`, 240, 60 * 1000);
    if (!limit.ok) return res.status(429).json({ error: 'تعداد درخواست‌های Sync زیاد است.', retryAfter: limit.retryAfter });
    const rawEvents = Array.isArray(req.body?.events) ? req.body.events : [];
    if (rawEvents.length > MAX_BATCH) return res.status(413).json({ error: `هر بسته حداکثر ${MAX_BATCH} Deal داشته باشد.` });
    const body = req.body || {};
    const normalized = rawEvents.map(item => normalizeEvent(item, connection, body)).filter(Boolean);
    if (rawEvents.length && !normalized.length) return res.status(400).json({ error: 'هیچ Deal معتبر و قابل پردازشی در بسته وجود ندارد.' });
    const mindset = body.mindset == null ? null : normalizeMindset(body.mindset, connection, body);
    if (body.mindset != null && !mindset) return res.status(400).json({ error: 'دادهٔ Mindset معتبر نیست.' });
    const tradePlan = body.trade_plan == null ? null : normalizeTradePlan(body.trade_plan, connection, body);
    if (body.trade_plan != null && !tradePlan) return res.status(400).json({ error: 'دادهٔ Trade Plan معتبر نیست.' });
    const tradeReview = body.trade_review == null ? null : normalizeTradeReview(body.trade_review, connection, body);
    if (body.trade_review != null && !tradeReview) return res.status(400).json({ error: 'دادهٔ Trade Review معتبر نیست.' });
    const now = iso();
    const accepted = [];
    const positions = new Set();
    const insert = db.prepare(`INSERT INTO mt5_deals
      (id,connection_id,external_key,deal_ticket,order_ticket,position_id,entry_type,deal_type,symbol,volume,price,profit,commission,swap,fee,deal_time,server_time,server_offset_minutes,magic,comment,payload,received_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    db.transaction(() => {
      for (const event of normalized) {
        const externalKey = `${connection.id}:${event.dealTicket}`;
        /* Re-materialize duplicate positions too: this lets a later retry
           succeed after a plan quota is raised or a missing entry arrives. */
        positions.add(event.positionId);
        if (db.prepare('SELECT id FROM mt5_deals WHERE external_key=?').get(externalKey)) continue;
        insert.run(id('mt5deal'), connection.id, externalKey, event.dealTicket, event.orderTicket || null, event.positionId,
          event.entry, event.type, event.symbol, event.volume, event.price, event.profit, event.commission, event.swap, event.fee,
          event.dealTime, event.serverTime || null, event.serverOffsetMinutes, event.magic || null, event.comment || null,
          JSON.stringify(event.raw), now);
        accepted.push(event.dealTicket);
      }
      let mindsetAccepted = 0;
      if (mindset && !db.prepare('SELECT id FROM mt5_mindset_events WHERE event_key=?').get(mindset.eventKey)) {
        db.prepare(`INSERT INTO mt5_mindset_events
          (id,connection_id,event_key,symbol,score,gate_enabled,answers_json,captured_at,received_at)
          VALUES (?,?,?,?,?,?,?,?,?)`)
          .run(id('mt5mind'), connection.id, mindset.eventKey, mindset.symbol, mindset.score,
            mindset.gateEnabled, mindset.answersJson, mindset.capturedAt, now);
        mindsetAccepted = 1;
      }
      const annotationInsert = db.prepare(`INSERT INTO mt5_trade_annotations
        (id,connection_id,symbol,annotation_type,position_id,payload_json,captured_at,event_key,received_at)
        VALUES (?,?,?,?,?,?,?,?,?)`);
      let planAccepted = 0;
      let reviewAccepted = 0;
      if (tradePlan && !db.prepare('SELECT id FROM mt5_trade_annotations WHERE event_key=?').get(tradePlan.eventKey)) {
        annotationInsert.run(id('mt5plan'), connection.id, tradePlan.symbol, tradePlan.type, null,
          JSON.stringify(tradePlan.payload), tradePlan.capturedAt, tradePlan.eventKey, now);
        planAccepted = 1;
      }
      if (tradeReview && !db.prepare('SELECT id FROM mt5_trade_annotations WHERE event_key=?').get(tradeReview.eventKey)) {
        annotationInsert.run(id('mt5review'), connection.id, tradeReview.symbol, tradeReview.type, tradeReview.positionId,
          JSON.stringify(tradeReview.payload), tradeReview.capturedAt, tradeReview.eventKey, now);
        positions.add(tradeReview.positionId);
        reviewAccepted = 1;
      }
      const connectionUpdate = `UPDATE mt5_connections SET updated_at=?,last_seen_at=?,last_sync_at=?,last_ip=?,ea_version=COALESCE(NULLIF(?,''),ea_version),currency=COALESCE(NULLIF(?,''),currency),last_error=NULL WHERE id=?`;
      db.prepare(connectionUpdate).run(now, now, now, clientIp(req), clean(body.ea_version, 40), clean(body.currency, 12).toUpperCase(), connection.id);
      let created = 0, updated = 0, quota = 0;
      positions.forEach(positionId => {
        const result = materializePosition(connection, positionId, now);
        if (result === 'created') created += 1;
        else if (result === 'updated') updated += 1;
        else if (result === 'quota') quota += 1;
      });
      connection._materialized = { created, updated, quota, mindsetAccepted, planAccepted, reviewAccepted };
    })();
    const materialized = connection._materialized || { created: 0, updated: 0, quota: 0, planAccepted: 0, reviewAccepted: 0 };
    if (accepted.length || materialized.created || materialized.updated || materialized.planAccepted || materialized.reviewAccepted) {
      refreshTradeCount(connection.user_id);
      bumpJournalVersion(connection.user_id, 'pa-trades', now);
    }
    logUserActivity({ userId: connection.user_id, action: 'MT5_SYNC_RECEIVED', entityType: 'mt5_connection', entityId: connection.id, details: { accepted: accepted.length, created: connection._materialized?.created || 0, updated: connection._materialized?.updated || 0, mindsetAccepted: connection._materialized?.mindsetAccepted || 0, planAccepted: connection._materialized?.planAccepted || 0, reviewAccepted: connection._materialized?.reviewAccepted || 0 }, ip: clientIp(req) });
    res.json({
      ok: true,
      accepted: accepted.length,
      ignoredDuplicates: normalized.length - accepted.length,
      createdTrades: connection._materialized?.created || 0,
      updatedTrades: connection._materialized?.updated || 0,
      quotaBlocked: connection._materialized?.quota || 0,
      mindsetAccepted: connection._materialized?.mindsetAccepted || 0,
      planAccepted: connection._materialized?.planAccepted || 0,
      reviewAccepted: connection._materialized?.reviewAccepted || 0,
      lastSyncAt: now
    });
  });

  app.post('/api/integrations/mt5/screenshot', (req, res) => {
    const token = bearer(req);
    const connection = activeConnection(token);
    if (!connection) return res.status(401).json({ error: 'توکن اتصال MT5 نامعتبر یا لغوشده است.' });
    const limit = rateLimit(`screenshot:${connection.id}`, 120, 60 * 60 * 1000);
    if (!limit.ok) return res.status(429).json({ error: 'تعداد تصاویر ارسالی زیاد است.', retryAfter: limit.retryAfter });
    const stage = ['entry', 'exit'].includes(String(req.body?.stage).toLowerCase()) ? String(req.body.stage).toLowerCase() : '';
    const symbol = clean(req.body?.symbol, 40).toUpperCase();
    const positionId = clean(req.body?.position_id || req.body?.positionId, 90);
    const dealTicket = clean(req.body?.deal_ticket || req.body?.dealTicket, 40);
    const data = String(req.body?.image_data || req.body?.data || '');
    const capturedUnix = Number(req.body?.captured_unix || req.body?.capturedUnix || 0);
    if (!stage || !validSymbol(symbol) || symbol !== String(connection.scope_symbol).toUpperCase()
        || !validId(positionId) || !validId(dealTicket) || !Number.isFinite(capturedUnix)
        || capturedUnix <= 0 || data.length < 100 || data.length > 17 * 1024 * 1024) {
      return res.status(400).json({ error: 'اطلاعات یا تصویر اسکرین‌شات معتبر نیست.' });
    }
    const expectedTradeId = `mt5_${connection.id}_${positionId}`;
    const created = [];
    try {
      const fileId = storeJournalImage(connection.user_id, data, expectedTradeId, created);
      const now = iso();
      db.prepare('UPDATE media_files SET orphaned_at=NULL WHERE id=? AND user_id=?').run(fileId, connection.user_id);
      db.prepare('UPDATE mt5_connections SET last_seen_at=?,updated_at=?,last_error=NULL WHERE id=?').run(now, now, connection.id);
      logUserActivity({ userId: connection.user_id, action: 'MT5_SCREENSHOT_RECEIVED', entityType: 'media_file', entityId: fileId, details: { stage, symbol, positionId, dealTicket }, ip: clientIp(req) });
      res.status(201).json({ ok: true, id: fileId, tradeId: expectedTradeId, stage, url: `/api/journal/media/${fileId}` });
    } catch (error) {
      if (error.status) return res.status(error.status).json({ error: error.message });
      throw error;
    }
  });

  app.get('/api/integrations/mt5/ping', (req, res) => {
    const connection = activeConnection(bearer(req));
    if (!connection) return res.status(401).json({ ok: false });
    if (!connection.scope_symbol || !connection.scope_magic) return res.status(409).json({ ok: false, error: 'اتصال قدیمی است و باید دوباره Pair شود.' });
    const now = iso();
    db.prepare('UPDATE mt5_connections SET last_seen_at=?,updated_at=? WHERE id=?').run(now, now, connection.id);
    res.json({ ok: true, connectionId: connection.id, serverTime: now });
  });
}

module.exports = { install };
