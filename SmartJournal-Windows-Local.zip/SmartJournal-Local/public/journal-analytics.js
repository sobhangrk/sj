/* SmartJournal — Professional Analytics Studio
 * مستقل از bundle ژورنال نگه داشته شده تا بخش تحلیل بدون دست‌کاری داده‌های خام
 * و بدون وابستگی به کتابخانهٔ نمودار، روی نسخه‌های بعدی هم قابل ارتقا باشد.
 */
(function () {
  'use strict';
  if (location.protocol === 'file:' || window.__PA_JOURNAL_ANALYTICS__) return;
  window.__PA_JOURNAL_ANALYTICS__ = true;

  var ROOT_CLASS = 'pa-analytics-studio';
  var lastSignature = '';
  var refreshTimer = null;
  var observer = null;
  var css = `
    .pa-analytics-studio{--as-bg:#0b1320;--as-card:#101b2b;--as-card-2:#0d1726;--as-line:#203149;--as-text:#edf7fb;--as-muted:#8fa2b6;--as-cyan:#36d7e7;--as-green:#35d38a;--as-red:#fb7185;--as-purple:#a78bfa;direction:rtl;margin:18px 0 22px;padding:22px;border:1px solid rgba(54,215,231,.22);border-radius:24px;background:radial-gradient(circle at 8% 0,rgba(54,215,231,.11),transparent 30%),linear-gradient(145deg,#101c2d,#0a111c);box-shadow:0 18px 60px rgba(0,0,0,.18);color:var(--as-text);font-family:Vazirmatn,Tahoma,Arial,sans-serif}
    .pa-analytics-studio *{box-sizing:border-box}.pa-as-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}.pa-as-kicker{display:block;color:var(--as-cyan);font:700 10px/1.4 JetBrains Mono,monospace;letter-spacing:.14em;text-transform:uppercase;direction:ltr}.pa-as-title{margin:5px 0 5px;font-size:clamp(20px,2.4vw,29px);letter-spacing:-.03em}.pa-as-sub{margin:0;color:var(--as-muted);font-size:12px;line-height:1.9}.pa-as-refresh{display:inline-flex;align-items:center;gap:7px;min-height:38px;padding:8px 12px;border:1px solid rgba(143,162,182,.27);border-radius:11px;background:rgba(255,255,255,.035);color:var(--as-text);font:600 12px Vazirmatn;cursor:pointer}.pa-as-refresh:hover{border-color:var(--as-cyan);color:var(--as-cyan)}.pa-as-refresh[disabled]{opacity:.6;cursor:wait}.pa-as-filters{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:9px;padding:11px;margin:0 0 16px;border:1px solid rgba(143,162,182,.16);border-radius:15px;background:rgba(4,9,16,.22)}.pa-as-field{display:flex;flex-direction:column;gap:5px;min-width:0}.pa-as-field label{color:var(--as-muted);font-size:10px}.pa-as-field select{width:100%;min-height:37px;padding:7px 9px;border:1px solid #263950;border-radius:9px;background:#0b1523;color:var(--as-text);font:12px Vazirmatn;outline:none}.pa-as-field select:focus{border-color:var(--as-cyan);box-shadow:0 0 0 3px rgba(54,215,231,.11)}.pa-as-kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:9px;margin-bottom:16px}.pa-as-kpi{min-height:89px;padding:12px 13px;border:1px solid rgba(143,162,182,.14);border-radius:14px;background:rgba(16,27,43,.78)}.pa-as-kpi-label{display:block;color:var(--as-muted);font-size:10px;line-height:1.6}.pa-as-kpi-value{display:block;margin-top:7px;color:var(--as-text);font:700 21px/1.2 JetBrains Mono,Vazirmatn,monospace;direction:ltr;text-align:right;white-space:nowrap}.pa-as-kpi-value.pos{color:var(--as-green)}.pa-as-kpi-value.neg{color:var(--as-red)}.pa-as-kpi-note{display:block;margin-top:5px;color:#7890a7;font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pa-as-grid{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(280px,.75fr);gap:12px}.pa-as-card{min-width:0;padding:15px;border:1px solid rgba(143,162,182,.14);border-radius:16px;background:rgba(13,23,38,.78)}.pa-as-card-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 12px;font-size:13px;font-weight:700}.pa-as-card-title small{color:var(--as-muted);font-size:10px;font-weight:400}.pa-as-chart{width:100%;height:185px;display:block;overflow:visible}.pa-as-chart-grid{stroke:#23344b;stroke-width:1}.pa-as-chart-area{fill:url(#paAsArea)}.pa-as-chart-line{fill:none;stroke:var(--as-cyan);stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}.pa-as-axis{fill:#6f849a;font:9px JetBrains Mono,monospace}.pa-as-empty{display:flex;align-items:center;justify-content:center;min-height:150px;color:var(--as-muted);font-size:12px}.pa-as-insights{display:flex;flex-direction:column;gap:9px}.pa-as-insight{display:flex;gap:9px;align-items:flex-start;padding:10px 11px;border-radius:11px;background:rgba(255,255,255,.035);border-right:3px solid var(--as-cyan);font-size:11px;line-height:1.9;color:#c9d7e3}.pa-as-insight.good{border-right-color:var(--as-green)}.pa-as-insight.warn{border-right-color:#fbbf24}.pa-as-insight.bad{border-right-color:var(--as-red)}.pa-as-insight strong{display:block;color:var(--as-text);font-size:11px}.pa-as-insight-icon{flex:0 0 23px;width:23px;height:23px;display:grid;place-items:center;border-radius:7px;background:rgba(54,215,231,.12);color:var(--as-cyan);font-size:13px}.pa-as-tables{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px}.pa-as-table{width:100%;border-collapse:collapse;font-size:11px}.pa-as-table th{padding:7px 5px;color:#71879d;text-align:right;font-size:10px;font-weight:500;border-bottom:1px solid var(--as-line)}.pa-as-table td{padding:8px 5px;border-bottom:1px solid rgba(32,49,73,.65);white-space:nowrap}.pa-as-table tr:last-child td{border-bottom:0}.pa-as-table .num{direction:ltr;text-align:left;font-family:JetBrains Mono,Vazirmatn,monospace}.pa-as-pos{color:var(--as-green)}.pa-as-neg{color:var(--as-red)}.pa-as-muted{color:var(--as-muted)}.pa-as-badge{display:inline-block;padding:3px 6px;border-radius:5px;background:rgba(167,139,250,.12);color:#c4b5fd;font-size:9px}.pa-as-foot{display:flex;justify-content:space-between;gap:10px;margin-top:13px;color:#6f849a;font-size:10px}.pa-as-foot button{padding:0;border:0;background:none;color:var(--as-cyan);font:inherit;cursor:pointer}.pa-as-loading{min-height:160px;display:grid;place-items:center;color:var(--as-muted);font-size:12px}.pa-as-error{padding:15px;color:#fecdd3;background:rgba(251,113,133,.09);border:1px solid rgba(251,113,133,.2);border-radius:12px;font-size:12px}
    @media(max-width:1100px){.pa-as-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}.pa-as-filters{grid-template-columns:repeat(3,minmax(0,1fr))}}
    @media(max-width:720px){.pa-analytics-studio{padding:15px;margin:13px 0 18px;border-radius:18px}.pa-as-head{display:block}.pa-as-refresh{margin-top:12px}.pa-as-filters{grid-template-columns:repeat(2,minmax(0,1fr))}.pa-as-grid,.pa-as-tables{grid-template-columns:1fr}.pa-as-kpis{grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.pa-as-kpi{min-height:80px;padding:10px}.pa-as-kpi-value{font-size:17px}.pa-as-foot{display:block;line-height:1.9}}
  `;
  var style = document.createElement('style');
  style.id = 'pa-analytics-styles';
  style.textContent = css;
  document.head.appendChild(style);

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>'"]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[c];
    });
  }
  function faNum(value, decimals) {
    var n = Number(value || 0);
    if (!isFinite(n)) return '∞';
    var fixed = decimals == null ? (Math.abs(n) >= 100 ? 0 : 2) : decimals;
    return n.toLocaleString('fa-IR', { maximumFractionDigits: fixed, minimumFractionDigits: fixed });
  }
  function signed(value, decimals) {
    var n = Number(value || 0);
    return (n > 0 ? '+' : '') + faNum(n, decimals);
  }
  function pnl(trade) {
    if (!trade || trade.riskFree) return 0;
    var amount = Math.abs(Number(trade.amount || 0));
    var value = trade.resultType === 'profit' ? amount : trade.resultType === 'loss' ? -amount : 0;
    return value - Number(trade.commission || 0) + Number(trade.swap || 0);
  }
  function dateOf(trade) {
    var d = new Date(trade && (trade.entryDate || trade.date || trade.createdAt));
    return isNaN(d.getTime()) ? null : d;
  }
  function label(value, fallback) {
    var v = String(value == null ? '' : value).trim();
    return v || fallback || 'بدون برچسب';
  }
  function uniqueValues(trades, key, fallback) {
    var set = Object.create(null);
    trades.forEach(function (t) { var v = label(t[key], fallback); if (v) set[v] = true; });
    return Object.keys(set).sort(function (a, b) { return a.localeCompare(b, 'fa'); });
  }
  function getPeriodStart(period) {
    if (period === 'all') return null;
    var d = new Date(); d.setHours(0, 0, 0, 0);
    if (period === '30') d.setDate(d.getDate() - 29);
    else if (period === '90') d.setDate(d.getDate() - 89);
    else if (period === 'year') d.setMonth(0, 1);
    return d;
  }
  function calculate(trades, account) {
    var active = trades.filter(function (t) { return !t.riskFree; });
    var wins = active.filter(function (t) { return t.resultType === 'profit'; });
    var losses = active.filter(function (t) { return t.resultType === 'loss'; });
    var net = active.reduce(function (sum, t) { return sum + pnl(t); }, 0);
    var grossWin = wins.reduce(function (sum, t) { return sum + Math.abs(Number(t.amount || 0)); }, 0);
    var grossLoss = losses.reduce(function (sum, t) { return sum + Math.abs(Number(t.amount || 0)); }, 0);
    var start = Number(account && account.startingBalance) || 0;
    var ordered = active.slice().sort(function (a, b) { return (dateOf(a) || 0) - (dateOf(b) || 0); });
    var balance = start, peak = start, maxDrawdown = 0, maxDrawdownAmount = 0, curve = [{ balance: balance, date: null }];
    var currentStreak = 0, currentType = '', bestWin = 0, bestLoss = 0;
    ordered.forEach(function (t) {
      var value = pnl(t); balance += value; peak = Math.max(peak, balance);
      var dd = peak ? Math.max(0, (peak - balance) / peak * 100) : 0;
      if (dd > maxDrawdown) { maxDrawdown = dd; maxDrawdownAmount = peak - balance; }
      curve.push({ balance: balance, date: dateOf(t) });
      var type = t.resultType === 'profit' ? 'win' : t.resultType === 'loss' ? 'loss' : '';
      if (type === currentType) currentStreak++; else { currentType = type; currentStreak = type ? 1 : 0; }
      if (type === 'win') bestWin = Math.max(bestWin, currentStreak);
      if (type === 'loss') bestLoss = Math.max(bestLoss, currentStreak);
    });
    var rValues = active.filter(function (t) { return Number(t.riskPercent) > 0 && start > 0; }).map(function (t) {
      return pnl(t) / (start * Number(t.riskPercent) / 100);
    });
    var avgR = rValues.length ? rValues.reduce(function (s, v) { return s + v; }, 0) / rValues.length : null;
    return {
      total: active.length, wins: wins.length, losses: losses.length, net: net,
      winRate: active.length ? wins.length / active.length * 100 : 0,
      profitFactor: grossLoss ? grossWin / grossLoss : grossWin ? Infinity : 0,
      expectancy: active.length ? net / active.length : 0,
      maxDrawdown: maxDrawdown, maxDrawdownAmount: maxDrawdownAmount,
      avgR: avgR, curve: curve, balance: balance,
      bestWin: bestWin, bestLoss: bestLoss, currentStreak: currentStreak,
      currentType: currentType, grossWin: grossWin, grossLoss: grossLoss
    };
  }
  function groupStats(trades, key, fallback) {
    var groups = Object.create(null);
    trades.filter(function (t) { return !t.riskFree; }).forEach(function (t) {
      var name = label(t[key], fallback);
      if (!groups[name]) groups[name] = { name: name, count: 0, wins: 0, net: 0 };
      groups[name].count++;
      if (t.resultType === 'profit') groups[name].wins++;
      groups[name].net += pnl(t);
    });
    return Object.keys(groups).map(function (k) { var g = groups[k]; g.winRate = g.count ? g.wins / g.count * 100 : 0; return g; })
      .sort(function (a, b) { return b.net - a.net; });
  }
  function selectOptions(values, selected, allLabel) {
    return '<option value="all">' + esc(allLabel || 'همه') + '</option>' + values.map(function (v) {
      return '<option value="' + esc(v) + '"' + (selected === v ? ' selected' : '') + '>' + esc(v) + '</option>';
    }).join('');
  }
  function pathFor(curve, width, height, pad) {
    if (!curve.length) return '';
    var vals = curve.map(function (x) { return x.balance; });
    var min = Math.min.apply(Math, vals), max = Math.max.apply(Math, vals), span = max - min || 1;
    return curve.map(function (x, i) {
      var px = pad + (curve.length === 1 ? 0 : i / (curve.length - 1) * (width - pad * 2));
      var py = height - pad - (x.balance - min) / span * (height - pad * 2);
      return (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1);
    }).join(' ');
  }
  function chartHtml(stats) {
    if (!stats.curve || stats.curve.length < 2) return '<div class="pa-as-empty">برای ساخت منحنی، حداقل یک معامله لازم است.</div>';
    var width = 680, height = 185, pad = 16, path = pathFor(stats.curve, width, height, pad);
    var area = path + ' L' + (width - pad) + ' ' + (height - pad) + ' L' + pad + ' ' + (height - pad) + ' Z';
    var first = stats.curve[0].balance, last = stats.curve[stats.curve.length - 1].balance;
    return '<svg class="pa-as-chart" viewBox="0 0 ' + width + ' ' + height + '" role="img" aria-label="منحنی موجودی حساب">' +
      '<defs><linearGradient id="paAsArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#36d7e7" stop-opacity=".28"/><stop offset="1" stop-color="#36d7e7" stop-opacity="0"/></linearGradient></defs>' +
      '<line class="pa-as-chart-grid" x1="16" y1="34" x2="664" y2="34"/><line class="pa-as-chart-grid" x1="16" y1="92" x2="664" y2="92"/><line class="pa-as-chart-grid" x1="16" y1="150" x2="664" y2="150"/>' +
      '<path class="pa-as-chart-area" d="' + area + '"/><path class="pa-as-chart-line" d="' + path + '"/>' +
      '<text class="pa-as-axis" x="16" y="178">' + esc(faNum(first, 0)) + '</text><text class="pa-as-axis" x="664" y="178" text-anchor="end">' + esc(faNum(last, 0)) + '</text></svg>';
  }
  function tableHtml(rows, emptyText) {
    if (!rows.length) return '<div class="pa-as-empty">' + esc(emptyText || 'داده‌ای برای نمایش نیست.') + '</div>';
    return '<table class="pa-as-table"><thead><tr><th>گروه</th><th>تعداد</th><th>وین‌ریت</th><th>خالص</th></tr></thead><tbody>' + rows.slice(0, 6).map(function (g) {
      return '<tr><td>' + esc(g.name) + '</td><td class="num">' + faNum(g.count, 0) + '</td><td class="num">' + faNum(g.winRate, 0) + '%</td><td class="num ' + (g.net >= 0 ? 'pa-as-pos' : 'pa-as-neg') + '">' + esc(signed(g.net, 0)) + '</td></tr>';
    }).join('') + '</tbody></table>';
  }
  function insights(stats, symbols, setups, trades) {
    var out = [];
    if (!stats.total) return [{ tone: 'warn', icon: '◎', title: 'دادهٔ کافی نداریم', text: 'بعد از ثبت چند معامله، الگوهای عملکردی اینجا نمایش داده می‌شوند.' }];
    var best = symbols.filter(function (x) { return x.count >= 3; })[0];
    var worst = symbols.filter(function (x) { return x.count >= 3; }).slice(-1)[0];
    if (best) out.push({ tone: 'good', icon: '↗', title: 'بهترین نماد', text: best.name + ' با ' + faNum(best.count, 0) + ' معامله، خالص ' + signed(best.net, 0) + ' و وین‌ریت ' + faNum(best.winRate, 0) + '%.' });
    if (worst && (!best || worst.name !== best.name) && worst.net < 0) out.push({ tone: 'bad', icon: '↘', title: 'نیازمند بررسی', text: worst.name + ' در این بازه خالص ' + signed(worst.net, 0) + ' داشته؛ قبل از افزایش حجم، نمونه معاملاتش را مرور کن.' });
    var bestSetup = setups.filter(function (x) { return x.count >= 3; })[0];
    if (bestSetup) out.push({ tone: 'good', icon: '✦', title: 'ستاپ برتر', text: bestSetup.name + ' با ' + faNum(bestSetup.winRate, 0) + '% وین‌ریت، بهترین عملکرد بین ستاپ‌های دارای حداقل سه معامله را دارد.' });
    if (stats.maxDrawdown > 0) out.push({ tone: stats.maxDrawdown >= 10 ? 'bad' : 'warn', icon: '△', title: 'دراودان', text: 'بیشترین افت این فیلتر ' + faNum(stats.maxDrawdown, 1) + '% معادل حدود ' + signed(-stats.maxDrawdownAmount, 0) + ' بوده است.' });
    var highRisk = trades.filter(function (t) { return Number(t.riskPercent) >= 2 && !t.riskFree; });
    if (highRisk.length >= 3) {
      var highNet = highRisk.reduce(function (s, t) { return s + pnl(t); }, 0);
      out.push({ tone: highNet >= 0 ? 'good' : 'bad', icon: '!', title: 'ریسک‌های بزرگ', text: faNum(highRisk.length, 0) + ' معامله با ریسک حداقل ۲٪ ثبت شده؛ نتیجهٔ خالص آن‌ها ' + signed(highNet, 0) + ' است.' });
    }
    if (stats.currentType === 'loss' && stats.currentStreak >= 2) out.push({ tone: 'bad', icon: '!', title: 'رشتهٔ باخت فعلی', text: faNum(stats.currentStreak, 0) + ' باخت متوالی ثبت شده؛ قبل از معاملهٔ بعدی پلن و سقف ریسک را مرور کن.' });
    return out.slice(0, 4);
  }
  function makeFilter(labelText, name, html) {
    return '<div class="pa-as-field"><label for="' + name + '">' + labelText + '</label><select id="' + name + '" data-pa-as-filter="' + name + '">' + html + '</select></div>';
  }
  function filteredTrades(data, state) {
    var all = data.trades.filter(function (t) { return !state.account || state.account === 'all' || t.accountId === state.account; });
    var periodStart = getPeriodStart(state.period);
    return all.filter(function (t) {
      var d = dateOf(t);
      return (!periodStart || (d && d >= periodStart)) &&
        (state.symbol === 'all' || label(t.symbol, 'بدون نماد') === state.symbol) &&
        (state.setup === 'all' || label(t.setupName, 'بدون ستاپ') === state.setup) &&
        (state.result === 'all' || t.resultType === state.result);
    });
  }
  function accountFor(data, state) {
    return data.accounts.find(function (a) { return a.id === state.account; }) || data.accounts[0] || { startingBalance: 0 };
  }
  function view(data, state) {
    var all = data.trades.filter(function (t) { return !state.account || state.account === 'all' || t.accountId === state.account; });
    var filtered = filteredTrades(data, state);
    var account = accountFor(data, state);
    var stats = calculate(filtered, account), symbols = groupStats(filtered, 'symbol', 'بدون نماد'), setups = groupStats(filtered, 'setupName', 'بدون ستاپ');
    var insightHtml = insights(stats, symbols, setups, filtered).map(function (x) { return '<div class="pa-as-insight ' + x.tone + '"><span class="pa-as-insight-icon">' + x.icon + '</span><span><strong>' + esc(x.title) + '</strong>' + esc(x.text) + '</span></div>'; }).join('');
    var accounts = data.accounts.map(function (a) { return '<option value="' + esc(a.id) + '"' + (state.account === a.id ? ' selected' : '') + '>' + esc(a.name || 'حساب بدون نام') + '</option>'; }).join('');
    return '<section class="' + ROOT_CLASS + '" dir="rtl" data-pa-as-root>' +
      '<div class="pa-as-head"><div><span class="pa-as-kicker">PRO ANALYTICS / PERFORMANCE LAB</span><h2 class="pa-as-title">اتاق تحلیل عملکرد</h2><p class="pa-as-sub">با فیلترکردن داده‌ها بفهم کدام نماد، ستاپ و سطح ریسک واقعاً برایت بهتر کار می‌کند.</p></div><button class="pa-as-refresh" type="button" data-pa-as-refresh>↻ تازه‌سازی تحلیل</button></div>' +
      '<div class="pa-as-filters">' +
      makeFilter('بازهٔ تحلیل', 'period', '<option value="all"' + (state.period === 'all' ? ' selected' : '') + '>کل تاریخچه</option><option value="30"' + (state.period === '30' ? ' selected' : '') + '>۳۰ روز اخیر</option><option value="90"' + (state.period === '90' ? ' selected' : '') + '>۹۰ روز اخیر</option><option value="year"' + (state.period === 'year' ? ' selected' : '') + '>سال جاری</option>') +
      makeFilter('حساب', 'account', '<option value="all"' + (state.account === 'all' ? ' selected' : '') + '>همهٔ حساب‌ها</option>' + accounts) +
      makeFilter('نماد', 'symbol', selectOptions(uniqueValues(all, 'symbol', 'بدون نماد'), state.symbol, 'همهٔ نمادها')) +
      makeFilter('ستاپ', 'setup', selectOptions(uniqueValues(all, 'setupName', 'بدون ستاپ'), state.setup, 'همهٔ ستاپ‌ها')) +
      makeFilter('نتیجه', 'result', '<option value="all"' + (state.result === 'all' ? ' selected' : '') + '>همهٔ نتایج</option><option value="profit"' + (state.result === 'profit' ? ' selected' : '') + '>سودده</option><option value="loss"' + (state.result === 'loss' ? ' selected' : '') + '>زیان‌ده</option>') +
      '</div>' +
      '<div class="pa-as-kpis">' +
      '<div class="pa-as-kpi"><span class="pa-as-kpi-label">سود/زیان خالص</span><strong class="pa-as-kpi-value ' + (stats.net >= 0 ? 'pos' : 'neg') + '">' + esc(signed(stats.net, 0)) + '</strong><span class="pa-as-kpi-note">بعد از کمیسیون و Swap</span></div>' +
      '<div class="pa-as-kpi"><span class="pa-as-kpi-label">وین‌ریت</span><strong class="pa-as-kpi-value">' + faNum(stats.winRate, 0) + '%</strong><span class="pa-as-kpi-note">' + faNum(stats.wins, 0) + ' برد از ' + faNum(stats.total, 0) + ' معامله</span></div>' +
      '<div class="pa-as-kpi"><span class="pa-as-kpi-label">Profit Factor</span><strong class="pa-as-kpi-value ' + (stats.profitFactor >= 1 ? 'pos' : 'neg') + '">' + esc(stats.profitFactor === Infinity ? '∞' : faNum(stats.profitFactor, 2)) + '</strong><span class="pa-as-kpi-note">سود ناخالص / ضرر ناخالص</span></div>' +
      '<div class="pa-as-kpi"><span class="pa-as-kpi-label">Expectancy</span><strong class="pa-as-kpi-value ' + (stats.expectancy >= 0 ? 'pos' : 'neg') + '">' + esc(signed(stats.expectancy, 2)) + '</strong><span class="pa-as-kpi-note">میانگین هر معامله</span></div>' +
      '<div class="pa-as-kpi"><span class="pa-as-kpi-label">بیشترین Drawdown</span><strong class="pa-as-kpi-value neg">-' + faNum(stats.maxDrawdown, 1) + '%</strong><span class="pa-as-kpi-note">حدود ' + esc(signed(-stats.maxDrawdownAmount, 0)) + '</span></div>' +
      '<div class="pa-as-kpi"><span class="pa-as-kpi-label">میانگین R واقعی</span><strong class="pa-as-kpi-value ' + (stats.avgR == null || stats.avgR >= 0 ? 'pos' : 'neg') + '">' + (stats.avgR == null ? '—' : esc(signed(stats.avgR, 2) + 'R')) + '</strong><span class="pa-as-kpi-note">بر اساس درصد ریسک ثبت‌شده</span></div>' +
      '</div>' +
      '<div class="pa-as-grid"><div class="pa-as-card"><div class="pa-as-card-title">منحنی سرمایه <small>' + faNum(stats.total, 0) + ' معاملهٔ مؤثر</small></div>' + chartHtml(stats) + '</div><div class="pa-as-card"><div class="pa-as-card-title">بینش‌های این فیلتر</div><div class="pa-as-insights">' + insightHtml + '</div></div></div>' +
      '<div class="pa-as-tables"><div class="pa-as-card"><div class="pa-as-card-title">عملکرد بر اساس نماد <small>حداقل نمونه پیشنهادی: ۳ معامله</small></div>' + tableHtml(symbols, 'هنوز نمادی برای تحلیل وجود ندارد.') + '</div><div class="pa-as-card"><div class="pa-as-card-title">عملکرد بر اساس ستاپ <small>نام ستاپ را هنگام ثبت معامله وارد کن</small></div>' + tableHtml(setups, 'هنوز ستاپی برای تحلیل وجود ندارد.') + '</div></div>' +
      '<div class="pa-as-foot"><span>این تحلیل توصیفی است و سیگنال خرید یا فروش تولید نمی‌کند.</span><button type="button" data-pa-as-copy>کپی خلاصهٔ تحلیل</button></div>' +
      '</section>';
  }
  async function readData() {
    var keys = ['pa-trades', 'pa-accounts', 'pa-active-account'];
    var values = await Promise.all(keys.map(function (key) { return window.storage.get(key).catch(function () { return null; }); }));
    function parse(item, fallback) { try { return item && item.value ? JSON.parse(item.value) : fallback; } catch (_) { return fallback; } }
    var accounts = parse(values[1], []), active = values[2] && values[2].value ? String(values[2].value) : (accounts[0] && accounts[0].id);
    return { trades: parse(values[0], []), accounts: Array.isArray(accounts) ? accounts : [], active: active };
  }
  function defaultState(data) { return { period: 'all', account: data.active || 'all', symbol: 'all', setup: 'all', result: 'all' }; }
  function dataSignature(data) {
    var trades = data.trades.map(function (t) { return [t.id, t.accountId, t.entryDate, t.resultType, t.amount, t.commission, t.swap, t.symbol, t.setupName, t.riskPercent].join('~'); }).join('|');
    var accounts = data.accounts.map(function (a) { return [a.id, a.startingBalance, a.name].join('~'); }).join('|');
    return String(data.active || '') + '||' + accounts + '||' + trades;
  }
  function mount(host, data, state) {
    lastSignature = dataSignature(data);
    host.__paAsData = data;
    host.__paAsState = state;
    host.innerHTML = view(data, state);
    var root = host.querySelector('[data-pa-as-root]');
    root.querySelectorAll('[data-pa-as-filter]').forEach(function (el) {
      el.addEventListener('change', function () {
        state[el.getAttribute('data-pa-as-filter')] = el.value;
        if (el.getAttribute('data-pa-as-filter') === 'account') { state.symbol = 'all'; state.setup = 'all'; }
        mount(host, data, state);
      });
    });
    root.querySelector('[data-pa-as-refresh]').addEventListener('click', async function () {
      var button = this; button.disabled = true;
      try { data = await readData(); mount(host, data, state); } finally { button.disabled = false; }
    });
    root.querySelector('[data-pa-as-copy]').addEventListener('click', function () {
      var stats = calculate(filteredTrades(data, state), accountFor(data, state));
      var text = 'SmartJournal | سود خالص: ' + signed(stats.net, 0) + ' | Win Rate: ' + faNum(stats.winRate, 0) + '% | Profit Factor: ' + (stats.profitFactor === Infinity ? '∞' : faNum(stats.profitFactor, 2)) + ' | Expectancy: ' + signed(stats.expectancy, 2);
      navigator.clipboard && navigator.clipboard.writeText(text).then(function () { alert('خلاصهٔ تحلیل کپی شد.'); }).catch(function () {});
    });
  }
  async function ensure() {
    if (!window.storage) return;
    var dash = document.querySelector('.pa-dash');
    var body = document.querySelector('.pa-body');
    var dashboardTab = document.querySelector('.pa-tab[data-tab="dashboard"].active');
    if (!body || !dashboardTab) {
      document.querySelectorAll('[data-pa-as-host]').forEach(function (node) { node.remove(); });
      return;
    }
    var container = dash || body;
    var old = container.querySelector('[data-pa-as-host]');
    if (!old) {
      var host = document.createElement('div'); host.setAttribute('data-pa-as-host', '1');
      var anchor = dash && dash.querySelector('.pa-dash-hero');
      if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(host, anchor.nextSibling); else body.appendChild(host);
      host.innerHTML = '<section class="' + ROOT_CLASS + '"><div class="pa-as-loading">در حال آماده‌سازی اتاق تحلیل…</div></section>';
      try { var data = await readData(); mount(host, data, defaultState(data)); } catch (error) { host.innerHTML = '<section class="' + ROOT_CLASS + '"><div class="pa-as-error">تحلیل داده‌ها در این لحظه ممکن نشد. دوباره تازه‌سازی کن.</div></section>'; }
    }
  }
  async function sync() {
    var host = document.querySelector('[data-pa-as-host]');
    if (!host || !window.storage) return;
    try {
      var data = await readData();
      if (dataSignature(data) !== lastSignature) mount(host, data, host.__paAsState || defaultState(data));
    } catch (_) {}
  }
  function start() {
    if (observer) return;
    observer = new MutationObserver(function () { ensure(); });
    observer.observe(document.body, { childList: true, subtree: true });
    ensure();
    refreshTimer = setInterval(function () { ensure(); sync(); }, 2200);
  }
  window.addEventListener('pa-journal-app-loaded', start, { once: true });
  if (document.querySelector('.pa-body') && document.querySelector('.pa-tab[data-tab="dashboard"].active')) start();
  /* در بعضی مرورگرها module script داینامیک قبل از defer اجرا می‌شود؛
     بنابراین فقط به event تکیه نمی‌کنیم و اولین داشبورد را هم poll می‌کنیم. */
  var bootTimer = setInterval(function () {
    if (observer) return clearInterval(bootTimer);
    if (document.querySelector('.pa-body') && document.querySelector('.pa-tab[data-tab="dashboard"].active')) {
      clearInterval(bootTimer);
      start();
    }
  }, 350);
})();
