(function(){
  'use strict';
  if(window.__SMARTJOURNAL_MT5_BRIDGE__) return;
  window.__SMARTJOURNAL_MT5_BRIDGE__ = true;

  var auth = null, modal, list, status, codeBox;
  var css = `
    #sj-mt5-launcher{position:fixed;left:18px;bottom:20px;z-index:10040;border:1px solid #3a5877;border-radius:14px;background:linear-gradient(135deg,#12243a,#0e1726);color:#eaf5ff;box-shadow:0 12px 30px #02060caa;padding:11px 15px;display:flex;align-items:center;gap:9px;font:700 13px Tahoma,Arial;cursor:pointer;direction:rtl}
    #sj-mt5-launcher i{width:9px;height:9px;border-radius:50%;background:#5ce1bd;box-shadow:0 0 0 4px #5ce1bd22}
    #sj-mt5-overlay{position:fixed;inset:0;z-index:10050;background:#02060cb8;display:flex;align-items:center;justify-content:center;padding:18px;direction:rtl}
    #sj-mt5-modal{width:min(560px,100%);max-height:min(720px,calc(100vh - 32px));overflow:auto;border:1px solid #2d4563;border-radius:22px;background:#0a111d;color:#e9f3fb;box-shadow:0 24px 90px #000b;padding:24px;font:14px Tahoma,Arial}
    #sj-mt5-modal *{box-sizing:border-box}#sj-mt5-modal h2{margin:0 0 7px;font-size:21px;color:#f4c660}#sj-mt5-modal p{color:#91a6ba;line-height:1.9;margin:7px 0}#sj-mt5-modal code{direction:ltr;unicode-bidi:plaintext;color:#91f4d4;background:#071a1b;border:1px solid #1a4547;border-radius:7px;padding:2px 6px}
    .sj-mt5-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.sj-mt5-close{border:0;background:transparent;color:#7e94aa;font-size:24px;cursor:pointer;line-height:1}.sj-mt5-actions{display:flex;gap:8px;flex-wrap:wrap;margin:16px 0}.sj-mt5-btn{border:1px solid #355574;border-radius:10px;background:#132840;color:#dcecff;padding:10px 13px;font:700 12px Tahoma;cursor:pointer}.sj-mt5-btn.primary{background:#1d9b87;border-color:#35c5ab;color:#031b1a}.sj-mt5-btn.danger{background:#311d26;border-color:#794050;color:#ffb1bc}.sj-mt5-btn:disabled{opacity:.55;cursor:wait}
    .sj-mt5-connection{border:1px solid #243a53;border-radius:13px;background:#0e1b2a;padding:13px;margin:9px 0}.sj-mt5-connection strong{color:#dcecff}.sj-mt5-meta{display:flex;gap:8px;flex-wrap:wrap;color:#8ea5ba;font-size:11px;margin-top:8px}.sj-mt5-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#5ce1bd;margin-left:5px}.sj-mt5-dot.off{background:#f47c87}.sj-mt5-code{margin:14px 0;padding:17px;text-align:center;border-radius:13px;border:1px dashed #43d5bc;background:#062621;color:#9ff7dc;font:bold 25px Consolas,monospace;letter-spacing:3px;direction:ltr}.sj-mt5-steps{margin:12px 0;padding:13px 20px;border-radius:12px;background:#0e1a29;color:#aec1d1;line-height:2}.sj-mt5-steps li{margin:4px 0}.sj-mt5-error{color:#ff9eaa;background:#321b24;border:1px solid #69333e;border-radius:9px;padding:9px;margin-top:10px;line-height:1.8}.sj-mt5-ok{color:#9ff7dc;background:#092a24;border:1px solid #226b5c;border-radius:9px;padding:9px;margin-top:10px;line-height:1.8}.sj-mt5-empty{text-align:center;color:#7e94aa;padding:22px 6px;border:1px dashed #263d54;border-radius:12px}
    @media(max-width:600px){#sj-mt5-launcher{left:12px;bottom:12px;font-size:11px;padding:10px 12px}#sj-mt5-modal{padding:18px;border-radius:18px}.sj-mt5-code{font-size:21px}}
  `;
  var style = document.createElement('style'); style.id='sj-mt5-bridge-style'; style.textContent=css; document.head.appendChild(style);

  function esc(value){return String(value==null?'':value).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);});}
  async function json(url, options){
    var response = await fetch(url, Object.assign({credentials:'same-origin',headers:{'content-type':'application/json'}}, options||{}));
    var body = await response.json().catch(function(){return {};});
    if(!response.ok){var error=new Error(body.error||'درخواست ناموفق بود.');error.status=response.status;throw error;}
    return body;
  }
  async function loadAuth(){try{auth=await json('/api/auth/me',{headers:{}});return !!auth.user;}catch(error){return false;}}
  function showMessage(message, ok){status.innerHTML='<div class="sj-mt5-'+(ok?'ok':'error')+'">'+esc(message)+'</div>';}
  function closeModal(){if(modal){modal.remove();modal=null;}}
  function renderConnections(rows, mindsetRows){
    var latest={};(mindsetRows||[]).forEach(function(item){if(!latest[item.connection_id])latest[item.connection_id]=item;});
    list.innerHTML = rows.length ? rows.map(function(row){
      var last = row.last_sync_at ? new Date(row.last_sync_at).toLocaleString('fa-IR') : 'هنوز Sync نشده';
      var mind=latest[row.id], mindText=mind ? ('Mindset آخر: '+mind.score+'/100') : 'Mindset: هنوز ثبت نشده';
      return '<div class="sj-mt5-connection"><strong><span class="sj-mt5-dot '+(row.status==='active'?'':'off')+'"></span>'+esc(row.label)+'</strong><div class="sj-mt5-meta"><span>'+esc(row.broker_server)+'</span><span>حساب '+esc(row.login_hint)+'</span><span>آخرین Sync: '+esc(last)+'</span><span>'+esc(mindText)+'</span></div><div class="sj-mt5-actions"><button class="sj-mt5-btn danger" data-revoke="'+esc(row.id)+'">لغو اتصال</button></div></div>';
    }).join('') : '<div class="sj-mt5-empty">هنوز حساب MetaTrader 5 متصل نشده است.</div>';
    Array.from(list.querySelectorAll('[data-revoke]')).forEach(function(button){button.onclick=async function(){if(!confirm('این اتصال لغو شود؟ معاملات قبلی حذف نمی‌شوند.'))return;button.disabled=true;try{await json('/api/journal/mt5/connections/'+encodeURIComponent(button.dataset.revoke),{method:'DELETE',headers:{'x-csrf-token':auth.csrfToken}});showMessage('اتصال لغو شد. EA دیگر اجازهٔ ارسال داده ندارد.',true);await refresh();}catch(error){showMessage(error.message,false);button.disabled=false;}};});
  }
  async function refresh(){try{var pair=await Promise.all([json('/api/journal/mt5/connections'),json('/api/journal/mt5/mindset')]);renderConnections(pair[0].rows||[],pair[1].rows||[]);}catch(error){showMessage(error.message,false);}}
  async function createCode(){
    var button=document.getElementById('sj-mt5-create');button.disabled=true;codeBox.innerHTML='در حال ساخت کد…';status.innerHTML='';
    try{var data=await json('/api/journal/mt5/pairing',{method:'POST',headers:{'x-csrf-token':auth.csrfToken}});codeBox.textContent=data.code;showMessage('کد فقط یک‌بار مصرف است و ۱۵ دقیقه اعتبار دارد.',true);}catch(error){codeBox.textContent='';showMessage(error.message,false);}finally{button.disabled=false;}
  }
  function openModal(){
    if(modal){return;}
    modal=document.createElement('div');modal.id='sj-mt5-overlay';modal.innerHTML='<section id="sj-mt5-modal" role="dialog" aria-modal="true"><div class="sj-mt5-head"><div><h2>اتصال مستقیم MetaTrader 5</h2><p>اکسپرت فقط معاملات را می‌خواند؛ سایت هیچ رمز عبور بروکر یا مجوز اجرای معامله دریافت نمی‌کند.</p></div><button class="sj-mt5-close" aria-label="بستن">×</button></div><div id="sj-mt5-list"></div><div class="sj-mt5-actions"><button id="sj-mt5-create" class="sj-mt5-btn primary">ساخت کد اتصال جدید</button><button id="sj-mt5-refresh" class="sj-mt5-btn">به‌روزرسانی</button></div><div id="sj-mt5-code"></div><div id="sj-mt5-status"></div><ol class="sj-mt5-steps"><li>در سایت کد اتصال بساز.</li><li>در ورودی‌های بخش <code>SmartJournal Sync</code> اکسپرت، کد را وارد کن.</li><li>آدرس سایت را در <code>SmartJournalApiBaseUrl</code> بگذار.</li><li>در MT5 از مسیر Tools → Options → Expert Advisors، دامنه را برای WebRequest مجاز کن.</li><li>EA را روی چارت اجرا کن؛ فقط معاملات همین Magic Number و نماد ارسال می‌شوند.</li></ol></section>';
    document.body.appendChild(modal);list=modal.querySelector('#sj-mt5-list');status=modal.querySelector('#sj-mt5-status');codeBox=modal.querySelector('#sj-mt5-code');
    modal.querySelector('.sj-mt5-close').onclick=closeModal;modal.onclick=function(e){if(e.target===modal)closeModal();};modal.querySelector('#sj-mt5-create').onclick=createCode;modal.querySelector('#sj-mt5-refresh').onclick=refresh;refresh();
  }
  function mount(){
    if(document.getElementById('sj-mt5-launcher')) return;
    var launcher=document.createElement('button');launcher.id='sj-mt5-launcher';launcher.innerHTML='<i></i><span>اتصال MetaTrader 5</span>';launcher.onclick=openModal;document.body.appendChild(launcher);
  }
  loadAuth().then(function(ok){if(ok)mount();});
})();
