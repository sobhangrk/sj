/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paRuleCard(props) {
      const tone = props.breached ? "breached" : props.met ? "met" : "safe";
      return M.createElement("article", {
        className: "pa-prop-rule " + tone,
        "data-rule": props.id
      }, M.createElement("header", null, M.createElement("div", null, M.createElement("span", {
        className: "pa-prop-rule-kicker"
      }, props.kicker), M.createElement("h3", null, props.title)), M.createElement("span", {
        className: "pa-prop-state"
      }, props.breached ? "نقض شده" : props.met ? "تکمیل" : "مجاز")), M.createElement("strong", {
        className: "num pa-prop-rule-value"
      }, props.value), M.createElement("div", {
        className: "pa-prop-progress",
        role: "progressbar",
        "aria-valuemin": "0",
        "aria-valuemax": "100",
        "aria-valuenow": Math.round(props.progress)
      }, M.createElement("i", {
        style: {
          width: Math.min(100, props.progress) + "%"
        }
      })), M.createElement("p", null, props.help))
    }
    
    function paPropFirmCenter({
      account,
      trades,
      onSave
    }) {
      const readStored = () => ({
          ...paPropDefaults(account),
          ...account && account.propFirmRules || {}
        }),
        [rules, setRules] = M.useState(readStored),
        [saveState, setSaveState] = M.useState("idle"),
        [dirty, setDirty] = M.useState(!1),
        [formError, setFormError] = M.useState(""),
        saveTimer = M.useRef(null);
      M.useEffect(() => {
        setRules(readStored()), setSaveState("idle"), setDirty(!1), setFormError("")
      }, [account && account.id]);
      M.useEffect(() => () => saveTimer.current && clearTimeout(saveTimer.current), []);
      const report = M.useMemo(() => paEvaluatePropRules(account || {}, trades || [], rules), [account, trades, rules]),
        set = (key, value) => {
          setRules(current => ({
            ...current,
            [key]: value
          })), setDirty(!0), setFormError(""), saveState === "saved" && setSaveState("idle")
        },
        reset = () => {
          setRules(readStored()), setDirty(!1), setFormError(""), setSaveState("idle")
        },
        save = async () => {
          if (saveState === "saving") return;
          const errors = paValidatePropRules(account, rules),
            firstError = Object.values(errors)[0];
          if (firstError) {
            setFormError(firstError), setSaveState("error");
            return
          }
          const normalized = {
            ...rules,
            firmName: String(rules.firmName || "").trim(),
            phaseName: String(rules.phaseName || "").trim() || "چالش ارزیابی",
            startDate: rules.startDate || "",
            drawdownMode: rules.drawdownMode === "trailing" ? "trailing" : "static",
            dailyLossPercent: Number(rules.dailyLossPercent),
            totalLossPercent: Number(rules.totalLossPercent),
            profitTargetPercent: Number(rules.profitTargetPercent),
            minTradingDays: Number(rules.minTradingDays),
            maxRiskPerTradePercent: Number(rules.maxRiskPerTradePercent),
            consistencyPercent: Number(rules.consistencyPercent),
            updatedAt: new Date().toISOString()
          };
          setSaveState("saving"), setFormError("");
          try {
            const result = await Promise.resolve(onSave && onSave(normalized));
            if (result === !1) throw new Error("storage-failed");
            setRules(normalized), setDirty(!1), setSaveState("saved"), saveTimer.current && clearTimeout(saveTimer.current), saveTimer.current = setTimeout(() => setSaveState("idle"), 2600)
          } catch (_) {
            setSaveState("error"), setFormError("ذخیره قوانین انجام نشد؛ فضای ذخیره‌سازی مرورگر را بررسی و دوباره تلاش کنید.")
          }
        },
        breachLabels = [report.dailyBreached && "زیان روزانه", report.totalBreached && "افت سرمایه", report.riskBreached && "ریسک معامله", report.consistencyBreached && "قانون ثبات"].filter(Boolean),
        statusFa = report.status === "disabled" ? "پایش غیرفعال" : report.status === "breached" ? "حساب نقض شده" : report.status === "passed" ? "چالش تکمیل شده" : report.evaluatedTrades ? "در حال ارزیابی" : "منتظر اولین معامله",
        statusDetail = report.status === "breached" ? "موارد نقض: " + breachLabels.join("، ") : report.status === "passed" ? "هدف سود و حداقل روزها تکمیل شده‌اند" : report.status === "disabled" ? "برای شروع، پایش را فعال و قوانین را ذخیره کنید" : report.evaluatedTrades ? (rules.firmName || "پراپ‌فرم") + " · " + (rules.phaseName || "مرحله ارزیابی") : "در بازه انتخاب‌شده معامله‌ای وجود ندارد";
      return M.createElement("div", {
        className: "pa-feature-center pa-prop-center",
        "data-testid": "prop-firm-center",
        "data-status": report.status
      }, M.createElement("section", {
        className: "pa-feature-hero pa-prop-hero " + report.status
      }, M.createElement("div", null, M.createElement("span", {
        className: "pa-feature-eyebrow"
      }, "PROP FIRM CONTROL"), M.createElement("h1", null, "قوانین حساب پراپ‌فرم"), M.createElement("p", null, "قوانین این حساب را مستقل تنظیم کن؛ مسیر هر روز، هدف سود و افت سرمایه با کمیسیون و سواپ محاسبه می‌شوند و برداشت فقط موجودی نمایشی را کاهش می‌دهد.")), M.createElement("div", {
        className: "pa-prop-status",
        role: "status"
      }, M.createElement("span", null, statusFa), M.createElement("b", {
        className: "num"
      }, Ke(report.current)), M.createElement("small", null, statusDetail))), breachLabels.length && rules.enabled ? M.createElement("div", {
        className: "pa-prop-breach-alert",
        role: "alert"
      }, M.createElement("b", null, "هشدار نقض قانون"), M.createElement("span", null, breachLabels.join(" · "))) : null, M.createElement("section", {
        className: "pa-card pa-prop-config"
      }, M.createElement("div", {
        className: "pa-prop-config-head"
      }, M.createElement("div", null, M.createElement("h2", null, "پروفایل چالش"), M.createElement("p", null, "درصدها نسبت به موجودی اولیه حساب محاسبه می‌شوند؛ مقدار صفر هر قانون را غیرفعال می‌کند.")), M.createElement("label", {
        className: "pa-switch-row"
      }, M.createElement("input", {
        type: "checkbox",
        checked: !!rules.enabled,
        onChange: event => set("enabled", event.target.checked),
        "aria-label": "فعال‌سازی پایش پراپ‌فرم"
      }), M.createElement("span", null), M.createElement("b", null, rules.enabled ? "پایش فعال" : "فعال‌سازی پایش"))), M.createElement("div", {
        className: "pa-prop-form-grid"
      }, M.createElement(Qe, {
        label: "نام شرکت"
      }, M.createElement("input", {
        className: "pa-input",
        value: rules.firmName,
        maxLength: 80,
        placeholder: "مثلاً FTMO",
        onChange: event => set("firmName", event.target.value)
      })), M.createElement(Qe, {
        label: "نام مرحله"
      }, M.createElement("input", {
        className: "pa-input",
        value: rules.phaseName,
        maxLength: 80,
        onChange: event => set("phaseName", event.target.value)
      })), M.createElement(Qe, {
        label: "شروع محاسبه"
      }, M.createElement("input", {
        className: "pa-input num",
        type: "date",
        value: rules.startDate,
        onChange: event => set("startDate", event.target.value)
      })), M.createElement(Qe, {
        label: "نوع افت سرمایه"
      }, M.createElement("select", {
        className: "pa-select",
        value: rules.drawdownMode,
        onChange: event => set("drawdownMode", event.target.value)
      }, M.createElement("option", {
        value: "static"
      }, "ثابت از موجودی اولیه"), M.createElement("option", {
        value: "trailing"
      }, "شناور از سقف سرمایه"))), [["dailyLossPercent", "حداکثر زیان روزانه", .1, 100], ["totalLossPercent", "حداکثر زیان کل", .1, 100], ["profitTargetPercent", "هدف سود", .1, 100], ["minTradingDays", "حداقل روز معاملاتی", 1, 3650], ["maxRiskPerTradePercent", "حداکثر ریسک هر معامله", .1, 100], ["consistencyPercent", "سقف ثبات روز سودده", 1, 100]].map(field => M.createElement(Qe, {
        label: field[1],
        key: field[0]
      }, M.createElement("div", {
        className: "pa-input-suffix"
      }, M.createElement("input", {
        className: "pa-input num",
        type: "number",
        min: "0",
        max: String(field[3]),
        step: field[2],
        inputMode: field[0] === "minTradingDays" ? "numeric" : "decimal",
        value: rules[field[0]],
        onChange: event => set(field[0], event.target.value === "" ? "" : Number(event.target.value))
      }), M.createElement("span", null, field[0] === "minTradingDays" ? "روز" : "٪"))))), M.createElement("div", {
        className: "pa-prop-scope-note"
      }, M.createElement("span", null, "مبنای چالش ", M.createElement("b", {
        className: "num"
      }, Ke(report.start))), M.createElement("span", null, report.evaluatedTrades.toLocaleString("fa-IR"), " معامله در محاسبه"), M.createElement("span", null, "برداشت ", M.createElement("b", {
        className: "num"
      }, Ke(report.withdrawals)), " فقط از موجودی کم شده است")), M.createElement("div", {
        className: "pa-prop-save-row"
      }, M.createElement("button", {
        type: "button",
        className: "pa-btn primary",
        onClick: save,
        disabled: saveState === "saving",
        "data-testid": "save-prop-rules"
      }, saveState === "saving" ? "در حال ذخیره…" : saveState === "saved" ? "ذخیره شد ✓" : "ذخیره قوانین این حساب"), M.createElement("button", {
        type: "button",
        className: "pa-btn ghost",
        onClick: reset,
        disabled: !dirty || saveState === "saving"
      }, "لغو تغییرات"), M.createElement("span", {
        className: "pa-prop-save-feedback " + saveState,
        role: saveState === "error" ? "alert" : "status"
      }, formError || (dirty ? "تغییرات این حساب هنوز ذخیره نشده‌اند." : "این تنظیمات فقط به «" + (account && account.name || "حساب فعال") + "» تعلق دارد.")))), rules.enabled ? M.createElement(M.Fragment, null, M.createElement("section", {
        className: "pa-prop-summary"
      }, M.createElement("article", null, M.createElement("span", null, "سود خالص چالش"), M.createElement("b", {
        className: "num " + (report.netProfit >= 0 ? "pos" : "neg")
      }, Ke(report.netProfit))), M.createElement("article", null, M.createElement("span", null, "روزهای ثبت‌شده"), M.createElement("b", {
        className: "num"
      }, report.days.toLocaleString("fa-IR"))), M.createElement("article", null, M.createElement("span", null, "زیان مسیر امروز"), M.createElement("b", {
        className: "num"
      }, Ke(report.todayLoss))), M.createElement("article", null, M.createElement("span", null, "بیشترین ریسک"), M.createElement("b", {
        className: "num"
      }, report.maxRisk.toFixed(2), "%"))), M.createElement("section", {
        className: "pa-prop-rules-grid"
      }, M.createElement(paRuleCard, {
        id: "daily-loss",
        kicker: "DAILY LOSS",
        title: "حد زیان روزانه",
        value: Ke(report.worstDayLoss) + " / " + Ke(report.dailyLimit),
        progress: paProgress(report.worstDayLoss, report.dailyLimit),
        breached: report.dailyBreached,
        help: "بدترین زیان محقق‌شده در مسیر یک روز؛ سود بعدی نقض قبلی را پنهان نمی‌کند"
      }), M.createElement(paRuleCard, {
        id: "total-loss",
        kicker: "DRAWDOWN",
        title: rules.drawdownMode === "trailing" ? "افت شناور سرمایه" : "زیان کل ثابت",
        value: Ke(report.totalDrawdown) + " / " + Ke(report.totalLimit),
        progress: paProgress(report.totalDrawdown, report.totalLimit),
        breached: report.totalBreached,
        help: rules.drawdownMode === "trailing" ? "بیشترین فاصله از سقف سرمایه در مسیر معاملات" : "بیشترین فاصله زیر موجودی اولیه در مسیر معاملات"
      }), M.createElement(paRuleCard, {
        id: "profit-target",
        kicker: "TARGET",
        title: "هدف سود",
        value: Ke(Math.max(0, report.netProfit)) + " / " + Ke(report.targetAmount),
        progress: paProgress(Math.max(0, report.netProfit), report.targetAmount),
        met: report.targetMet,
        help: report.targetMet ? "هدف سود محقق شده است" : "سود معاملاتی لازم برای عبور از مرحله"
      }), M.createElement(paRuleCard, {
        id: "trading-days",
        kicker: "MIN DAYS",
        title: "حداقل روز معاملاتی",
        value: report.days.toLocaleString("fa-IR") + " / " + Number(rules.minTradingDays || 0).toLocaleString("fa-IR"),
        progress: paProgress(report.days, Number(rules.minTradingDays || 0)),
        met: report.daysMet,
        help: "هر تاریخ دارای حداقل یک معامله معتبر، یک روز محسوب می‌شود"
      }), M.createElement(paRuleCard, {
        id: "risk-per-trade",
        kicker: "POSITION RISK",
        title: "ریسک هر معامله",
        value: report.maxRisk.toFixed(2) + "% / " + Number(rules.maxRiskPerTradePercent || 0).toFixed(2) + "%",
        progress: paProgress(report.maxRisk, Number(rules.maxRiskPerTradePercent || 0)),
        breached: report.riskBreached,
        help: "بیشترین درصد ریسک ثبت‌شده برای معاملات این بازه"
      }), M.createElement(paRuleCard, {
        id: "consistency",
        kicker: "CONSISTENCY",
        title: "قانون ثبات سود",
        value: report.consistency.toFixed(1) + "% / " + Number(rules.consistencyPercent || 0).toFixed(1) + "%",
        progress: paProgress(report.consistency, Number(rules.consistencyPercent || 0)),
        breached: report.consistencyBreached,
        help: "سهم بزرگ‌ترین روز سودده از مجموع سود روزهای مثبت"
      }))) : M.createElement("div", {
        className: "pa-feature-empty pa-prop-disabled"
      }, M.createElement("b", null, "پایش این حساب غیرفعال است"), M.createElement("p", null, "کلید فعال‌سازی را روشن کن، حدود شرکت را وارد کن و دکمه ذخیره را بزن.")))
    }
    registry["prop"] = paPropFirmCenter;
  }
})();
