/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paSetHero({
      userName,
      accounts,
      trades,
      settings,
      equity
    }) {
      const n = accounts.length,
        c = trades.length;
      const first = trades.reduce(function(a, t) {
        const d = t.entryDate ? new Date(t.entryDate) : null;
        if (!d || isNaN(d)) return a;
        return (!a || d < a) ? d : a;
      }, null);
      const days = first ? Math.max(1, Math.round((Date.now() - first.getTime()) / 864e5)) : 0;
      return d.jsxs("div", {
        className: "pa-set-hero",
        children: [d.jsx("div", {
          className: "pa-set-hero-glow",
          "aria-hidden": "true"
        }), d.jsxs("div", {
          className: "pa-set-hero-main",
          children: [d.jsxs("div", {
            className: "pa-set-hero-badge",
            children: [d.jsx(r$, {
              size: 13
            }), " مرکز تنظیمات"]
          }), d.jsxs("div", {
            className: "pa-set-hero-title",
            children: ["سلام ", userName, " 👋"]
          }), d.jsx("div", {
            className: "pa-set-hero-sub",
            children: "اینجا قلب ژورنالته: قوانین ریسک، حساب‌ها، پشتیبان‌گیری و ظاهر برنامه رو از همین صفحه تنظیم کن."
          })]
        }), d.jsxs("div", {
          className: "pa-set-hero-stats",
          children: [d.jsxs("div", {
            className: "pa-set-hstat",
            children: [d.jsx("div", {
              className: "pa-set-hstat-ic",
              children: d.jsx(Sy, {
                size: 15
              })
            }), d.jsxs("div", {
              children: [d.jsx("div", {
                className: "pa-set-hstat-v num",
                children: Ke(equity)
              }), d.jsx("div", {
                className: "pa-set-hstat-l",
                children: "موجودی کل"
              })]
            })]
          }), d.jsxs("div", {
            className: "pa-set-hstat",
            children: [d.jsx("div", {
              className: "pa-set-hstat-ic",
              children: d.jsx(Gf, {
                size: 15
              })
            }), d.jsxs("div", {
              children: [d.jsx("div", {
                className: "pa-set-hstat-v num",
                children: c
              }), d.jsx("div", {
                className: "pa-set-hstat-l",
                children: "معامله ثبت‌شده"
              })]
            })]
          }), d.jsxs("div", {
            className: "pa-set-hstat",
            children: [d.jsx("div", {
              className: "pa-set-hstat-ic",
              children: d.jsx(Yh, {
                size: 15
              })
            }), d.jsxs("div", {
              children: [d.jsx("div", {
                className: "pa-set-hstat-v num",
                children: n
              }), d.jsx("div", {
                className: "pa-set-hstat-l",
                children: "حساب فعال"
              })]
            })]
          }), d.jsxs("div", {
            className: "pa-set-hstat",
            children: [d.jsx("div", {
              className: "pa-set-hstat-ic",
              children: d.jsx(KE, {
                size: 15
              })
            }), d.jsxs("div", {
              children: [d.jsx("div", {
                className: "pa-set-hstat-v num",
                children: days
              }), d.jsx("div", {
                className: "pa-set-hstat-l",
                children: "روز از شروع"
              })]
            })]
          })]
        })]
      });
    }
    
    function paSetNav({
      active,
      onGo
    }) {
      return d.jsx("div", {
        className: "pa-set-nav",
        children: PA_SET_SECS.map(function(x) {
          const I = x.icon;
          return d.jsxs("button", {
            type: "button",
            className: "pa-set-nav-btn" + (active === x.id ? " active" : ""),
            onClick: function() {
              onGo(x.id);
            },
            children: [d.jsx(I, {
              size: 14
            }), d.jsx("span", {
              children: x.label
            })]
          }, x.id);
        })
      });
    }
    
    function paAccCard({
      acc,
      row,
      trades,
      onField,
      onWithdraw,
      onDeleteWithdrawal,
      confirmId,
      setConfirmId,
      onDelete,
      canDelete,
      isActive
    }) {
      const [withdrawAmount, setWithdrawAmount] = M.useState(""),
        [withdrawError, setWithdrawError] = M.useState("");
      const pts = trades.filter(function(t) {
        return t.accountId === acc.id;
      }).slice().sort(function(a, b) {
        return new Date(a.entryDate) - new Date(b.entryDate);
      });
      let run = 0;
      const eq = pts.map(function(t) {
        run += wr(t);
        return run;
      });
      const mn = Math.min(0, Math.min.apply(null, eq.concat([0]))),
        mx = Math.max(0, Math.max.apply(null, eq.concat([0]))),
        rng = (mx - mn) || 1;
      const path = eq.length > 1 ? eq.map(function(v, i) {
        return (i ? "L" : "M") + (i / (eq.length - 1) * 100).toFixed(2) + " " + (28 - (v - mn) / rng * 26).toFixed(2);
      }).join(" ") : "";
      const pos = row.net >= 0,
        withdrawals = (Array.isArray(acc.withdrawals) ? acc.withdrawals : []).slice().sort(function(a, b) {
          return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
        });
    
      function submitWithdrawal() {
        const amount = Number(withdrawAmount);
        if (!Number.isFinite(amount) || amount <= 0) {
          setWithdrawError("یک مبلغ معتبر و بزرگ‌تر از صفر وارد کن");
          return
        }
        if (amount > row.current + .000001) {
          setWithdrawError("مبلغ برداشت از موجودی فعلی بیشتر است");
          return
        }
        if (onWithdraw(acc.id, amount)) {
          setWithdrawAmount("");
          setWithdrawError("")
        }
      }
    
      function formatWithdrawalDate(item) {
        const date = new Date(item.createdAt || item.date || 0);
        return isNaN(date) ? "بدون تاریخ" : date.toLocaleDateString("fa-IR", {
          year: "numeric",
          month: "short",
          day: "numeric"
        })
      }
      return d.jsxs("div", {
        className: "pa-acc-card" + (isActive ? " active" : "") + (pos ? " pos" : " neg"),
        children: [d.jsxs("div", {
          className: "pa-acc-card-top",
          children: [d.jsxs("div", {
            className: "pa-acc-card-id",
            children: [d.jsx("span", {
              className: "pa-acc-avatar",
              children: (acc.name || "?").trim().charAt(0)
            }), isActive ? d.jsx("span", {
              className: "pa-acc-live",
              children: "فعال"
            }) : null]
          }), canDelete ? (confirmId === acc.id ? d.jsxs("div", {
            className: "pa-confirm pa-acc-confirm",
            children: [d.jsx("button", {
              className: "pa-btn danger sm",
              onClick: function() {
                onDelete(acc.id);
              },
              children: "حذف قطعی"
            }), d.jsx("button", {
              className: "pa-btn ghost sm",
              onClick: function() {
                setConfirmId(null);
              },
              children: "انصراف"
            })]
          }) : d.jsx("button", {
            className: "pa-btn ghost sm pa-acc-del",
            title: "حذف حساب",
            onClick: function() {
              setConfirmId(acc.id);
            },
            children: d.jsx(kc, {
              size: 14
            })
          })) : null]
        }), eq.length > 1 ? d.jsx("svg", {
          className: "pa-acc-spark",
          viewBox: "0 0 100 30",
          preserveAspectRatio: "none",
          "aria-hidden": "true",
          children: d.jsx("path", {
            d: path,
            fill: "none",
            stroke: pos ? "#22c55e" : "#f87171",
            "stroke-width": "1.8",
            "stroke-linejoin": "round",
            "stroke-linecap": "round"
          })
        }) : d.jsx("div", {
          className: "pa-acc-spark empty"
        }), d.jsxs("div", {
          className: "pa-acc-fields",
          children: [d.jsx(Qe, {
            label: "نام حساب",
            children: d.jsx("input", {
              className: "pa-input",
              value: acc.name,
              onChange: function(e) {
                onField(acc.id, "name", e.target.value);
              }
            })
          }), d.jsx(Qe, {
            label: "موجودی اولیه",
            children: d.jsx("input", {
              className: "pa-input",
              type: "number",
              value: acc.startingBalance,
              onChange: function(e) {
                onField(acc.id, "startingBalance", Number(e.target.value) || 0);
              }
            })
          })]
        }), d.jsxs("div", {
          className: "pa-acc-metrics",
          children: [d.jsxs("div", {
            className: "pa-acc-metric",
            children: [d.jsx("span", {
              className: "pa-acc-metric-l",
              children: "موجودی فعلی"
            }), d.jsx("span", {
              className: "pa-acc-metric-v num",
              children: Ke(row.current)
            })]
          }), d.jsxs("div", {
            className: "pa-acc-metric",
            children: [d.jsx("span", {
              className: "pa-acc-metric-l",
              children: "خالص معاملات"
            }), d.jsx("span", {
              className: "pa-acc-metric-v num " + (pos ? "pos" : "neg"),
              children: Ke(row.net)
            })]
          }), d.jsxs("div", {
            className: "pa-acc-metric",
            children: [d.jsx("span", {
              className: "pa-acc-metric-l",
              children: "معاملات"
            }), d.jsx("span", {
              className: "pa-acc-metric-v num",
              children: row.count
            })]
          }), d.jsxs("div", {
            className: "pa-acc-metric",
            children: [d.jsx("span", {
              className: "pa-acc-metric-l",
              children: "وین‌ریت"
            }), d.jsxs("span", {
              className: "pa-acc-metric-v num " + (row.winRate >= 50 ? "pos" : "neg"),
              children: [row.winRate.toFixed(0), "%"]
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-withdraw-box",
          children: [d.jsxs("div", {
            className: "pa-withdraw-head",
            children: [d.jsx("span", {
              className: "pa-withdraw-title",
              children: "ثبت برداشت"
            }), d.jsxs("span", {
              className: "pa-withdraw-total num",
              children: ["جمع: ", Ke(row.withdrawn || 0)]
            })]
          }), d.jsxs("div", {
            className: "pa-withdraw-form",
            children: [d.jsx("input", {
              className: "pa-input",
              type: "number",
              min: "0",
              step: "any",
              inputMode: "decimal",
              placeholder: "مبلغ برداشت",
              value: withdrawAmount,
              onChange: function(e) {
                setWithdrawAmount(e.target.value);
                withdrawError && setWithdrawError("");
              },
              onKeyDown: function(e) {
                e.key === "Enter" && submitWithdrawal();
              }
            }), d.jsx("button", {
              type: "button",
              className: "pa-btn primary sm",
              onClick: submitWithdrawal,
              disabled: row.current <= 0,
              children: "ثبت برداشت"
            })]
          }), withdrawError ? d.jsx("div", {
            className: "pa-withdraw-error",
            children: withdrawError
          }) : null, d.jsx("div", {
            className: "pa-withdraw-note",
            children: "برداشت فقط موجودی حساب را کم می‌کند و روی معاملات و آمار عملکرد اثری ندارد."
          }), withdrawals.length ? d.jsx("div", {
            className: "pa-withdraw-history",
            children: withdrawals.map(function(item) {
              return d.jsxs("div", {
                className: "pa-withdraw-row",
                children: [d.jsxs("div", {
                  className: "pa-withdraw-row-main",
                  children: [d.jsx("span", {
                    className: "pa-withdraw-amount num",
                    children: Ke(-Math.abs(Number(item.amount) || 0))
                  }), d.jsx("span", {
                    className: "pa-withdraw-date",
                    children: formatWithdrawalDate(item)
                  })]
                }), d.jsx("button", {
                  type: "button",
                  className: "pa-withdraw-remove",
                  title: "حذف برداشت",
                  "aria-label": "حذف برداشت",
                  onClick: function() {
                    window.confirm("این برداشت حذف شود؟") && onDeleteWithdrawal(acc.id, item.id);
                  },
                  children: "×"
                })]
              }, item.id || item.createdAt);
            })
          }) : null]
        })]
      });
    }
    
    const PA_THEMES = [{
      id: "dark",
      label: "تیره",
      note: "پیش‌فرض؛ مناسب اتاق کم‌نور"
    }, {
      id: "light",
      label: "روشن",
      note: "مناسب نور روز و پرینت"
    }, {
      id: "auto",
      label: "خودکار",
      note: "هماهنگ با سیستم"
    }];
    
    function paThemeCard() {
      const [t, setT] = M.useState(function() {
        try {
          return localStorage.getItem("pa-theme") || "dark";
        } catch (e) {
          return "dark";
        }
      });
      M.useEffect(function() {
        function sync() {
          try {
            setT(localStorage.getItem("pa-theme") || "dark");
          } catch (e) {}
        }
        window.addEventListener("pa-theme-change", sync);
        return function() {
          window.removeEventListener("pa-theme-change", sync);
        };
      }, []);
    
      function pick(id) {
        setT(id);
        window.dispatchEvent(new CustomEvent("pa-theme-set", {
          detail: id
        }));
      }
      return d.jsxs("div", {
        className: "pa-card pa-set-card",
        id: "pa-set-appearance",
        children: [d.jsxs("div", {
          className: "pa-card-title",
          children: [d.jsx(o$, {
            size: 15,
            style: {
              verticalAlign: "-2px"
            }
          }), " ظاهر برنامه"]
        }), d.jsx("div", {
          className: "pa-card-note",
          style: {
            marginBottom: 14
          },
          children: "پوسته‌ی روشن و تیره هر دو کامل پشتیبانی می‌شن. انتخابت ذخیره می‌شه و دفعه‌ی بعد هم همین می‌مونه — با کلید میان‌بر Ctrl+J هم می‌تونی سریع عوضش کنی."
        }), d.jsx("div", {
          className: "pa-theme-grid",
          children: PA_THEMES.map(function(x) {
            return d.jsxs("button", {
              type: "button",
              className: "pa-theme-opt " + x.id + (t === x.id ? " active" : ""),
              onClick: function() {
                pick(x.id);
              },
              children: [d.jsxs("span", {
                className: "pa-theme-prev",
                "aria-hidden": "true",
                children: [d.jsx("span", {
                  className: "pa-theme-prev-bar"
                }), d.jsx("span", {
                  className: "pa-theme-prev-l1"
                }), d.jsx("span", {
                  className: "pa-theme-prev-l2"
                })]
              }), d.jsxs("span", {
                className: "pa-theme-meta",
                children: [d.jsxs("span", {
                  className: "pa-theme-name",
                  children: [x.label, t === x.id ? d.jsx(oa, {
                    size: 13
                  }) : null]
                }), d.jsx("span", {
                  className: "pa-theme-note",
                  children: x.note
                })]
              })]
            }, x.id);
          })
        })]
      });
    }
    
    function PZ({
      settings: e,
      onSaveSettings: t,
      accounts: n,
      trades: r,
      updateAccountField: a,
      onWithdrawAccount: paWithdrawAccount,
      onDeleteWithdrawal: paDeleteWithdrawal,
      confirmDeleteAccId: i,
      setConfirmDeleteAccId: o,
      onDeleteAccount: l,
      confirmReset: s,
      setConfirmReset: u,
      onResetAll: f,
      tradeCount: c,
      onExportBackup: p,
      backingUp: h,
      onRestoreFile: v,
      pendingRestore: b,
      setPendingRestore: m,
      restoreError: g,
      setRestoreError: x,
      onConfirmRestore: y,
      restoring: O,
      activeAccountId: paAct
    }) {
      var $, L;
      const [w, S] = M.useState(e.userName || ""), [j, k] = M.useState(String(e.dailyLossLimitPercent ?? 3)), [P, E] = M.useState(String(e
        .dailyProfitTargetPercent ?? 5)), [paTzSel, paSetTzSel] = M.useState(e.importTimezone || "local"), N = M.useMemo(() => kZ(n, r), [n, r]);
      const [paSec, paSetSec] = M.useState("profile");
      const paDirty = w !== (e.userName || "") || j !== String(e.dailyLossLimitPercent ?? 3) || P !== String(e.dailyProfitTargetPercent ?? 5) || paTzSel !== (e.importTimezone || "local");
      const paEquity = N.reduce(function(A, q) {
        return A + q.current;
      }, 0);
      const paActRow = N.filter(function(q) {
        return q.id === paAct;
      })[0] || N[0] || {
        current: 0
      };
      M.useEffect(function() {
        const ids = PA_SET_SECS.map(function(q) {
          return "pa-set-" + q.id;
        });
    
        function onScroll() {
          let best = null,
            bd = 1 / 0;
          ids.forEach(function(id) {
            const el = document.getElementById(id);
            if (!el) return;
            const dd = Math.abs(el.getBoundingClientRect().top - 120);
            if (dd < bd) {
              bd = dd;
              best = id;
            }
          });
          if (best) paSetSec(best.replace("pa-set-", ""));
        }
        window.addEventListener("scroll", onScroll, {
          passive: !0
        });
        onScroll();
        return function() {
          window.removeEventListener("scroll", onScroll);
        };
      }, []);
    
      function paGo(id) {
        const el = document.getElementById("pa-set-" + id);
        if (el) el.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
        paSetSec(id);
      }
      return d.jsxs("div", {
        className: "pa-form-wrap pa-settings-wrap",
        children: [d.jsx(paSetHero, {
          userName: (e.userName || "تریدر"),
          accounts: n,
          trades: r,
          settings: e,
          equity: paEquity
        }), d.jsx(paSetNav, {
          active: paSec,
          onGo: paGo
        }), d.jsxs("div", {
          className: "pa-card pa-set-card",
          id: "pa-set-profile",
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(Gf, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " شخصی‌سازی و مدیریت ریسک"]
          }), d.jsx("div", {
            className: "pa-card-note",
            style: {
              marginBottom: 14
            },
            children: "این دو عدد، ترمز و ترمزدست روزانه‌ات هستن. وقتی بهشون برسی، برنامه بهت هشدار می‌ده تا احساسی ادامه ندی."
          }), d.jsxs("div", {
            className: "pa-form-grid",
            children: [d.jsx(Qe, {
              label: "اسم شما",
              hint: "توی پیام‌ها و داشبورد باهات همین‌طوری حرف می‌زنیم",
              children: d.jsx("input", {
                type: "text",
                className: "pa-input",
                value: w,
                onChange: D => S(D.target.value)
              })
            }), d.jsx(Qe, {
              label: "سقف ضرر مجاز روزانه (%)",
              hint: "رسیدن به این عدد یعنی امروز تمومه",
              children: d.jsx("input", {
                type: "number",
                step: "0.5",
                className: "pa-input",
                value: j,
                onChange: D => k(D.target.value)
              })
            }), d.jsx(Qe, {
              label: "حد سود روزانه (%)",
              hint: "وقتی سود امروزت به این درصد برسه، بهت پیام میدیم که همون‌جا معامله رو ببندی",
              children: d.jsx("input", {
                type: "number",
                step: "0.5",
                className: "pa-input",
                value: P,
                onChange: D => E(D.target.value)
              })
            }), d.jsx(Qe, {
              label: "منطقهٔ زمانی سرور بروکر (ورود از متاتریدر)",
              hint: "ساعت داخل فایل MT4/MT5 ساعت سرور بروکر است؛ با انتخاب درست، سشن معاملات واردشده دقیق می‌شود.",
              children: d.jsx("select", {
                className: "pa-input",
                value: paTzSel,
                onChange: D => paSetTzSel(D.target.value),
                children: PA_IMPORT_TZ_OPTIONS.map(D => d.jsx("option", {
                  value: D.id,
                  children: D.label
                }, D.id))
              })
            })]
          }), d.jsx(paRiskBar, {
            balance: paActRow.current || 0,
            lossPct: j,
            profitPct: P
          }), d.jsxs("div", {
            className: "pa-form-actions pa-set-actions",
            style: {
              marginTop: 14
            },
            children: [d.jsxs("button", {
              className: "pa-btn primary" + (paDirty ? " pa-set-save-dirty" : ""),
              onClick: () => t({
                ...e,
                userName: w.trim() || "تریدر",
                dailyLossLimitPercent: Number(j) || 3,
                dailyProfitTargetPercent: Number(P) || 0,
                importTimezone: paTzSel || "local"
              }),
              children: [d.jsx(oa, {
                size: 14
              }), " ذخیره"]
            }), paDirty ? d.jsx("span", {
              className: "pa-set-dirty-hint",
              children: "تغییرات ذخیره نشده"
            }) : null]
          })]
        }), d.jsxs("div", {
          className: "pa-card pa-set-card",
          id: "pa-set-accounts",
          children: [d.jsxs("div", {
            className: "pa-card-head-row",
            children: [d.jsxs("div", {
              className: "pa-card-title",
              style: {
                marginBottom: 0
              },
              children: [d.jsx(Sy, {
                size: 15,
                style: {
                  verticalAlign: "-2px"
                }
              }), " حساب‌های معاملاتی"]
            }), d.jsxs("span", {
              className: "pa-set-count",
              children: [d.jsx("b", {
                className: "num",
                children: n.length
              }), " حساب"]
            })]
          }), d.jsx("div", {
            className: "pa-card-note",
            style: {
              margin: "10px 0 14px"
            },
            children: "هر حساب آمار و نمودار مستقل خودش رو داره. نمودار کوچک هر کارت، منحنی رشد سرمایه‌ی همون حسابه."
          }), d.jsx("div", {
            className: "pa-acc-grid",
            children: n.map(function(D) {
              const row = N.filter(function(q) {
                return q.id === D.id;
              })[0] || {
                current: Number(D.startingBalance) || 0,
                net: 0,
                count: 0,
                winRate: 0
              };
              return d.jsx(paAccCard, {
                acc: D,
                row: row,
                trades: r,
                onField: a,
                onWithdraw: paWithdrawAccount,
                onDeleteWithdrawal: paDeleteWithdrawal,
                confirmId: i,
                setConfirmId: o,
                onDelete: l,
                canDelete: n.length > 1,
                isActive: D.id === paAct
              }, D.id);
            })
          }), n.length > 1 ? d.jsxs("div", {
            className: "pa-accounts-compare pa-set-compare",
            children: [d.jsxs("div", {
              className: "pa-compare-row pa-compare-head",
              children: [d.jsx("span", {
                children: "حساب"
              }), d.jsx("span", {
                children: "موجودی فعلی"
              }), d.jsx("span", {
                children: "سود/زیان خالص"
              }), d.jsx("span", {
                children: "معاملات"
              }), d.jsx("span", {
                children: "وین‌ریت"
              })]
            }), N.map(D => d.jsxs("div", {
              className: "pa-compare-row" + (D.id === paAct ? " active" : ""),
              children: [d.jsx("span", {
                className: "pa-compare-name",
                children: D.name
              }), d.jsx("span", {
                className: "num",
                children: Ke(D.current)
              }), d.jsx("span", {
                className: "num" + (D.net >= 0 ? " pos" : " neg"),
                children: Ke(D.net)
              }), d.jsx("span", {
                className: "num",
                children: D.count
              }), d.jsxs("span", {
                className: "num" + (D.winRate >= 50 ? " pos" : " neg"),
                children: [D.winRate.toFixed(0), "%"]
              })]
            }, D.id))]
          }) : null]
        }), d.jsx(paThemeCard, {}), d.jsxs("div", {
          className: "pa-card pa-set-card",
          id: "pa-set-backup",
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(Gh, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " بک‌آپ و بازیابی"]
          }), d.jsx("div", {
            className: "pa-card-note",
            style: {
              marginBottom: 14
            },
            children: "همه معاملات، حساب‌ها، تنظیمات، چک‌لیست‌ها، یادداشت‌های مرور و تصاویر چارت در یک فایل JSON ذخیره می‌شن. این فایل رو یه جای امن (گوگل‌درایو، ایمیل خودت) نگه دار."
          }), d.jsxs("div", {
            className: "pa-backup-row",
            children: [d.jsxs("div", {
              className: "pa-backup-tile",
              children: [d.jsx("div", {
                className: "pa-backup-ic dl",
                children: d.jsx(Gh, {
                  size: 18
                })
              }), d.jsxs("div", {
                className: "pa-backup-body",
                children: [d.jsx("div", {
                  className: "pa-backup-t",
                  children: "گرفتن بک‌آپ"
                }), d.jsxs("div", {
                  className: "pa-backup-s",
                  children: ["یک فایل شامل ", d.jsx("b", {
                    className: "num",
                    children: r.length
                  }), " معامله"]
                })]
              }), d.jsx("button", {
                className: "pa-btn primary",
                onClick: p,
                disabled: h,
                children: h ? "در حال آماده‌سازی…" : "دانلود"
              })]
            }), d.jsxs("div", {
              className: "pa-backup-tile",
              children: [d.jsx("div", {
                className: "pa-backup-ic up",
                children: d.jsx(i$, {
                  size: 18
                })
              }), d.jsxs("div", {
                className: "pa-backup-body",
                children: [d.jsx("div", {
                  className: "pa-backup-t",
                  children: "بازیابی از فایل"
                }), d.jsx("div", {
                  className: "pa-backup-s",
                  children: "جایگزینی کامل داده‌های فعلی"
                })]
              }), d.jsxs("label", {
                className: "pa-btn ghost",
                style: {
                  cursor: "pointer"
                },
                children: ["انتخاب فایل", d.jsx("input", {
                  type: "file",
                  accept: "application/json,.json",
                  onChange: v,
                  style: {
                    display: "none"
                  }
                })]
              })]
            })]
          }), g && d.jsxs("div", {
            className: "pa-set-alert err",
            children: [d.jsx(Ac, {
              size: 14
            }), d.jsx("span", {
              children: g
            })]
          }), b && d.jsxs("div", {
            className: "pa-confirm pa-set-restore",
            children: [d.jsxs("span", {
              children: ["این فایل شامل ", d.jsx("b", {
                className: "num",
                children: (($ = b.trades) == null ? void 0 : $.length) ?? 0
              }), " معامله و ", d.jsx("b", {
                className: "num",
                children: ((L = b.accounts) == null ? void 0 : L.length) ?? 0
              }), " حساب است", b.exportedAt ? d.jsxs(d.Fragment, {
                children: [" (تاریخ تهیه بک‌آپ: ", d.jsx("b", {
                  className: "num",
                  children: Cg(b.exportedAt)
                }), ")"]
              }) : null, ". بازیابی، همه داده‌های فعلی رو با محتوای این فایل جایگزین می‌کنه و برگشت‌پذیر نیست. مطمئنی؟"]
            }), d.jsxs("div", {
              style: {
                display: "flex",
                gap: 8
              },
              children: [d.jsx("button", {
                className: "pa-btn danger sm",
                onClick: y,
                disabled: O,
                children: O ? "در حال بازیابی…" : "بله، جایگزین کن"
              }), d.jsx("button", {
                className: "pa-btn ghost sm",
                onClick: () => m(null),
                disabled: O,
                children: "انصراف"
              })]
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-card pa-set-card pa-set-danger",
          id: "pa-set-data",
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(Ac, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " مدیریت داده‌ها"]
          }), d.jsxs("div", {
            className: "pa-card-note",
            style: {
              marginBottom: 12
            },
            children: ["در حال حاضر ", d.jsx("b", {
              className: "num",
              children: c
            }), " معامله برای این حساب ذخیره شده است. قبل از پاک کردن، حتماً یک بک‌آپ بگیر."]
          }), s ? d.jsxs("div", {
            className: "pa-confirm",
            children: [d.jsx("span", {
              children: "همه معاملات این حساب برای همیشه پاک می‌شوند. مطمئنی؟"
            }), d.jsx("button", {
              className: "pa-btn danger sm",
              onClick: f,
              children: "بله، پاک کن"
            }), d.jsx("button", {
              className: "pa-btn ghost sm",
              onClick: () => u(!1),
              children: "انصراف"
            })]
          }) : d.jsxs("button", {
            className: "pa-btn danger",
            onClick: () => u(!0),
            children: [d.jsx(kc, {
              size: 14
            }), " پاک کردن معاملات این حساب"]
          })]
        })]
      });
    }
    registry["settings"] = PZ;
  }
})();
