/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paClamp(e, t = 0, n = 100) {
      return Math.max(t, Math.min(n, Number(e) || 0))
    }
    
    function paGroupPerformance(e, t) {
      const n = {};
      return e.forEach(r => {
        const a = t(r);
        if (!a) return;
        n[a] || (n[a] = {
          key: a,
          count: 0,
          wins: 0,
          net: 0
        }), n[a].count += 1, n[a].net += wr(r), r.resultType === "profit" && (n[a].wins += 1)
      }), Object.values(n).map(r => ({
        ...r,
        winRate: r.count ? r.wins / r.count * 100 : 0,
        expectancy: r.count ? r.net / r.count : 0
      }))
    }
    
    function paSmartInsights(e, t) {
      const n = [...e].filter(R => R.entryDate && !isNaN(new Date(R.entryDate))).sort((R, B) => new Date(R.entryDate) - new Date(B.entryDate)),
        r = Number(t.maxRiskPerTrade || 1),
        a = Number(t.maxTradesPerDay || 4),
        i = [],
        o = paGroupPerformance(n, R => (R.setupName || "").trim()),
        l = paGroupPerformance(n, R => new Date(R.entryDate).toLocaleDateString("fa-IR", {
          weekday: "long"
        })),
        s = paGroupPerformance(n, R => Tg(R.entryDate)),
        u = paGroupPerformance(n, R => R.pre && R.pre.emotionBefore),
        f = paGroupPerformance(n, R => R.post && Array.isArray(R.post.mistakes) && R.post.mistakes.length ? R.post.mistakes[0] : ""),
        c = o.filter(R => R.count >= 3).sort((R, B) => B.expectancy - R.expectancy),
        p = l.filter(R => R.count >= 3).sort((R, B) => R.expectancy - B.expectancy),
        h = s.filter(R => R.count >= 3).sort((R, B) => B.expectancy - R.expectancy),
        v = u.filter(R => R.count >= 3).sort((R, B) => R.expectancy - B.expectancy),
        b = {},
        m = [];
      n.forEach(R => {
        const B = vr(new Date(R.entryDate));
        b[B] || (b[B] = []), b[B].push(R)
      }), Object.entries(b).forEach(([R, B]) => B.length > a && m.push({
        date: R,
        count: B.length,
        net: B.reduce((_, C) => _ + wr(C), 0)
      }));
      let g = 0,
        x = 0;
      for (let R = 1; R < n.length; R++) {
        const B = n[R - 1],
          _ = n[R],
          C = (new Date(_.entryDate) - new Date(B.entryDate)) / 60000;
        B.resultType === "loss" && C >= 0 && C <= 30 && (g += 1, _.resultType === "loss" && (x += 1))
      }
      const y = n.filter(R => Number(R.riskPercent) > r).length,
        O = n.filter(R => R.pre && R.pre.matchesPlan === !1),
        w = n.filter(R => R.pre && R.pre.matchesPlan === !0),
        S = R => R.length ? R.reduce((B, _) => B + wr(_), 0) / R.length : 0;
      c[0] && i.push({
        tone: "good",
        title: `لبه آماری در ستاپ «${c[0].key}»`,
        text: `در ${c[0].count} نمونه، نرخ برد ${c[0].winRate.toFixed(0)}٪ و امید ریاضی ${Ke(c[0].expectancy)} به‌ازای هر معامله ثبت شده است.`,
        action: "این ستاپ را با همان شرایط معتبر در پلن برجسته کن."
      });
      p[0] && p[0].expectancy < 0 && i.push({
        tone: "warn",
        title: `${p[0].key}، روز پرریسک توست`,
        text: `در ${p[0].count} معامله، میانگین نتیجه ${Ke(p[0].expectancy)} بوده است.`,
        action: "در این روز حجم را کمتر کن یا فقط ستاپ‌های درجه A را بگیر."
      });
      h[0] && i.push({
        tone: "good",
        title: `بهترین تمرکز در سشن ${h[0].key}`,
        text: `${h[0].count} معامله با نرخ برد ${h[0].winRate.toFixed(0)}٪ و خالص ${Ke(h[0].net)}.`,
        action: "زمان آماده‌سازی قبل از این سشن را ثابت نگه دار."
      });
      v[0] && v[0].expectancy < 0 && i.push({
        tone: "danger",
        title: `هشدار حالت روانی «${v[0].key}»`,
        text: `این حالت در ${v[0].count} معامله با میانگین ${Ke(v[0].expectancy)} همراه بوده است.`,
        action: "این احساس را به‌عنوان تریگر توقف ۱۵ دقیقه‌ای تعریف کن."
      });
      w.length >= 3 && O.length >= 3 && i.push({
        tone: S(w) >= S(O) ? "good" : "warn",
        title: "اثر پایبندی به پلن قابل اندازه‌گیری است",
        text: `میانگین معاملات طبق پلن ${Ke(S(w))} و خارج از پلن ${Ke(S(O))} است.`,
        action: S(w) >= S(O) ? "قبل از سفارش، تیک «مطابق پلن» را اجباری کن." : "تعریف پلن یا نحوه برچسب‌گذاری را بازبینی کن."
      });
      g >= 2 && i.push({
        tone: x / g >= .45 ? "danger" : "warn",
        title: "الگوی ورود سریع بعد از ضرر",
        text: `${g} بار در کمتر از ۳۰ دقیقه پس از ضرر دوباره وارد شدی؛ ${x} مورد آن دوباره زیان‌ده بوده است.`,
        action: "پس از هر ضرر، قانون Cool-down سی‌دقیقه‌ای اجرا کن."
      });
      m.length && i.push({
        tone: "warn",
        title: "نشانه‌های Overtrading",
        text: `${m.length} روز بیشتر از سقف ${a} معامله داشتی؛ خالص این روزها ${Ke(m.reduce((R,B)=>R+B.net,0))} بوده است.`,
        action: "بعد از رسیدن به سقف روزانه، ثبت سفارش جدید را متوقف کن."
      });
      y && i.push({
        tone: "danger",
        title: "عبور از ریسک مجاز هر معامله",
        text: `${y} معامله ریسک ثبت‌شده‌ای بالاتر از ${r}٪ داشته‌اند.`,
        action: "قبل از ورود، حجم را با ماشین‌حساب ریسک همین صفحه محاسبه کن."
      });
      f.filter(R => R.count >= 2).sort((R, B) => B.count - R.count)[0] && (() => {
        const R = f.filter(B => B.count >= 2).sort((B, _) => _.count - B.count)[0];
        i.push({
          tone: "warn",
          title: `اشتباه پرتکرار: ${R.key}`,
          text: `${R.count} بار ثبت شده و نتیجه خالص مرتبط ${Ke(R.net)} است.`,
          action: "برای این خطا یک بند مشخص به چک‌لیست قبل از معامله اضافه کن."
        })
      })();
      if (n.length < 3) i.push({
        tone: "info",
        title: "داده بیشتری برای تحلیل لازم است",
        text: "با حداقل ۳ معامله، اولین الگوها فعال می‌شوند؛ برای اعتماد بالا بهتر است ۳۰ نمونه داشته باشی.",
        action: "تاریخچه MetaTrader را وارد کن یا معاملات جدید را کامل ثبت کن."
      });
      let k = 100;
      k -= Math.min(22, y * 4), k -= Math.min(18, m.length * 5), k -= Math.min(18, O.length * 2), g && (k -= Math.min(16, Math.round(x / g * 20)));
      const P = n.length >= 50 ? 92 : n.length >= 30 ? 80 : n.length >= 15 ? 64 : n.length >= 8 ? 48 : Math.max(15, n.length * 6),
        E = i.slice(0, 8);
      return {
        count: n.length,
        score: paClamp(Math.round(k)),
        confidence: P,
        confidenceLabel: P >= 80 ? "بالا" : P >= 50 ? "متوسط" : "اولیه",
        insights: E,
        rapidAfterLoss: g,
        rapidLosses: x,
        riskBreaches: y,
        overtradeDays: m.length
      }
    }
    
    function paRiskMeter({
      label: e,
      value: t,
      max: n,
      unit: r = "",
      inverse: a = !1
    }) {
      const i = n > 0 ? paClamp(t / n * 100) : 0,
        o = a ? i < 65 ? "good" : i < 90 ? "warn" : "bad" : i >= 100 ? "good" : i >= 70 ? "warn" : "bad";
      return M.createElement("div", {
          className: "pa-risk-meter " + o
        }, M.createElement("div", {
          className: "pa-risk-meter-head"
        }, M.createElement("span", null, e), M.createElement("b", {
          className: "num"
        }, Number(t || 0).toFixed(r === "%" ? 2 : 0), r, " / ", Number(n || 0).toFixed(r === "%" ? 2 : 0), r)), M.createElement("div", {
          className: "pa-risk-meter-track"
        }, M.createElement("i", {
          style: {
            width: Math.min(100, i) + "%"
          }
        })))
    }
    
    function paRiskCenter({
      trades: e,
      account: t,
      balance: n,
      settings: r,
      onSaveSettings: a
    }) {
      const [i, o] = M.useState(() => ({
          maxRiskPerTrade: Number(r.maxRiskPerTrade || 1),
          dailyLossLimitPercent: Number(r.dailyLossLimitPercent || 3),
          maxTradesPerDay: Number(r.maxTradesPerDay || 4),
          maxConsecutiveLosses: Number(r.maxConsecutiveLosses || 3),
          maxWeeklyLossPercent: Number(r.maxWeeklyLossPercent || 6)
        })), [l, s] = M.useState({
          riskPercent: Number(r.maxRiskPerTrade || 1),
          stopDistance: 25,
          pipValue: 10
        }), [u, f] = M.useState(!1),
        c = paSmartInsights(e, i),
        p = e.filter(E => kv(E.entryDate, "daily")),
        h = e.filter(E => kv(E.entryDate, "weekly")),
        v = Math.abs(Math.min(0, p.reduce((E, N) => E + wr(N), 0))),
        b = Math.abs(Math.min(0, h.reduce((E, N) => E + wr(N), 0))),
        m = Math.max(0, Number(n) || Number(t && t.startingBalance) || 0),
        g = m * i.dailyLossLimitPercent / 100,
        x = m * i.maxWeeklyLossPercent / 100;
      let y = 0;
      [...e].sort((E, N) => new Date(N.entryDate) - new Date(E.entryDate)).some(E => E.resultType === "loss" ? (y += 1, !1) : !0);
      const O = m * Number(l.riskPercent || 0) / 100,
        w = Number(l.stopDistance || 0) * Number(l.pipValue || 0),
        S = w > 0 ? O / w : 0,
        j = c.score >= 80 ? "منضبط" : c.score >= 60 ? "نیازمند توجه" : "ریسک بالا";
    
      function k(E, N) {
        o($ => ({
          ...$,
          [E]: Number(N)
        }))
      }
    
      function P() {
        a({
          ...r,
          ...i
        }), f(!0), setTimeout(() => f(!1), 1800)
      }
      return M.createElement("div", {
          className: "pa-feature-page pa-risk-page",
          "data-feature": "risk"
        },
        M.createElement("section", {
            className: "pa-feature-hero pa-risk-hero"
          },
          M.createElement("div", {
            className: "pa-feature-hero-icon"
          }, M.createElement(paRiskIcon, {
            size: 27
          })),
          M.createElement("div", {
              className: "pa-feature-hero-copy"
            }, M.createElement("span", {
              className: "pa-feature-kicker"
            }, "RISK & BEHAVIOR COCKPIT"), M.createElement("h1", null, "مدیریت ریسک و تحلیل هوشمند رفتار"), M.createElement("p", null, "قواعد ریسک، حجم مناسب و الگوهای رفتاری را از داده‌های همین حساب و کاملاً روی دستگاه تحلیل کن.")),
          M.createElement("div", {
              className: "pa-discipline-orb " + (c.score >= 80 ? "good" : c.score >= 60 ? "warn" : "bad"),
              style: {
                "--score": c.score
              }
            }, M.createElement("div", null, M.createElement("b", {
              className: "num"
            }, c.score), M.createElement("span", null, "امتیاز انضباط")), M.createElement("small", null, j))
        ),
        M.createElement("section", {
            className: "pa-risk-status-grid"
          },
          M.createElement("div", {
              className: "pa-card pa-risk-status"
            }, M.createElement("span", null, "زیان مصرف‌شده امروز"), M.createElement("b", {
              className: v >= g && g > 0 ? "num neg" : "num"
            }, Ke(v)), M.createElement("small", null, g ? `${(v/g*100).toFixed(0)}٪ از سقف` : "سقف تعریف نشده")),
          M.createElement("div", {
              className: "pa-card pa-risk-status"
            }, M.createElement("span", null, "تعداد معاملات امروز"), M.createElement("b", {
              className: p.length >= i.maxTradesPerDay ? "num neg" : "num"
            }, p.length), M.createElement("small", null, `سقف ${i.maxTradesPerDay} معامله`)),
          M.createElement("div", {
              className: "pa-card pa-risk-status"
            }, M.createElement("span", null, "باخت متوالی فعلی"), M.createElement("b", {
              className: y >= i.maxConsecutiveLosses ? "num neg" : "num"
            }, y), M.createElement("small", null, `توقف در ${i.maxConsecutiveLosses} باخت`)),
          M.createElement("div", {
              className: "pa-card pa-risk-status"
            }, M.createElement("span", null, "تخلف ریسک ثبت‌شده"), M.createElement("b", {
              className: c.riskBreaches ? "num neg" : "num pos"
            }, c.riskBreaches), M.createElement("small", null, `بالاتر از ${i.maxRiskPerTrade}٪`))
        ),
        M.createElement("section", {
            className: "pa-risk-main-grid"
          },
          M.createElement("div", {
              className: "pa-card pa-risk-limits"
            }, M.createElement("div", {
              className: "pa-card-title"
            }, "وضعیت محدودیت‌های زنده"), M.createElement(paRiskMeter, {
              label: "سقف زیان روزانه",
              value: v,
              max: g,
              inverse: !0
            }), M.createElement(paRiskMeter, {
              label: "سقف زیان هفتگی",
              value: b,
              max: x,
              inverse: !0
            }), M.createElement(paRiskMeter, {
              label: "معاملات امروز",
              value: p.length,
              max: i.maxTradesPerDay,
              inverse: !0
            }), M.createElement(paRiskMeter, {
              label: "باخت متوالی",
              value: y,
              max: i.maxConsecutiveLosses,
              inverse: !0
            }), M.createElement("div", {
              className: "pa-risk-verdict " + (v >= g && g > 0 || p.length >= i.maxTradesPerDay || y >= i.maxConsecutiveLosses ? "stop" : "go")
            }, v >= g && g > 0 || p.length >= i.maxTradesPerDay || y >= i.maxConsecutiveLosses ? "⛔ توقف معاملاتی پیشنهاد می‌شود" : "✓ قوانین فعلی اجازه معامله می‌دهند")),
          M.createElement("div", {
              className: "pa-card pa-size-calc"
            }, M.createElement("div", {
              className: "pa-card-title"
            }, "ماشین‌حساب حجم بر پایه ریسک"), M.createElement("div", {
              className: "pa-size-balance"
            }, M.createElement("span", null, "موجودی مبنا"), M.createElement("b", {
              className: "num"
            }, Ke(m))), M.createElement("div", {
              className: "pa-risk-fields"
            }, [{
              id: "riskPercent",
              label: "ریسک معامله (%)",
              step: ".1"
            }, {
              id: "stopDistance",
              label: "فاصله استاپ (pip/point)",
              step: ".1"
            }, {
              id: "pipValue",
              label: "ارزش هر pip برای ۱ lot",
              step: ".01"
            }].map(E => M.createElement("label", {
              key: E.id
            }, M.createElement("span", null, E.label), M.createElement("input", {
              className: "pa-input num",
              type: "number",
              min: "0",
              step: E.step,
              value: l[E.id],
              onChange: N => s($ => ({
                ...$,
                [E.id]: N.target.value
              }))
            })))), M.createElement("div", {
              className: "pa-size-result"
            }, M.createElement("div", null, M.createElement("span", null, "مبلغ در معرض ریسک"), M.createElement("b", {
              className: "num"
            }, Ke(O))), M.createElement("div", null, M.createElement("span", null, "حجم پیشنهادی"), M.createElement("b", {
              className: "num"
            }, S.toFixed(2), " lot"))), M.createElement("small", {
              className: "pa-risk-disclaimer"
            }, "ارزش pip/point را متناسب با نماد و قرارداد بروکر وارد کن؛ این محاسبه توصیه مالی نیست."))
        ),
        M.createElement("section", {
            className: "pa-card pa-risk-policy"
          }, M.createElement("div", {
            className: "pa-card-head-row"
          }, M.createElement("div", null, M.createElement("div", {
            className: "pa-card-title"
          }, "سیاست مدیریت ریسک"), M.createElement("div", {
            className: "pa-card-sub"
          }, "مقادیر برای همین ژورنال ذخیره و در تحلیل رفتار استفاده می‌شوند")), M.createElement("button", {
            type: "button",
            className: "pa-btn primary sm",
            onClick: P
          }, u ? "ذخیره شد ✓" : "ذخیره قوانین")), M.createElement("div", {
              className: "pa-policy-grid"
            }, [{
              id: "maxRiskPerTrade",
              label: "حداکثر ریسک هر معامله",
              suffix: "%",
              step: ".1"
            }, {
              id: "dailyLossLimitPercent",
              label: "سقف زیان روزانه",
              suffix: "%",
              step: ".1"
            }, {
              id: "maxWeeklyLossPercent",
              label: "سقف زیان هفتگی",
              suffix: "%",
              step: ".1"
            }, {
              id: "maxTradesPerDay",
              label: "حداکثر معامله روزانه",
              suffix: "عدد",
              step: "1"
            }, {
              id: "maxConsecutiveLosses",
              label: "توقف پس از باخت متوالی",
              suffix: "باخت",
              step: "1"
            }].map(E => M.createElement("label", {
              key: E.id
            }, M.createElement("span", null, E.label), M.createElement("div", null, M.createElement("input", {
              className: "pa-input num",
              type: "number",
              min: "0",
              step: E.step,
              value: i[E.id],
              onChange: N => k(E.id, N.target.value)
            }), M.createElement("small", null, E.suffix)))))
        ),
        M.createElement("section", {
            className: "pa-card pa-insights"
          }, M.createElement("div", {
              className: "pa-insights-head"
            }, M.createElement("div", null, M.createElement("span", {
              className: "pa-feature-kicker"
            }, "LOCAL PATTERN ENGINE"), M.createElement("div", {
              className: "pa-card-title"
            }, "بینش‌های رفتاری هوشمند"), M.createElement("div", {
              className: "pa-card-sub"
            }, "تحلیل قطعی و قابل توضیح؛ بدون ارسال اطلاعات به سرویس ابری")), M.createElement("div", {
              className: "pa-confidence"
            }, M.createElement("span", null, "اعتماد تحلیل"), M.createElement("b", null, c.confidenceLabel), M.createElement("i", null, M.createElement("em", {
              style: {
                width: c.confidence + "%"
              }
            })), M.createElement("small", {
              className: "num"
            }, c.count, " نمونه"))), M.createElement("div", {
              className: "pa-insight-grid"
            }, c.insights.map((E, N) => M.createElement("article", {
              className: "pa-insight " + E.tone,
              key: N
            }, M.createElement("span", {
              className: "pa-insight-n num"
            }, String(N + 1).padStart(2, "0")), M.createElement("div", null, M.createElement("h3", null, E.title), M.createElement("p", null, E.text), M.createElement("footer", null, "اقدام پیشنهادی: ", M.createElement("b", null, E.action))))))
        )
      )
    }
    registry["risk"] = paRiskCenter;
  }
})();
