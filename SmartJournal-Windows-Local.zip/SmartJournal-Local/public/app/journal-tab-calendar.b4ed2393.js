/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paDayTradeMap(e) {
      const t = {};
      e.forEach(n => {
        if (!n.entryDate) return;
        const r = new Date(n.entryDate);
        if (isNaN(r)) return;
        const a = vr(r);
        t[a] || (t[a] = {
          trades: [],
          count: 0,
          wins: 0,
          losses: 0,
          net: 0
        });
        t[a].trades.push(n), t[a].count += 1, t[a].net += wr(n), n.resultType === "profit" ? t[a].wins += 1 : t[a].losses += 1
      });
      return t
    }
    
    function paCalendarCenter({
      trades: e
    }) {
      const t = jv(new Date), [n, r] = M.useState({
          year: t.year,
          month: t.month
        }), [a, i] = M.useState(() => vr(new Date)),
        o = M.useMemo(() => paDayTradeMap(e), [e]),
        l = M.useMemo(() => rZ(n.year).filter(B => B.jMonth === n.month), [n]),
        s = l.length ? nZ(l[0].date) : 0,
        u = new Array(s).fill(null).concat(l),
        f = o[a],
        c = M.useMemo(() => {
          const B = l.map(_ => ({
            day: _,
            data: o[_.key]
          })).filter(_ => _.data);
          return {
            count: B.reduce((_, C) => _ + C.data.count, 0),
            wins: B.reduce((_, C) => _ + C.data.wins, 0),
            losses: B.reduce((_, C) => _ + C.data.losses, 0),
            net: B.reduce((_, C) => _ + C.data.net, 0),
            active: B.length,
            best: B.length ? [...B].sort((_, C) => C.data.net - _.data.net)[0] : null
          }
        }, [l, o]),
        p = Math.max(1, ...l.map(B => Math.abs((o[B.key] || {}).net || 0)));
    
      function h(B) {
        r(_ => {
          let C = _.year,
            z = _.month + B;
          return z < 1 && (z = 12, C -= 1), z > 12 && (z = 1, C += 1), {
            year: C,
            month: z
          }
        })
      }
    
      function v(B) {
        const _ = o[B.key];
        if (!_) return {};
        const C = .1 + Math.min(1, Math.abs(_.net) / p) * .28;
        return {
          background: _.net > 0 ? `linear-gradient(145deg,rgba(34,197,94,${C}),rgba(34,197,94,.035))` : _.net < 0 ? `linear-gradient(145deg,rgba(248,113,113,${C}),rgba(248,113,113,.035))` : "rgba(139,149,167,.055)",
          borderColor: _.net > 0 ? "rgba(34,197,94,.32)" : _.net < 0 ? "rgba(248,113,113,.32)" : "var(--border)"
        }
      }
      const b = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
      return M.createElement("div", {
          className: "pa-feature-page pa-calendar-page",
          "data-feature": "calendar"
        },
        M.createElement("section", {
            className: "pa-feature-hero pa-calendar-hero"
          },
          M.createElement("div", {
              className: "pa-feature-hero-icon"
            }, M.createElement(paCalendarIcon, {
              size: 26
            })),
          M.createElement("div", {
              className: "pa-feature-hero-copy"
            },
            M.createElement("span", {
              className: "pa-feature-kicker"
            }, "PERFORMANCE CALENDAR"),
            M.createElement("h1", null, "تقویم معاملاتی و Heatmap عملکرد"),
            M.createElement("p", null, "ریتم سود و زیان، شدت فعالیت و کیفیت اجرای پلن را در نمای روزانه و سالانه ببین.")
          ),
          M.createElement("div", {
              className: "pa-feature-hero-metrics"
            },
            M.createElement("div", null, M.createElement("b", {
              className: "num"
            }, e.length), M.createElement("span", null, "کل معاملات")),
            M.createElement("div", null, M.createElement("b", {
              className: "num"
            }, Object.keys(o).length), M.createElement("span", null, "روز فعال"))
          )
        ),
        M.createElement("section", {
            className: "pa-card pa-month-calendar"
          },
          M.createElement("div", {
              className: "pa-monthcal-head"
            },
            M.createElement("div", {
                className: "pa-monthcal-nav"
              },
              M.createElement("button", {
                type: "button",
                onClick: () => h(-1),
                "aria-label": "ماه قبل"
              }, "‹"),
              M.createElement("div", null,
                M.createElement("strong", null, JQ[n.month - 1]),
                M.createElement("span", {
                  className: "num"
                }, n.year)
              ),
              M.createElement("button", {
                type: "button",
                onClick: () => h(1),
                "aria-label": "ماه بعد"
              }, "›")
            ),
            M.createElement("div", {
                className: "pa-monthcal-kpis"
              },
              M.createElement("span", null, M.createElement("b", {
                className: "num"
              }, c.count), " معامله"),
              M.createElement("span", null, M.createElement("b", {
                className: "num"
              }, c.active), " روز فعال"),
              M.createElement("span", {
                className: c.net >= 0 ? "pos" : "neg"
              }, M.createElement("b", {
                className: "num"
              }, Ke(c.net)), " خالص ماه")
            )
          ),
          M.createElement("div", {
              className: "pa-monthcal-weekdays"
            }, b.map(B => M.createElement("span", {
              key: B
            }, B))),
          M.createElement("div", {
              className: "pa-monthcal-grid"
            }, u.map((B, _) => B ? M.createElement("button", {
              type: "button",
              className: "pa-monthcal-day" + (a === B.key ? " selected" : "") + (o[B.key] ? " active" : ""),
              style: v(B),
              onClick: () => i(B.key),
              title: o[B.key] ? `${o[B.key].count} معامله — ${Ke(o[B.key].net)}` : "بدون معامله",
              key: B.key
            },
            M.createElement("span", {
              className: "pa-monthcal-dayn num"
            }, B.jDay.toLocaleString("fa-IR")),
            o[B.key] ? M.createElement(M.Fragment, null,
              M.createElement("span", {
                className: "pa-monthcal-pnl num " + (o[B.key].net >= 0 ? "pos" : "neg")
              }, Ke(o[B.key].net)),
              M.createElement("span", {
                className: "pa-monthcal-count num"
              }, o[B.key].count, "×"),
              M.createElement("span", {
                className: "pa-monthcal-dots"
              }, new Array(Math.min(4, o[B.key].count)).fill(0).map((C, z) => M.createElement("i", {
                key: z
              })))
            ) : M.createElement("span", {
              className: "pa-monthcal-empty"
            }, "—")) : M.createElement("span", {
              className: "pa-monthcal-blank",
              key: "b" + _
            })))
        ),
        M.createElement("section", {
            className: "pa-card pa-calendar-detail"
          },
          M.createElement("div", {
              className: "pa-card-head-row"
            },
            M.createElement("div", null,
              M.createElement("div", {
                className: "pa-card-title"
              }, a ? new Date(a + "T12:00:00").toLocaleDateString("fa-IR", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
              }) : "جزئیات روز"),
              M.createElement("div", {
                className: "pa-card-sub"
              }, f ? `${f.wins} برد، ${f.losses} باخت و ${Ke(f.net)} خالص` : "برای این روز معامله‌ای ثبت نشده")
            ),
            f ? M.createElement("span", {
              className: "pa-calendar-daybadge " + (f.net >= 0 ? "up" : "down")
            }, M.createElement("b", {
              className: "num"
            }, f.count), " معامله") : null
          ),
          f ? M.createElement("div", {
              className: "pa-calendar-trades"
            }, [...f.trades].sort((B, _) => new Date(B.entryDate) - new Date(_.entryDate)).map(B => M.createElement("div", {
              className: "pa-calendar-trade",
              key: B.id
            },
            M.createElement("span", {
              className: "pa-calendar-trade-time num"
            }, GQ(B.entryDate)),
            M.createElement("span", {
              className: "pa-calendar-trade-symbol"
            }, paInstrumentLabel(B.symbol)),
            M.createElement("span", {
              className: "pa-calendar-trade-dir " + (B.direction === "buy" ? "buy" : "sell")
            }, B.direction === "buy" ? "BUY" : "SELL"),
            M.createElement("span", {
              className: "num " + (wr(B) >= 0 ? "pos" : "neg")
            }, Ke(wr(B)))
          ))) : M.createElement("div", {
            className: "pa-feature-empty"
          }, "یک روز فعال را انتخاب کن تا معاملات همان روز اینجا نمایش داده شوند.")
        ),
        M.createElement(yZ, {
          trades: e
        }),
        M.createElement(paSessionHeatmap, {
          trades: e
        })
      )
    }
    
    function paSessionHeatmap({
      trades: e
    }) {
      const rows = M.useMemo(() => {
        const stats = {};
        PA_SESSION_DEFS.forEach(session => {
          stats[session.key] = { key: session.key, count: 0, wins: 0, losses: 0, net: 0 };
        });
        stats["خارج از سشن"] = { key: "خارج از سشن", count: 0, wins: 0, losses: 0, net: 0, outside: true };
        (e || []).forEach(trade => {
          if (!trade || !trade.entryDate) return;
          const entryDate = new Date(trade.entryDate);
          if (isNaN(entryDate.getTime())) return;
          const info = paSessionsAt(entryDate);
          if (!info) return;
          const keys = info.active.length ? info.active.map(session => session.key) : ["خارج از سشن"];
          keys.forEach(key => {
            const row = stats[key];
            if (!row) return;
            row.count += 1;
            row.net += wr(trade);
            if (trade.riskFree) return;
            if (trade.resultType === "profit") row.wins += 1;
            else if (trade.resultType === "loss") row.losses += 1;
          });
        });
        return Object.values(stats).map(row => ({
          ...row,
          decided: row.wins + row.losses,
          winRate: row.wins + row.losses ? row.wins / (row.wins + row.losses) * 100 : null,
          avg: row.count ? row.net / row.count : 0
        }));
      }, [e]);
      const sessionRows = rows.filter(row => !row.outside);
      const maxNet = Math.max(1, ...sessionRows.map(row => Math.abs(row.net)));
      const maxCount = Math.max(1, ...sessionRows.map(row => row.count));
      const best = rows.filter(row => row.count && !row.outside).slice().sort((a, b) => b.net - a.net)[0];
      function cellStyle(row, type) {
        if (!row.count || (type === "win" && !row.decided)) return { background: "var(--hm-zero)", color: "var(--text-mute)" };
        if (type === "count") return { background: `rgba(34,211,238,${.18 + Math.min(1, row.count / maxCount) * .65})`, color: "#d9fbff" };
        if (type === "win") {
          const alpha = .18 + Math.min(1, Math.abs(row.winRate - 50) / 50) * .65;
          return row.winRate >= 50 ? { background: `rgba(34,197,94,${alpha})`, color: "#dcffe9" } : { background: `rgba(248,113,113,${alpha})`, color: "#ffe1e1" };
        }
        if (!row.net) return { background: "var(--hm-zero)", color: "var(--text-mute)" };
        const alpha = .18 + Math.min(1, Math.abs(row.net) / maxNet) * .65;
        return row.net > 0 ? { background: `rgba(34,197,94,${alpha})`, color: "#dcffe9" } : { background: `rgba(248,113,113,${alpha})`, color: "#ffe1e1" };
      }
      return d.jsxs("section", {
        className: "pa-card pa-session-heatmap-card",
        children: [d.jsxs("div", {
          className: "pa-session-hm-head",
          children: [d.jsxs("div", {
            children: [d.jsx("div", { className: "pa-card-title", children: "هیت‌مپ سشن‌های معاملاتی" }), d.jsx("div", { className: "pa-card-sub", children: "مقایسه تعداد معاملات، وین‌ریت و سود/زیان خالص در سشن‌های اصلی بازار" })]
          }), d.jsx("span", { className: "pa-session-hm-badge", children: "SESSION PERFORMANCE" })]
        }), d.jsx("div", {
          className: "pa-session-hm-scroll",
          children: d.jsxs("div", {
            className: "pa-session-hm-grid",
            children: [d.jsxs("div", {
              className: "pa-session-hm-row head",
              children: [d.jsx("div", { children: "سشن" }), d.jsx("div", { children: "تعداد" }), d.jsx("div", { children: "وین‌ریت" }), d.jsx("div", { children: "خالص" }), d.jsx("div", { children: "میانگین" })]
            }), rows.map(row => d.jsxs("div", {
              className: "pa-session-hm-row" + (row.outside ? " outside" : ""),
              children: [d.jsxs("div", { className: "pa-session-hm-name", children: [d.jsx("b", { children: row.key }), row.outside ? d.jsx("small", { children: " خارج از ساعت سشن" }) : d.jsx("small", { children: "جلسه معاملاتی" })] }), d.jsx("div", { className: "pa-session-hm-cell num", style: cellStyle(row, "count"), children: row.count }), d.jsx("div", { className: "pa-session-hm-cell num", style: cellStyle(row, "win"), children: row.decided ? row.winRate.toFixed(0) + "%" : "—" }), d.jsx("div", { className: "pa-session-hm-cell num", style: cellStyle(row, "pnl"), children: row.count ? Ke(row.net) : "—" }), d.jsx("div", { className: "pa-session-hm-cell num", style: cellStyle(row, "pnl"), children: row.count ? Ke(row.avg) : "—" })]
            }, row.key))]
          })
        }), d.jsxs("div", {
          className: "pa-session-hm-foot",
          children: [d.jsx("span", { children: "در زمان هم‌پوشانی، معامله در هر دو سشن محاسبه می‌شود." }), best ? d.jsxs("b", { className: best.net >= 0 ? "pos" : "neg", children: ["بهترین: ", best.key, " · ", Ke(best.net)] }) : d.jsx("span", { children: "هنوز معامله‌ای برای تحلیل سشن ثبت نشده" })]
        })]
      });
    }
    registry["calendar"] = paCalendarCenter;
  }
})();
