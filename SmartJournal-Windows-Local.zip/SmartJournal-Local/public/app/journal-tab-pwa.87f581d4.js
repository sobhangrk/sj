/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paMobilePwaCenter({
      onToast
    }) {
      const [online, setOnline] = M.useState(navigator.onLine),
        [standalone, setStandalone] = M.useState(window.matchMedia && window.matchMedia("(display-mode: standalone)").matches),
        [installable, setInstallable] = M.useState(!!window.PAInstallPrompt),
        [permission, setPermission] = M.useState("Notification" in window ? Notification.permission : "unsupported"),
        [reminder, setReminder] = M.useState(() => ({
          ...paReminderDefaults(),
          ...paSafeJson(localStorage.getItem(PA_REMINDER_KEY), {}) || {}
        }));
      M.useEffect(() => {
        const on = () => setOnline(!0),
          off = () => setOnline(!1),
          prompt = () => setInstallable(!0),
          installed = () => (setStandalone(!0), setInstallable(!1));
        window.addEventListener("online", on), window.addEventListener("offline", off), window.addEventListener("pa-install-available", prompt), window.addEventListener("appinstalled", installed);
        const timer = setInterval(paCheckReminder, 6e4);
        paCheckReminder();
        return () => (window.removeEventListener("online", on), window.removeEventListener("offline", off), window.removeEventListener("pa-install-available", prompt), window.removeEventListener("appinstalled", installed), clearInterval(timer))
      }, []);
      const install = async () => {
          if (standalone) return onToast("اپ از قبل در حالت نصب‌شده اجرا می‌شود");
          if (!window.PAInstallPrompt) return onToast("در iPhone از Share › Add to Home Screen استفاده کن؛ در دسکتاپ آیکن Install مرورگر را بزن.");
          await window.PAInstallPrompt.prompt();
          const choice = await window.PAInstallPrompt.userChoice;
          choice && choice.outcome === "accepted" ? onToast("نصب اپ تأیید شد") : onToast("نصب فعلاً انجام نشد"), window.PAInstallPrompt = null, setInstallable(!1)
        },
        requestNotifications = async () => {
          if (!("Notification" in window)) return onToast("این مرورگر از اعلان پشتیبانی نمی‌کند");
          const result = await Notification.requestPermission();
          setPermission(result), result === "granted" ? (onToast("اعلان ژورنال فعال شد"), paShowJournalReminder({
            ...reminder,
            title: "اعلان آزمایشی ژورنال"
          })) : onToast("اجازه اعلان داده نشد")
        },
        saveReminder = next => {
          setReminder(next), localStorage.setItem(PA_REMINDER_KEY, JSON.stringify(next)), onToast(next.enabled ? "یادآور روزانه ذخیره شد" : "یادآور غیرفعال شد"), paCheckReminder()
        };
      return M.createElement("div", {
        className: "pa-feature-center pa-pwa-center",
        "data-testid": "pwa-center"
      }, M.createElement("section", {
        className: "pa-feature-hero pa-pwa-hero"
      }, M.createElement("div", null, M.createElement("span", {
        className: "pa-feature-eyebrow"
      }, "MOBILE COMPANION"), M.createElement("h1", null, "اپ همراه ژورنال"), M.createElement("p", null, "نصب روی Home Screen، کار آفلاین، ثبت سریع و یادآور روزانه در یک تجربه موبایلی اختصاصی.")), M.createElement("div", {
        className: "pa-pwa-live " + (online ? "online" : "offline")
      }, M.createElement("i"), M.createElement("b", null, online ? "آنلاین" : "آفلاین"), M.createElement("span", null, online ? "همگام با حافظه محلی" : "داده‌ها همچنان روی دستگاه در دسترس‌اند"))), M.createElement("section", {
        className: "pa-pwa-grid"
      }, M.createElement("article", {
        className: "pa-card pa-pwa-install"
      }, M.createElement("div", {
        className: "pa-pwa-icon-preview"
      }, M.createElement("span", null, "PA")), M.createElement("div", null, M.createElement("span", {
        className: "pa-feature-eyebrow"
      }, "INSTALLABLE PWA"), M.createElement("h2", null, standalone ? "اپ روی دستگاه نصب است" : "نصب روی Home Screen"), M.createElement("p", null, "آیکن اختصاصی، صفحه شروع و اجرای تمام‌صفحه بدون نوار مرورگر."), M.createElement("button", {
        className: "pa-btn primary",
        onClick: install,
        disabled: standalone
      }, standalone ? "در حال اجرای نسخه نصب‌شده ✓" : installable ? "نصب اپ" : "راهنمای نصب"))), M.createElement("article", {
        className: "pa-card pa-reminder-card"
      }, M.createElement("span", {
        className: "pa-feature-eyebrow"
      }, "DAILY REMINDER"), M.createElement("h2", null, "یادآور تکمیل ژورنال"), M.createElement("p", null, "در ساعت انتخابی یادآوری می‌کند معاملات و تصاویر امروز را کامل کنی."), M.createElement("div", {
        className: "pa-reminder-controls"
      }, M.createElement("input", {
        className: "pa-input num",
        type: "time",
        value: reminder.time,
        onChange: event => setReminder(current => ({
          ...current,
          time: event.target.value
        }))
      }), M.createElement("label", {
        className: "pa-switch-row"
      }, M.createElement("input", {
        type: "checkbox",
        checked: !!reminder.enabled,
        onChange: event => saveReminder({
          ...reminder,
          enabled: event.target.checked
        })
      }), M.createElement("span"), M.createElement("b", null, reminder.enabled ? "فعال" : "غیرفعال"))), M.createElement("div", {
        className: "pa-pwa-actions"
      }, M.createElement("button", {
        className: "pa-btn ghost",
        onClick: requestNotifications
      }, permission === "granted" ? "ارسال اعلان آزمایشی" : "اجازه اعلان"), M.createElement("button", {
        className: "pa-btn primary",
        onClick: () => saveReminder({
          ...reminder
        })
      }, "ذخیره زمان")))), M.createElement("section", {
        className: "pa-pwa-capabilities"
      }, [["آفلاین واقعی", "فایل برنامه و پوسته برای اجرای بدون اینترنت cache می‌شوند.", online ? "آماده" : "فعال"], ["ذخیره خودکار", "فیلدهای فرم نیمه‌کاره برای هر حساب جداگانه نگهداری می‌شوند.", "فعال"], ["ثبت سریع", "دکمه مرکزی نوار پایین موبایل فرم معامله را با یک لمس باز می‌کند.", "فعال"], ["حریم خصوصی", "تمام داده‌ها و تصاویر در همین دستگاه باقی می‌مانند.", "محلی"]].map(item => M.createElement("article", {
        key: item[0]
      }, M.createElement("i", null, "✓"), M.createElement("div", null, M.createElement("h3", null, item[0]), M.createElement("p", null, item[1])), M.createElement("span", null, item[2])))), M.createElement("p", {
        className: "pa-pwa-note"
      }, "نکته: زمان‌بندی کاملاً پس‌زمینه به محدودیت سیستم‌عامل و مرورگر وابسته است. اپ هنگام بازبودن یا بازگشت به آن، یادآور عقب‌افتاده همان روز را بررسی می‌کند."))
    }
    registry["pwa"] = paMobilePwaCenter;
  }
})();
