/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function cZ({
      tasks: e,
      checks: t,
      todayKey: n,
      weekKey: r,
      monthKey: a,
      reviewNotes: i,
      onAdd: o,
      onRemove: l,
      onToggle: s,
      onTogglePin: u,
      onSaveReview: f,
      onBulk: bk
    }) {
      /* بازهٔ انتخاب‌شده؛ پیش‌فرض «حالا»، ولی کاربر می‌تواند به عقب/جلو برود
         و چک‌لیست و مرور همان بازه را ببیند و ویرایش کند. */
      const [paDay, paSetDay] = M.useState(n), [paWeek, paSetWeek] = M.useState(r), [paMonth, paSetMonth] = M.useState(a), [paRvWeek, paSetRvWeek] = M
        .useState(r), [paRvMonth, paSetRvMonth] = M.useState(a);
      M.useEffect(() => {
        paSetDay(n), paSetWeek(r), paSetMonth(a), paSetRvWeek(r), paSetRvMonth(a)
      }, [n, r, a]);
      const c = paDayLabel(paDay),
        v = paWeekLabel(paWeek),
        b = paMonthLabel(paMonth),
        /* نوارِ ۷ روزه حول روز انتخاب‌شده می‌چرخد تا در آرشیو هم مفید باشد */
        m = M.useMemo(() => {
          const g = [],
            base = paKeyToDate(paDay);
          for (let x = 6; x >= 0; x--) {
            const y = new Date(base);
            y.setDate(y.getDate() - x);
            const O = vr(y),
              w = (t.daily[O] || []).length,
              S = e.daily.length;
            g.push({
              key: O,
              ok: S > 0 && w === S,
              isToday: O === n
            })
          }
          return g
        }, [t.daily, e.daily, paDay, n]),
        dp = e.daily.length ? Math.round((t.daily[paDay] || []).length / e.daily.length * 100) : 0,
        paIsToday = paDay === n,
        dm = e.daily.length === 0 ? "اول چند کار برای امروز تعریف کن" : !paIsToday ? "در حال مرور آرشیو " + c : dp === 100 ?
        "امروز کامل شد — همین انضباط را فردا هم تکرار کن" : dp >= 50 ? "بیشتر از نیمی از کارهای امروز انجام شده" : dp > 0 ?
        "شروع کردی؛ باقی کارها را هم ببند" : "هنوز هیچ کاری از امروز تیک نخورده";
      /* فهرست بازه‌هایی که یادداشت ذخیره‌شده دارند، برای پرش سریع */
      function paNoteHistory(kind) {
        const src = (i && i[kind]) || {};
        return Object.keys(src).filter(kk => String(src[kk] || "").trim()).sort().reverse().map(kk => ({
          key: kk,
          label: kind === "monthly" ? paMonthLabel(kk) : paWeekLabel(kk),
          preview: String(src[kk]).replace(/\s+/g, " ").slice(0, 48) + (String(src[kk]).length > 48 ? "…" : "")
        }))
      }
      return d.jsxs(d.Fragment, {
        children: [d.jsxs("header", {
          className: "pa-check-hero",
          children: [d.jsx("span", {
            className: "pa-check-hero-glow",
            "aria-hidden": "true"
          }), d.jsxs("div", {
            className: "pa-check-hero-l",
            children: [d.jsxs("span", {
              className: "pa-check-hero-eyebrow",
              children: [d.jsx(Xa, {
                size: 12
              }), "انضباط روزانه"]
            }), d.jsx("h2", {
              className: "pa-check-hero-title",
              children: "چک‌لیست امروزت را تمیز ببند"
            }), d.jsx("p", {
              className: "pa-check-hero-desc",
              children: "سود از پیش‌بینی بازار نمی‌آید، از تکرار روزانهٔ چند کار ساده می‌آید. این صفحه همان چند کار است — امروز، این هفته و رشته‌ای که نباید بشکند."
            }), d.jsxs("div", {
              className: "pa-check-hero-pills",
              children: [d.jsxs("span", {
                className: "pa-hero-pill",
                children: [d.jsx(KE, {
                  size: 12
                }), " ", c]
              }), d.jsxs("span", {
                className: "pa-hero-pill",
                children: [d.jsx(ZE, {
                  size: 12
                }), " ", v]
              })]
            })]
          }), d.jsxs("div", {
            className: "pa-check-hero-stats",
            children: [d.jsxs("div", {
              className: "pa-check-stat" + (e.daily.length > 0 && (t.daily[paDay] || []).length === e.daily.length ? " ok" : ""),
              children: [d.jsx("span", {
                className: "pa-check-stat-i",
                children: d.jsx(Za, {
                  size: 15
                })
              }), d.jsxs("div", {
                className: "pa-check-stat-b",
                children: [d.jsxs("span", {
                  className: "pa-check-stat-v num",
                  children: [(t.daily[paDay] || []).length, "/", e.daily.length]
                }), d.jsx("span", {
                  className: "pa-check-stat-l",
                  children: paIsToday ? "کارهای امروز" : "کارهای " + c
                })]
              })]
            }), d.jsxs("div", {
              className: "pa-check-stat" + (e.weekly.length > 0 && (t.weekly[paWeek] || []).length === e.weekly.length ? " ok" : ""),
              children: [d.jsx("span", {
                className: "pa-check-stat-i",
                children: d.jsx(VE, {
                  size: 15
                })
              }), d.jsxs("div", {
                className: "pa-check-stat-b",
                children: [d.jsxs("span", {
                  className: "pa-check-stat-v num",
                  children: [(t.weekly[paWeek] || []).length, "/", e.weekly.length]
                }), d.jsx("span", {
                  className: "pa-check-stat-l",
                  children: paWeek === r ? "کارهای این هفته" : "کارهای هفتهٔ انتخابی"
                })]
              })]
            }), d.jsxs("div", {
              className: "pa-check-stat" + (m.reduce((sa, sb) => sb.ok ? sa + 1 : 0, 0) > 0 ? " ok" : ""),
              children: [d.jsx("span", {
                className: "pa-check-stat-i",
                children: d.jsx(o2, {
                  size: 15
                })
              }), d.jsxs("div", {
                className: "pa-check-stat-b",
                children: [d.jsxs("span", {
                  className: "pa-check-stat-v num",
                  children: [m.reduce((sa, sb) => sb.ok ? sa + 1 : 0, 0), " روز"]
                }), d.jsx("span", {
                  className: "pa-check-stat-l",
                  children: "رشته روزهای کامل"
                })]
              })]
            })]
          }), d.jsxs("div", {
            className: "pa-check-hero-prog" + (dp === 100 ? " full" : ""),
            children: [d.jsxs("div", {
              className: "pa-check-hero-prog-h",
              children: [d.jsx("span", {
                children: dm
              }), d.jsxs("span", {
                className: "num",
                children: [dp, "٪"]
              })]
            }), d.jsx("div", {
              className: "pa-check-hero-track",
              children: d.jsx("span", {
                className: "pa-check-hero-fill",
                style: {
                  width: dp + "%"
                }
              })
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-checklist-wrap",
          children: [d.jsx(Hw, {
            title: "چک‌لیست روزانه",
            subtitle: (paIsToday ? "امروز — " : "آرشیو — ") + c,
            list: e.daily,
            doneIds: t.daily[paDay] || [],
            period: "daily",
            itemKey: paDay,
            streakDays: m,
            onAdd: o,
            onRemove: l,
            onToggle: s,
            onTogglePin: u,
            onBulk: bk,
            nav: {
              label: c,
              value: paDay,
              current: n,
              hint: "امروز",
              filled: ((t.daily[paDay] || []).length > 0),
              onPrev: () => paSetDay(paDayKeyShift(paDay, -1)),
              onNext: () => paSetDay(paDayKeyShift(paDay, 1)),
              onNow: () => paSetDay(n),
              onPickDay: kk => paSetDay(kk)
            },
            readonlyNotice: paIsToday ? null : "این روز از آرشیو باز شده؛ تیک‌هایی که می‌زنی برای همان روز ذخیره می‌شود."
          }), d.jsx(Hw, {
            title: "چک‌لیست هفتگی",
            subtitle: (paWeek === r ? "این هفته — " : "آرشیو — ") + v,
            list: e.weekly,
            doneIds: t.weekly[paWeek] || [],
            period: "weekly",
            itemKey: paWeek,
            onAdd: o,
            onRemove: l,
            onToggle: s,
            onTogglePin: u,
            onBulk: bk,
            nav: {
              label: v,
              value: paWeek,
              current: r,
              hint: "هفتهٔ جاری",
              filled: ((t.weekly[paWeek] || []).length > 0),
              onPrev: () => paSetWeek(paWeekKeyShift(paWeek, -1)),
              onNext: () => paSetWeek(paWeekKeyShift(paWeek, 1)),
              onNow: () => paSetWeek(r)
            },
            readonlyNotice: paWeek === r ? null : "این هفته از آرشیو باز شده؛ تغییرات برای همان هفته ذخیره می‌شود."
          })]
        }), d.jsxs("div", {
          className: "pa-checklist-wrap",
          style: {
            marginTop: 16
          },
          children: [d.jsx(Vw, {
            title: "مرور هفتگی",
            kind: "weekly",
            subtitle: (paRvWeek === r ? "این هفته — " : "آرشیو — ") + paWeekLabel(paRvWeek),
            periodKey: paRvWeek,
            value: (i.weekly || {})[paRvWeek] || "",
            onSave: g => f("weekly", paRvWeek, g),
            history: paNoteHistory("weekly"),
            onJump: kk => paSetRvWeek(kk),
            nav: {
              label: paWeekLabel(paRvWeek),
              value: paRvWeek,
              current: r,
              hint: "هفتهٔ جاری",
              filled: !!String((i.weekly || {})[paRvWeek] || "").trim(),
              onPrev: () => paSetRvWeek(paWeekKeyShift(paRvWeek, -1)),
              onNext: () => paSetRvWeek(paWeekKeyShift(paRvWeek, 1)),
              onNow: () => paSetRvWeek(r)
            },
            placeholder: "این هفته چی خوب پیش رفت؟ کجا اشتباه کردی؟ هفته بعد چی رو تغییر می‌دی؟"
          }), d.jsx(Vw, {
            title: "مرور ماهانه",
            kind: "monthly",
            subtitle: (paRvMonth === a ? "این ماه — " : "آرشیو — ") + paMonthLabel(paRvMonth),
            periodKey: paRvMonth,
            value: (i.monthly || {})[paRvMonth] || "",
            onSave: g => f("monthly", paRvMonth, g),
            history: paNoteHistory("monthly"),
            onJump: kk => paSetRvMonth(kk),
            nav: {
              label: paMonthLabel(paRvMonth),
              value: paRvMonth,
              current: a,
              hint: "ماه جاری",
              filled: !!String((i.monthly || {})[paRvMonth] || "").trim(),
              onPrev: () => paSetRvMonth(paMonthKeyShift(paRvMonth, -1)),
              onNext: () => paSetRvMonth(paMonthKeyShift(paRvMonth, 1)),
              onNow: () => paSetRvMonth(a)
            },
            placeholder: "جمع‌بندی کلی این ماه از نظر عملکرد، انضباط و حال‌وهوای روانی معامله‌گری..."
          })]
        })]
      })
    }
    registry["checklist"] = cZ;
  }
})();
