/* SmartJournal — ساخته‌شده با scripts/split-landing-bundle.js. دستی ویرایش نکنید. */
/* SmartJournal — Social Share Cards (journal/trade data driven) */
(function() {
  'use strict';

  function injectStyles() {
    if (document.getElementById('pa-share-card-styles')) return;
    var style = document.createElement('style');
    style.id = 'pa-share-card-styles';
    style.textContent = `
      .pa-share-overlay { position: fixed; inset: 0; z-index: 10080; display: flex; align-items: center; justify-content: center; padding: 12px; background: rgba(3, 8, 16, 0.92); backdrop-filter: blur(18px); opacity: 0; transition: opacity 0.25s ease; }
      .pa-share-overlay.is-open { opacity: 1; }
      .pa-share-dialog-full { width: min(1280px, 98vw); height: min(920px, 94vh); border: 1px solid #1e2f42; border-radius: 24px; overflow: hidden; background: #060d15; box-shadow: 0 40px 120px rgba(0,0,0,0.9); display: flex; flex-direction: column; }
      .pa-share-iframe { width: 100%; height: 100%; border: none; background: transparent; }
    `;
    document.head.appendChild(style);
  }

  function drawRoundedBox(ctx, x, y, w, h, r, fill, stroke, strokeW, shadowColor) {
    ctx.save();
    if (shadowColor) {
      ctx.shadowColor = shadowColor;
      ctx.shadowBlur = 24;
    }
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.shadowColor = 'transparent'; ctx.strokeStyle = stroke; ctx.lineWidth = strokeW || 1; ctx.stroke(); }
    ctx.restore();
  }

  function drawSLogo(ctx, cx, cy, size) {
    ctx.save();
    ctx.translate(cx, cy);
    var scale = size / 50;
    if (ctx.scale) ctx.scale(scale, scale);
    ctx.beginPath();
    ctx.moveTo(-18, -20); ctx.lineTo(12, -20);
    ctx.quadraticCurveTo(22, -20, 22, -10); ctx.quadraticCurveTo(22, 0, 10, 4);
    ctx.lineTo(-6, 8); ctx.quadraticCurveTo(-18, 12, -18, 22);
    ctx.quadraticCurveTo(-18, 32, -6, 32); ctx.lineTo(18, 32);
    ctx.lineWidth = 7; ctx.strokeStyle = '#00ff88'; ctx.stroke();
    ctx.restore();
  }

  function finite(value) {
    var number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function firstNumber(item, keys) {
    for (var i = 0; i < keys.length; i += 1) {
      var value = finite(item && item[keys[i]]);
      if (value !== null) return value;
    }
    return 0;
  }

  /*
   * The journal stores amount as a positive magnitude and resultType as
   * profit/loss. Keep the same accounting rules as the journal itself:
   * risk-free trades are zero, commission is a cost and swap is signed.
   */
  function signedTradePnl(trade) {
    trade = trade || {};
    if (trade.riskFree) return 0;

    var raw = firstNumber(trade, ['pnl', 'netPnl', 'amount', 'profit']);
    var result = String(trade.resultType || trade.result || '').toLowerCase();
    var sign = result === 'loss' || result === 'lose' || result === 'negative' ? -1 :
      result === 'profit' || result === 'win' || result === 'positive' ? 1 : (raw < 0 ? -1 : 1);
    var commission = Math.abs(firstNumber(trade, ['commission', 'fees', 'fee']));
    var swap = firstNumber(trade, ['swap']);
    return Math.round((sign * Math.abs(raw) - commission + swap) * 100) / 100;
  }

  function tradeResult(trade, pnl) {
    var result = String((trade && (trade.resultType || trade.result)) || '').toLowerCase();
    if (trade && trade.riskFree) return 'break-even';
    if (result === 'profit' || result === 'win' || result === 'positive') return 'win';
    if (result === 'loss' || result === 'lose' || result === 'negative') return 'loss';
    return pnl > 0 ? 'win' : pnl < 0 ? 'loss' : 'break-even';
  }

  function round(value, digits) {
    var factor = Math.pow(10, digits || 2);
    return Math.round((Number(value) || 0) * factor) / factor;
  }

  function monthLabel(date) {
    var months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
    return months[date.getMonth()] + ' ' + date.getFullYear();
  }

  function reportPeriod(trades) {
    var dates = trades.map(function(trade) {
      var date = trade && trade.entryDate ? new Date(trade.entryDate) : null;
      return date && !Number.isNaN(date.getTime()) ? date : null;
    }).filter(Boolean).sort(function(a, b) { return a - b; });
    if (!dates.length) return 'TRADING REPORT';
    var first = monthLabel(dates[0]);
    var last = monthLabel(dates[dates.length - 1]);
    return first === last ? first : first + ' — ' + last;
  }

  function averageR(trades) {
    var values = trades.map(function(trade) {
      var key = ['rMultiple', 'realizedR', 'actualR', 'rrMultiple', 'plannedRR', 'rr'];
      for (var i = 0; i < key.length; i += 1) {
        var value = finite(trade && trade[key[i]]);
        if (value !== null) {
          /* plannedRR is a target and is stored as a positive ratio. */
          return key[i] === 'plannedRR' || key[i] === 'rr' ? Math.abs(value) : value;
        }
      }
      return null;
    }).filter(function(value) { return value !== null; });
    if (!values.length) return '—';
    return round(values.reduce(function(total, value) { return total + value; }, 0) / values.length, 2).toFixed(2) + 'R';
  }

  function buildReportData(trades) {
    trades = Array.isArray(trades) ? trades.filter(function(item) { return item && typeof item === 'object'; }) : [];
    var wins = 0;
    var losses = 0;
    var net = 0;
    var grossProfit = 0;
    var grossLoss = 0;

    trades.forEach(function(trade) {
      var pnl = signedTradePnl(trade);
      var result = tradeResult(trade, pnl);
      net += pnl;
      if (result === 'win') {
        wins += 1;
        grossProfit += Math.max(0, pnl);
      } else if (result === 'loss') {
        losses += 1;
        grossLoss += Math.abs(Math.min(0, pnl));
      }
    });

    var resolved = wins + losses;
    var profitFactor = grossLoss > 0 ? (grossProfit / grossLoss).toFixed(2) : grossProfit > 0 ? '∞' : '0.00';
    return {
      period: reportPeriod(trades),
      net: round(net, 2),
      winRate: resolved ? round((wins / resolved) * 100, 1) : 0,
      trades: trades.length,
      wins: wins,
      losses: losses,
      profitFactor: profitFactor,
      avgR: averageR(trades),
      grossProfit: round(grossProfit, 2),
      grossLoss: round(grossLoss, 2)
    };
  }

  function symbolName(symbol) {
    var value = String(symbol || '').toUpperCase();
    if (value.indexOf('XAU') >= 0 || value.indexOf('GOLD') >= 0) return 'GOLD / U.S. DOLLAR';
    if (value.indexOf('XAG') >= 0 || value.indexOf('SILVER') >= 0) return 'SILVER / U.S. DOLLAR';
    if (value.indexOf('EUR') >= 0) return 'EURO / U.S. DOLLAR';
    if (value.indexOf('GBP') >= 0) return 'BRITISH POUND';
    if (value.indexOf('BTC') >= 0) return 'BITCOIN';
    if (value.indexOf('ETH') >= 0) return 'ETHER';
    return 'FINANCIAL ASSET';
  }

  function buildTradeData(item) {
    item = item || {};
    var symbol = String(item.symbol || 'XAUUSD').toUpperCase();
    return {
      symbol: symbol,
      name: item.name || symbolName(symbol),
      direction: String(item.direction || 'buy').toUpperCase() === 'SELL' ? 'SELL' : 'BUY',
      /* This is deliberately signed; the builder colors loss cards correctly. */
      profit: signedTradePnl(item),
      volume: String(item.positionSize || item.lot || item.volume || '—'),
      risk: String(item.riskPercent || item.risk || '—'),
      timeframe: String(item.timeframe || '—').toUpperCase(),
      setup: String(item.setupName || item.setup || '—')
    };
  }

  function buildSharePayload(tradeOrTrades, isSummary) {
    var isArray = Array.isArray(tradeOrTrades);
    var trades = (isArray ? tradeOrTrades : [tradeOrTrades]).filter(function(item) {
      return item && typeof item === 'object';
    });
    var first = trades[0] || {};
    var report = buildReportData(trades);
    var traderHandle = first.traderHandle || first.username ||
      (typeof window !== 'undefined' && window.__PA_SHARE_HANDLE__) || 'smarttradejournal.ir';

    return {
      mode: isSummary ? 'report' : 'trade',
      fixedMode: isSummary ? 'report' : 'trade',
      themeId: 'emerald',
      ratio: 'story',
      username: String(traderHandle),
      trade: buildTradeData(first),
      report: report
    };
  }

  function paDrawTradeCanvas(canvas, trade, options) {
    trade = trade || {};
    options = options || {};
    var ratio = options.ratio || 'story';
    var showAmount = options.showAmount !== false;
    var traderHandle = String(options.traderHandle || 'smarttradejournal.ir').trim();
    var W = 1080, H = 1920;
    if (ratio === 'square') { W = 1080; H = 1080; }
    else if (ratio === 'banner' || ratio === 'wide') { W = 1200; H = 675; }

    canvas.width = W; canvas.height = H;
    var ctx = canvas.getContext('2d');
    ctx.direction = 'ltr';
    var pnl = signedTradePnl(trade);
    var isWin = pnl >= 0;
    var primaryColor = isWin ? '#00ff88' : '#ef4444';
    var primaryGlow = isWin ? 'rgba(0, 255, 136, 0.4)' : 'rgba(239, 68, 68, 0.4)';
    var grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#010407'); grad.addColorStop(0.5, '#07121b'); grad.addColorStop(1, '#020508');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
    var topY = 110;
    drawSLogo(ctx, W / 2, topY, 48);
    ctx.textAlign = 'center'; ctx.font = '900 44px "Vazirmatn", Tahoma, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('SmartJournal', W / 2, topY + 62);
    ctx.font = '700 16px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b';
    ctx.fillText('TRADING JOURNAL', W / 2, topY + 92);
    var cardX = 80, cardY = topY + 130, cardW = W - 160, cardH = H - cardY - 260;
    drawRoundedBox(ctx, cardX, cardY, cardW, cardH, 44, 'rgba(5, 18, 24, 0.94)', primaryColor, 3.5, primaryGlow);
    var innerX = cardX + 45, innerY = cardY + 45;
    var symbol = String(trade.symbol || 'XAUUSD').toUpperCase();
    ctx.textAlign = 'left'; ctx.font = '900 52px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText(symbol, innerX + 110, innerY + 45);
    var curY = innerY + 125;
    ctx.font = '700 20px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b';
    ctx.fillText('PROFIT', innerX + 5, curY + 55);
    curY += 130;
    var amtTxt = showAmount ? (isWin ? '+' : '-') + '$' + Math.abs(pnl).toFixed(2) : (isWin ? 'WINNER' : 'LOSS');
    ctx.font = '900 88px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = primaryColor;
    ctx.fillText(amtTxt, innerX + 5, curY);
    var footerY = H - 160;
    var handleTxt = traderHandle ? (traderHandle.startsWith('@') ? traderHandle : '@' + traderHandle) : '@smarttradejournal.ir';
    ctx.textAlign = 'center'; ctx.font = '700 24px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('👤  ' + handleTxt, W / 2, footerY + 38);
  }

  /* Legacy canvas API retained for scripts and older integrations. */
  function paDrawSummaryCanvas(canvas, trades, options) {
    options = options || {};
    var W = 1080, H = options.ratio === 'square' ? 1080 : 1920;
    canvas.width = W; canvas.height = H;
    var ctx = canvas.getContext('2d');
    var report = buildReportData(trades);
    var grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#010407'); grad.addColorStop(0.5, '#07121b'); grad.addColorStop(1, '#020508');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
    drawSLogo(ctx, W / 2, 110, 48);
    ctx.textAlign = 'center'; ctx.font = '900 44px "Vazirmatn", Tahoma, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('SmartJournal', W / 2, 172);
    ctx.font = '700 18px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b';
    ctx.fillText('PERFORMANCE REPORT', W / 2, 215);
    var cardX = 80, cardY = 300, cardW = W - 160, cardH = Math.min(H - 520, 1120);
    drawRoundedBox(ctx, cardX, cardY, cardW, cardH, 44, 'rgba(5, 18, 24, 0.94)', '#00ff88', 3.5, 'rgba(0, 255, 136, 0.35)');
    ctx.textAlign = 'left'; ctx.font = '700 22px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b';
    ctx.fillText(report.period, cardX + 55, cardY + 80);
    ctx.font = '700 20px "JetBrains Mono", monospace, sans-serif'; ctx.fillText('NET P&L', cardX + 55, cardY + 155);
    ctx.font = '900 72px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = report.net >= 0 ? '#00ff88' : '#ef4444';
    ctx.fillText((report.net >= 0 ? '+' : '-') + '$' + Math.abs(report.net).toFixed(2), cardX + 55, cardY + 245);
    var rows = [
      ['WIN RATE', report.winRate.toFixed(1) + '%'],
      ['TRADES', String(report.trades)],
      ['PROFIT FACTOR', String(report.profitFactor)],
      ['AVG R', String(report.avgR)]
    ];
    rows.forEach(function(row, index) {
      var x = cardX + 55 + (index % 2) * (cardW / 2 - 20);
      var y = cardY + 390 + Math.floor(index / 2) * 150;
      ctx.font = '700 18px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b'; ctx.fillText(row[0], x, y);
      ctx.font = '900 42px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#ffffff'; ctx.fillText(row[1], x, y + 58);
    });
    ctx.textAlign = 'center'; ctx.font = '700 24px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('@' + (options.traderHandle || 'smarttradejournal.ir').replace(/^@/, ''), W / 2, H - 120);
  }

  function paOpenShareModal(tradeOrTrades, isSummary) {
    injectStyles();
    var existing = document.getElementById('pa-share-overlay');
    if (existing) existing.remove();
    var sharePayload = buildSharePayload(tradeOrTrades, isSummary);
    var overlay = document.createElement('div');
    overlay.id = 'pa-share-overlay';
    overlay.className = 'pa-share-overlay';
    var dialog = document.createElement('div');
    dialog.className = 'pa-share-dialog-full';
    var iframe = document.createElement('iframe');
    iframe.className = 'pa-share-iframe';
    iframe.src = '/share-card-builder.html';
    dialog.appendChild(iframe);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    window.paCloseShareModal = function() {
      overlay.classList.remove('is-open');
      setTimeout(function() { overlay.remove(); }, 250);
    };
    iframe.onload = function() {
      try {
        iframe.contentWindow.__pa_share_data = sharePayload;
        iframe.contentWindow.dispatchEvent(new CustomEvent('pa-update-share-data', { detail: sharePayload }));
      } catch (err) {}
    };
    requestAnimationFrame(function() { overlay.classList.add('is-open'); });
  }

  window.paDrawTradeCanvas = paDrawTradeCanvas;
  window.paDrawSummaryCanvas = paDrawSummaryCanvas;
  window.paBuildSharePayload = buildSharePayload;
  window.paBuildShareReport = buildReportData;
  window.paOpenShareModal = function(trade) { paOpenShareModal(trade, false); };
  window.paOpenShareSummaryModal = function(trades) { paOpenShareModal(trades, true); };
})();
