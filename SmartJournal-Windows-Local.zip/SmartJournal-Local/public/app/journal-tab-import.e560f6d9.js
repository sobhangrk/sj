/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    const paImportFields = [{
      id: "date",
      label: "تاریخ/زمان معامله",
      required: !0,
      aliases: ["close time", "closing time", "exit time", "زمان بسته شدن", "تاریخ", "date", "time", "open time", "entry date", "entrydate"]
    }, {
      id: "symbol",
      label: "نماد",
      required: !0,
      aliases: ["symbol", "item", "instrument", "market", "نماد", "دارایی"]
    }, {
      id: "direction",
      label: "جهت Buy/Sell",
      aliases: ["type", "side", "trade type", "order type", "نوع", "جهت", "direction"]
    }, {
      id: "pnl",
      label: "سود/زیان یا Amount",
      required: !0,
      aliases: ["profit", "p l", "pnl", "net profit", "net pnl", "amount", "result amount", "سود زیان", "سود", "مبلغ"]
    }, {
      id: "result",
      label: "نتیجه Profit/Loss",
      aliases: ["result", "result type", "outcome", "نتیجه"]
    }, {
      id: "commission",
      label: "کمیسیون",
      aliases: ["commission", "fee", "fees", "کمیسیون", "کارمزد"]
    }, {
      id: "swap",
      label: "Swap",
      aliases: ["swap", "rollover", "سواپ"]
    }, {
      id: "volume",
      label: "حجم/Lot",
      aliases: ["volume", "size", "lots", "lot", "position size", "حجم"]
    }, {
      id: "ticket",
      label: "Ticket/Deal/Order",
      aliases: ["ticket", "deal", "position", "order", "trade id", "id", "تیکت"]
    }, {
      id: "setup",
      label: "ستاپ/کامنت",
      aliases: ["setup", "strategy", "comment", "magic", "ستاپ", "استراتژی", "توضیحات"]
    }, {
      id: "riskPercent",
      label: "ریسک درصدی",
      aliases: ["risk percent", "risk", "risk %", "ریسک"]
    }, {
      id: "entryFlag",
      label: "ورود/خروج Deal",
      aliases: ["entry", "deal direction", "entry direction"]
    }];
    
    function paHeaderScore(e) {
      const t = e.map(paKey),
        n = new Set;
      return paImportFields.forEach(r => r.aliases.some(a => t.some(i => i === paKey(a) || i.includes(paKey(a)))) && n.add(r.id)), n.size
    }
    
    function paTableFromMatrix(e, t) {
      if (!e.length) throw new Error("هیچ ردیف قابل خواندنی پیدا نشد");
      let n = 0,
        r = -1;
      e.slice(0, 35).forEach((l, s) => {
        const u = paHeaderScore(l);
        u > r && (r = u, n = s)
      });
      let headerRow = e[n].slice();
      {
        const body = e.slice(n + 1).filter(l => l.some(s => String(s).trim())), tally = {};
        body.slice(0, 60).forEach(l => tally[l.length] = (tally[l.length] || 0) + 1);
        const modal = Number(Object.keys(tally).sort((x, y) => tally[y] - tally[x])[0] || headerRow.length);
        if (modal === headerRow.length + 1) {
          const at = headerRow.findIndex(h => /^\s*type\s*$/i.test(String(h)));
          headerRow.splice(at >= 0 ? at + 1 : headerRow.length, 0, "Comment")
        }
      }
      const a = headerRow.map((l, s) => String(l || `ستون ${s+1}`).trim()),
        i = {},
        o = a.map((l, s) => {
          const u = paKey(l) || "column";
          i[u] = (i[u] || 0) + 1;
          return {
            key: "c" + s,
            label: l + (i[u] > 1 ? ` (${i[u]})` : ""),
            norm: u
          }
        });
      return {
        columns: o,
        rows: e.slice(n + 1).filter(l => l.some(s => String(s).trim())).map((l, s) => {
          const u = {
            __row: n + s + 2
          };
          return o.forEach((f, c) => u[f.key] = String(l[c] == null ? "" : l[c]).trim()), u
        }),
        detected: t
      }
    }
    
    function paSplitReportSections(matrix) {
      const sections = [];
      let current = null, pendingName = "";
      matrix.forEach(row => {
        const filled = row.filter(c => String(c).trim().length);
        if (filled.length <= 1) { if (filled.length === 1) pendingName = String(filled[0]).trim(); return }
        if (row.length < 3) return;
        const score = paHeaderScore(row);
        if (score >= 4 && (!current || current.rows.length > 1)) {
          current = { name: pendingName, header: row, rows: [row] };
          sections.push(current); pendingName = ""; return
        }
        if (current) current.rows.push(row)
      });
      return sections
    }
    
    function paPickReportSection(sections) {
      const hasProfit = s => s.header.some(h => /profit|p\s*\/?\s*l|سود/i.test(String(h)));
      /* حتی اگر نام بخش در فایل نباشد، از روی سرستون‌ها تشخیص می‌دهیم:
         Positions ستون «Position» دارد و ستون «Direction» ندارد؛ Deals برعکس؛
         Orders ستون «State» دارد و ستون سود ندارد. */
      const keys = s => s.header.map(h => paKey(h));
      const isPositions = s => keys(s).some(h => h === "position") && !keys(s).some(h => h === "direction") && hasProfit(s);
      const isDeals = s => keys(s).some(h => h === "direction") && hasProfit(s);
      const isOrders = s => keys(s).some(h => h === "state") || (keys(s).some(h => h === "order") && !hasProfit(s));
      const rank = s => (hasProfit(s) ? 1e6 : 0)
        + (/position/i.test(s.name || "") || isPositions(s) ? 5e5 : 0)
        + (/deal/i.test(s.name || "") || isDeals(s) ? 2e5 : 0)
        - (/order/i.test(s.name || "") || isOrders(s) ? 1e5 : 0) + s.rows.length;
      return sections.slice().sort((a, b) => rank(b) - rank(a))[0] || null
    }
    
    function paSectionHeader(section) {
      const head = section.header.map(h => paKey(h));
      const body = section.rows.slice(1).filter(r => r.some(c => String(c).trim()));
      const tally = {};
      body.slice(0, 60).forEach(r => tally[r.length] = (tally[r.length] || 0) + 1);
      const modal = Number(Object.keys(tally).sort((a, b) => tally[b] - tally[a])[0] || head.length);
      if (modal === head.length + 1) {
        const at = head.findIndex(h => h === "type");
        head.splice(at >= 0 ? at + 1 : head.length, 0, "comment")
      }
      return { head, body }
    }
    
    function paDealsLedger(sections) {
      const sec = sections.find(s => /deal/i.test(s.name || "") ||
        (s.header.some(h => /direction/i.test(String(h))) && s.header.some(h => /commission/i.test(String(h)))));
      if (!sec) return null;
      const { head, body } = paSectionHeader(sec);
      const at = (name, n = 0) => { let seen = 0; for (let i = 0; i < head.length; i++) if (head[i] === name && seen++ === n) return i; return -1 };
      const iTime = at("time"), iSym = at("symbol"), iType = at("type"), iDir = at("direction"),
        iVol = at("volume"), iOrder = at("order"), iCom = at("commission"), iFee = at("fee"), iSwap = at("swap");
      if (iCom < 0 && iSwap < 0) return null;
      const num = v => { const x = paNumber(v); return Number.isFinite(x) ? x : 0 };
      const list = body.map(r => ({
        time: String(r[iTime] == null ? "" : r[iTime]).trim(),
        symbol: String(r[iSym] == null ? "" : r[iSym]).trim().toUpperCase(),
        type: paKey(r[iType] || ""),
        dir: paKey(r[iDir] || ""),
        volume: iVol < 0 ? 0 : num(r[iVol]),
        order: iOrder < 0 ? "" : String(r[iOrder] == null ? "" : r[iOrder]).trim(),
        commission: (iCom < 0 ? 0 : num(r[iCom])) + (iFee < 0 ? 0 : num(r[iFee])),
        swap: iSwap < 0 ? 0 : num(r[iSwap])
      })).filter(d => d.symbol && d.type !== "balance");
      return list.length ? list : null
    }
    
    function paApplyDealCharges(table, sections) {
      let deals = null;
      try { deals = paDealsLedger(sections) } catch (err) { deals = null }
      if (!deals) return table;
      const colOf = (norm, n = 0) => { let seen = 0; for (const c of table.columns) if (c.norm === norm && seen++ === n) return c.key; return null };
      const kOpen = colOf("time", 0), kClose = colOf("time", 1), kSym = colOf("symbol"),
        kPos = colOf("position") || colOf("ticket") || colOf("deal"),
        kCom = colOf("commission"), kSwap = colOf("swap");
      if (!kSym || (!kCom && !kSwap)) return table;
      const byTime = new Map(), byOrder = new Map();
      deals.forEach((d, i) => {
        const k = d.time + "|" + d.symbol;
        (byTime.get(k) || byTime.set(k, []).get(k)).push(i);
        if (d.order) (byOrder.get(d.order) || byOrder.set(d.order, []).get(d.order)).push(i)
      });
      const used = new Set();
      table.rows.forEach(row => {
        const sym = String(row[kSym] || "").trim().toUpperCase(),
          pick = new Set();
        [kOpen, kClose].forEach(k => {
          if (!k) return;
          (byTime.get(String(row[k] || "").trim() + "|" + sym) || []).forEach(i => pick.add(i))
        });
        const pid = kPos ? String(row[kPos] || "").trim() : "";
        if (pid) (byOrder.get(pid) || []).forEach(i => pick.add(i));
        let com = 0, swap = 0, hit = 0;
        pick.forEach(i => {
          if (used.has(i) || deals[i].symbol !== sym) return;
          used.add(i), com += deals[i].commission, swap += deals[i].swap, hit++
        });
        if (!hit) return;
        if (kCom && com && !paNumber(row[kCom])) row[kCom] = String(com);
        if (kSwap && swap && !paNumber(row[kSwap])) row[kSwap] = String(swap)
      });
      return table
    }
    
    function paMergeEntryCharges(table) {
      const colOf = norm => { for (const c of table.columns) if (c.norm === norm) return c.key; return null };
      const kDir = colOf("direction"), kSym = colOf("symbol"), kVol = colOf("volume"),
        kCom = colOf("commission"), kFee = colOf("fee"), kSwap = colOf("swap");
      if (!kDir || !kSym || !kCom) return table;
      const num = v => { const x = paNumber(v); return Number.isFinite(x) ? x : 0 };
      const queue = new Map();
      table.rows.forEach(row => {
        const dir = paKey(row[kDir] || ""), sym = String(row[kSym] || "").trim().toUpperCase();
        if (!sym) return;
        if (kFee && num(row[kFee])) row[kCom] = String(num(row[kCom]) + num(row[kFee]));
        const vol = kVol ? Math.abs(num(row[kVol])) : 0;
        if (dir === "in") {
          (queue.get(sym) || queue.set(sym, []).get(sym)).push({ left: vol || 1, vol: vol || 1, com: num(row[kCom]), swap: kSwap ? num(row[kSwap]) : 0 });
          return
        }
        if (!/^out/.test(dir)) return;
        let need = vol || 1, com = 0, swap = 0;
        const q = queue.get(sym) || [];
        while (need > 1e-9 && q.length) {
          const head = q[0], take = Math.min(head.left, need), share = head.vol ? take / head.vol : 1;
          com += head.com * share, swap += head.swap * share;
          head.left -= take, need -= take;
          if (head.left <= 1e-9) q.shift()
        }
        if (com) row[kCom] = String(num(row[kCom]) + com);
        if (swap && kSwap) row[kSwap] = String(num(row[kSwap]) + swap)
      });
      return table
    }
    
    function paParseImportText(e, t) {
      if (/\.html?$/i.test(t) || /<table[\s>]/i.test(e)) {
        const n = new DOMParser().parseFromString(e, "text/html"),
          all = [...n.querySelectorAll("tr")].map(a => [...a.querySelectorAll("th,td")].map(i => (i.textContent || "").replace(/\s+/g, " ").trim())),
          r = all.filter(a => a.length > 2);
        /* نامِ هر بخش گزارش MT5 («Positions»، «Orders»، «Deals») در یک ردیفِ
           تک‌سلولی نوشته شده. قبلاً همین ردیف‌ها قبل از تقسیم‌بندی حذف می‌شدند،
           بخش‌ها بی‌نام می‌ماندند و انتخاب‌گر به‌جای Positions سراغ Deals می‌رفت؛
           نتیجه: زمانِ بسته‌شدن به‌جای زمان ورود، کامنت دیل به‌عنوان ستاپ، و
           وابسته‌شدن Buy/Sell به وارونه‌کردن دستیِ «دیل خروج». */
        const sections = paSplitReportSections(all), picked = sections.length > 1 ? paPickReportSection(sections) : null;
        if (picked && picked.rows.length > 1) {
          const table = paTableFromMatrix(picked.rows, "MetaTrader HTML" + (picked.name ? " — " + picked.name : ""));
          const isDeals = /deal/i.test(picked.name || "") || table.columns.some(c => c.norm === "direction");
          return isDeals ? paMergeEntryCharges(table) : paApplyDealCharges(table, sections)
        }
        return paTableFromMatrix(r, "MetaTrader HTML")
      }
      const n = paDelimiter(e),
        r = paCsvRows(e.replace(/^\uFEFF/, ""), n);
      return paTableFromMatrix(r, n === "\t" ? "MetaTrader / TSV" : "CSV")
    }
    
    function paGuessMap(e, t) {
      const n = {};
      paImportFields.forEach(r => {
        let a = null,
          i = -1;
        e.forEach(o => {
          r.aliases.forEach((l, s) => {
            const u = paKey(l),
              f = o.norm === u ? 100 - s : o.norm.includes(u) || u.includes(o.norm) ? 50 - s : -1;
            f > i && (i = f, a = o.key)
          })
        }), a && (n[r.id] = a)
      });
      const r = e.find(o => o.norm === "direction"),
        a = e.find(o => o.norm === "type");
      if (r && a) {
        const i = t.slice(0, 20).map(o => paKey(o[r.key])).filter(Boolean),
          l = i.filter(o => ["in", "out", "in out", "ورود", "خروج"].includes(o)).length;
        i.length && l / i.length > .5 && (n.entryFlag = r.key, n.direction = a.key)
      }
      return n
    }
    
    function paDirection(e) {
      const t = paKey(e);
      return /sell|short|فروش/.test(t) ? "sell" : /buy|long|خرید/.test(t) ? "buy" : null
    }
    
    function paResultSign(e) {
      const t = paKey(e);
      return /loss|lose|ضرر|زیان|باخت|negative/.test(t) ? -1 : /profit|win|سود|برد|positive/.test(t) ? 1 : 0
    }
    
    function paTradeSignature(e) {
      const t = e.importMeta || {};
      return t.ticket ? `${e.accountId}|ticket|${t.ticket}|${new Date(e.entryDate).getTime()}|${Number(e.amount||0).toFixed(4)}` : `${e.accountId}|trade|${new Date(e.entryDate).getTime()}|${e.symbol}|${e.direction}|${Number(e.amount||0).toFixed(4)}|${Number(e.commission||0).toFixed(4)}|${Number(e.swap||0).toFixed(4)}`
    }
    
    function paBuildImportedTrade(e, t, n) {
      const r = [],
        a = k => t[k] ? e[t[k]] : "",
        i = paNaiveToInstant(paDate(a("date")), n.timezone),
        o = String(a("symbol") || "").toUpperCase().replace(/\s/g, "").replace(/[^A-Z0-9._-]/g, ""),
        l = paDirection(a("direction")),
        s = paNumber(a("pnl")),
        u = paResultSign(a("result")),
        f = paKey(a("entryFlag"));
      if (!i) r.push("تاریخ نامعتبر");
      if (!o) r.push("نماد خالی");
      if (!Number.isFinite(s)) r.push("سود/زیان نامعتبر");
      if (f && ["in", "ورود"].includes(f)) r.push("Deal ورودی است");
      const c = paKey(a("direction"));
      if (c && !l && /(balance|credit|deposit|withdraw|بستانکار|واریز|برداشت)/.test(c)) r.push("تراکنش غیرمعاملاتی");
      if (c && !l && /(limit|stop)/.test(c)) r.push("سفارش معلق/حذف‌شده");
      const p = Number.isFinite(s) ? (u ? Math.abs(s) * u : s) : 0,
        h = paNumber(a("commission")),
        v = paNumber(a("swap")),
        b = paNumber(a("volume")),
        m = paNumber(a("riskPercent")),
        g = a("ticket");
      if (r.length) return {
        errors: r,
        trade: null
      };
      /* در MT5 «دیلِ خروج» همیشه نوع مخالف پوزیشن را دارد (خروجِ یک خرید = sell).
       * پس اگر ردیف، دیل خروج باشد جهت را برمی‌گردانیم تا Buy/Sell برعکس ثبت نشود. */
      let dir = l;
      if (dir && /^out/.test(f)) dir = dir === "buy" ? "sell" : "buy";
      const x = {
        ...xl,
        symbol: o.replace(/\.(PRO|RAW|ECN)$/i, ""),
        direction: dir || "buy",
        entryDate: i.toISOString(),
        positionSize: Number.isFinite(b) ? String(Math.abs(b)) : "",
        riskPercent: Number.isFinite(m) ? String(Math.abs(m)) : "",
        resultType: p >= 0 ? "profit" : "loss",
        amount: Math.abs(p),
        commission: Number.isFinite(h) ? Math.abs(h) : 0,
        swap: Number.isFinite(v) ? v : 0,
        /* برای معاملات واردشده از متاتریدر ستاپ ثبت نمی‌شود؛ کامنت‌های فایل
           (مثل «[tp 4606.94]») استراتژی نیستند و آمار ستاپ‌ها را خراب می‌کردند. */
        setupName: /metatrader|mt4|mt5/i.test(String(n.format || "")) ? "" : String(a("setup") || "").trim(),
        riskFree: !1,
        pre: {
          ...xl.pre
        },
        post: {
          ...xl.post,
          notes: `واردشده از ${n.format || "CSV"}`
        },
        id: Lu(),
        accountId: n.accountId,
        createdAt: new Date().toISOString(),
        hasChart: !1,
        importMeta: {
          source: n.source,
          format: n.format,
          fileName: n.fileName,
          ticket: String(g || "").trim(),
          row: e.__row,
          importedAt: new Date().toISOString()
        }
      };
      return {
        errors: [],
        trade: x
      }
    }
    
    function paImportCenter({
      trades: e,
      accounts: t,
      activeAccountId: n,
      onImport: r,
      importTimezone: paTz
    }) {
      const [a, i] = M.useState("auto"), [o, l] = M.useState(n), [s, u] = M.useState(null), [f, c] = M.useState({}), [p, h] = M.useState(""), [v, b] = M.useState(!1), [m, g] = M.useState(""),
        x = M.useMemo(() => {
          if (!s) return [];
          const U = new Set(e.filter(V => V.accountId === o).map(paTradeSignature)),
            V = new Set;
          return s.rows.map(ee => {
            const pe = paBuildImportedTrade(ee, f, {
              accountId: o,
              source: a,
              format: s.detected,
              fileName: s.fileName,
              timezone: paTz || "local"
            });
            if (pe.trade) {
              const Oe = paTradeSignature(pe.trade);
              (U.has(Oe) || V.has(Oe)) && pe.errors.push("تکراری"), V.add(Oe)
            }
            return {
              row: ee,
              ...pe,
              valid: pe.trade && !pe.errors.length
            }
          })
        }, [s, f, o, e, a, paTz]),
        y = x.filter(U => U.valid),
        O = x.filter(U => U.errors.includes("تکراری")),
        w = x.filter(U => !U.valid && !U.errors.includes("تکراری")),
        S = s && paImportFields.filter(U => U.required && !f[U.id]);
    
      M.useEffect(() => l(n), [n]);
    
      async function j(U) {
        const V = U.target.files && U.target.files[0];
        if (!V) return;
        U.target.value = "", h(""), g(""), b(!0);
        try {
          if (V.size > 15 * 1024 * 1024) throw new Error("حجم فایل باید کمتر از ۱۵ مگابایت باشد");
          const ee = await V.arrayBuffer();
          let pe;
          const Oe = new Uint8Array(ee);
          Oe[0] === 255 && Oe[1] === 254 ? pe = new TextDecoder("utf-16le").decode(ee) : Oe[0] === 254 && Oe[1] === 255 ? pe = new TextDecoder("utf-16be").decode(ee) : (pe = new TextDecoder("utf-8").decode(ee), (pe.match(/\u0000/g) || []).length > 5 && (pe = new TextDecoder("utf-16le").decode(ee)));
          const ue = paParseImportText(pe, V.name);
          ue.fileName = V.name, u(ue), c(paGuessMap(ue.columns, ue.rows)), g(`${ue.rows.length.toLocaleString("fa-IR")} ردیف از فایل خوانده شد`)
        } catch (ee) {
          u(null), c({}), h((ee == null ? void 0 : ee.message) || "فایل قابل خواندن نیست")
        } finally {
          b(!1)
        }
      }
    
      async function k() {
        if (!s || !y.length || S.length) return;
        b(!0), h("");
        try {
          const U = await r(y.map(V => V.trade), o);
          U !== !1 && (g(`${y.length.toLocaleString("fa-IR")} معامله با موفقیت وارد شد`), u(null), c({}))
        } catch (U) {
          h((U == null ? void 0 : U.message) || "ذخیره معاملات ناموفق بود")
        } finally {
          b(!1)
        }
      }
    
      function P() {
        const U = "date,symbol,direction,pnl,result,commission,swap,volume,ticket,setup,riskPercent\n2026-08-12 10:30,EURUSD,buy,125.50,profit,3.20,-0.40,0.10,10001,Breakout,1";
        const V = new Blob(["\uFEFF" + U], {
            type: "text/csv;charset=utf-8"
          }),
          ee = URL.createObjectURL(V),
          pe = document.createElement("a");
        pe.href = ee, pe.download = "trade-import-template.csv", pe.click(), setTimeout(() => URL.revokeObjectURL(ee), 500)
      }
      return M.createElement("div", {
          className: "pa-feature-page pa-import-page",
          "data-feature": "import"
        },
        M.createElement("section", {
            className: "pa-feature-hero pa-import-hero"
          },
          M.createElement("div", {
            className: "pa-feature-hero-icon"
          }, M.createElement(paImportIcon, {
            size: 26
          })),
          M.createElement("div", {
              className: "pa-feature-hero-copy"
            }, M.createElement("span", {
              className: "pa-feature-kicker"
            }, "OFFLINE IMPORT CENTER"), M.createElement("h1", null, "ورود معاملات از CSV و MetaTrader"), M.createElement("p", null, "فایل History خروجی MT4/MT5 یا CSV عمومی را بدون ارسال داده به اینترنت، اعتبارسنجی و وارد کن.")),
          M.createElement("span", {
            className: "pa-offline-badge"
          }, "● پردازش ۱۰۰٪ محلی")
        ),
        M.createElement("section", {
            className: "pa-import-layout"
          },
          M.createElement("div", {
              className: "pa-card pa-import-source"
            },
            M.createElement("div", {
              className: "pa-card-title"
            }, "۱. منبع و حساب مقصد"),
            M.createElement("div", {
                className: "pa-import-source-grid"
              }, [{
                id: "auto",
                title: "تشخیص خودکار",
                sub: "CSV / HTML / TSV"
              }, {
                id: "mt4",
                title: "MetaTrader 4",
                sub: "Account History → Save as Report"
              }, {
                id: "mt5",
                title: "MetaTrader 5",
                sub: "History → Report → HTML/CSV"
              }, {
                id: "csv",
                title: "CSV عمومی",
                sub: "ستون‌های دلخواه + Field Mapping"
              }].map(U => M.createElement("button", {
                type: "button",
                className: "pa-import-source-btn" + (a === U.id ? " active" : ""),
                onClick: () => i(U.id),
                key: U.id
              }, M.createElement("b", null, U.title), M.createElement("span", null, U.sub)))),
            M.createElement("label", {
                className: "pa-field pa-import-account"
              }, M.createElement("span", {
                className: "pa-field-label"
              }, "حساب مقصد"), M.createElement("select", {
                className: "pa-input",
                value: o,
                onChange: U => l(U.target.value)
              }, t.map(U => M.createElement("option", {
                value: U.id,
                key: U.id
              }, U.name)))),
            M.createElement("label", {
                className: "pa-import-drop"
              }, M.createElement(paImportIcon, {
                size: 30
              }), M.createElement("strong", null, v ? "در حال خواندن فایل..." : "فایل History یا CSV را انتخاب کن"), M.createElement("span", null, "CSV, TXT, TSV, HTML — حداکثر ۱۵ MB"), M.createElement("input", {
                type: "file",
                accept: ".csv,.txt,.tsv,.html,.htm,text/csv,text/html",
                onChange: j,
                disabled: v
              })),
            M.createElement("button", {
              type: "button",
              className: "pa-btn ghost sm pa-template-btn",
              onClick: P
            }, "دانلود نمونه CSV استاندارد"),
            M.createElement("div", {
              className: "pa-import-note"
            }, "به‌دلیل ماهیت فایل مستقل، اتصال زنده به ترمینال انجام نمی‌شود؛ ابتدا History را از MetaTrader خروجی بگیر."),
            M.createElement("div", {
              className: "pa-import-note"
            }, "منطقهٔ زمانی فایل: ", M.createElement("b", null, (PA_IMPORT_TZ_OPTIONS.find(U => U.id === (paTz || "local")) || PA_IMPORT_TZ_OPTIONS[0]).label), " — برای تغییر، به تنظیمات → پروفایل و ریسک برو. سشن معاملات از روی همین محاسبه می‌شود."),
            p ? M.createElement("div", {
              className: "pa-set-alert err"
            }, p) : null,
            m ? M.createElement("div", {
              className: "pa-set-alert ok"
            }, m) : null
          ),
          M.createElement("div", {
              className: "pa-card pa-import-map"
            },
            M.createElement("div", {
                className: "pa-card-head-row"
              }, M.createElement("div", null, M.createElement("div", {
                className: "pa-card-title"
              }, "۲. تطبیق ستون‌ها"), M.createElement("div", {
                className: "pa-card-sub"
              }, s ? `فرمت تشخیص‌داده‌شده: ${s.detected}` : "پس از انتخاب فایل، ستون‌ها خودکار تشخیص داده می‌شوند")), s ? M.createElement("span", {
                className: "pa-import-file-pill"
              }, s.fileName) : null),
            s ? M.createElement("div", {
                className: "pa-import-map-grid"
              }, paImportFields.map(U => M.createElement("label", {
                className: "pa-import-map-field",
                key: U.id
              }, M.createElement("span", null, U.label, U.required ? M.createElement("b", null, " *") : null), M.createElement("select", {
                className: "pa-input sm" + (U.required && !f[U.id] ? " has-error" : ""),
                value: f[U.id] || "",
                onChange: V => c(ee => ({
                  ...ee,
                  [U.id]: V.target.value
                }))
              }, M.createElement("option", {
                value: ""
              }, "نادیده گرفتن"), s.columns.map(V => M.createElement("option", {
                value: V.key,
                key: V.key
              }, V.label)))))) : M.createElement("div", {
              className: "pa-feature-empty"
            }, "هنوز فایلی انتخاب نشده است.")
          )
        ),
        s ? M.createElement("section", {
            className: "pa-card pa-import-preview"
          },
          M.createElement("div", {
              className: "pa-card-head-row"
            }, M.createElement("div", null, M.createElement("div", {
              className: "pa-card-title"
            }, "۳. پیش‌نمایش و اعتبارسنجی"), M.createElement("div", {
              className: "pa-card-sub"
            }, "ردیف‌های نامعتبر و تکراری به‌صورت امن رد می‌شوند")), M.createElement("div", {
                className: "pa-import-summary"
              }, M.createElement("span", {
                className: "ok"
              }, M.createElement("b", {
                className: "num"
              }, y.length), " آماده"), M.createElement("span", {
                className: "dup"
              }, M.createElement("b", {
                className: "num"
              }, O.length), " تکراری"), M.createElement("span", {
                className: "bad"
              }, M.createElement("b", {
                className: "num"
              }, w.length), " نامعتبر"))),
          S.length ? M.createElement("div", {
            className: "pa-set-alert err"
          }, "ستون‌های اجباری را مشخص کن: ", S.map(U => U.label).join("، ")) : null,
          M.createElement("div", {
              className: "pa-import-table-wrap"
            }, M.createElement("table", {
              className: "pa-import-table"
            }, M.createElement("thead", null, M.createElement("tr", null, ["ردیف", "وضعیت", "تاریخ", "نماد", "جهت", "P/L", "Ticket"].map(U => M.createElement("th", {
              key: U
            }, U)))), M.createElement("tbody", null, x.slice(0, 12).map((U, V) => M.createElement("tr", {
              className: U.valid ? "valid" : "invalid",
              key: V
            }, M.createElement("td", {
              className: "num"
            }, U.row.__row), M.createElement("td", null, U.valid ? M.createElement("span", {
              className: "pa-import-status ok"
            }, "آماده") : M.createElement("span", {
              className: "pa-import-status bad",
              title: U.errors.join("، ")
            }, U.errors.join("، "))), M.createElement("td", {
              className: "num"
            }, U.trade ? Cg(U.trade.entryDate) : U.row[f.date] || "—"), M.createElement("td", {
              className: "num"
            }, U.trade ? U.trade.symbol : U.row[f.symbol] || "—"), M.createElement("td", null, U.trade ? U.trade.direction.toUpperCase() : "—"), M.createElement("td", {
              className: U.trade ? "num " + (U.trade.resultType === "profit" ? "pos" : "neg") : "num"
            }, U.trade ? (U.trade.resultType === "profit" ? "+" : "-") + Ke(U.trade.amount) : "—"), M.createElement("td", {
              className: "num"
            }, U.trade && U.trade.importMeta.ticket || "—")))))),
          x.length > 12 ? M.createElement("div", {
            className: "pa-import-more"
          }, `و ${x.length - 12} ردیف دیگر…`) : null,
          M.createElement("div", {
              className: "pa-import-actions"
            }, M.createElement("span", null, y.length ? `${y.length.toLocaleString("fa-IR")} معامله در حساب «${(t.find(U=>U.id===o)||{}).name||"—"}» ذخیره می‌شود.` : "هیچ ردیف معتبری برای ورود وجود ندارد."), M.createElement("button", {
              type: "button",
              className: "pa-btn primary",
              disabled: v || !y.length || S.length,
              onClick: k
            }, v ? "در حال ذخیره…" : `ورود ${y.length.toLocaleString("fa-IR")} معامله`))
        ) : null
      )
    }
    registry["import"] = paImportCenter;
  }
})();
