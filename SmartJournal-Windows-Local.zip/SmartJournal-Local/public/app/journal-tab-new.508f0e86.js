/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paSymbolSearchPicker({
      value,
      onChange
    }) {
      const wrapRef = M.useRef(null),
        selected = Us.find(item => item.id === value) || Us[0],
        selectedLabel = selected.fa + " (" + selected.code + ")",
        [query, setQuery] = M.useState(selectedLabel),
        [open, setOpen] = M.useState(!1),
        [activeIndex, setActiveIndex] = M.useState(0);
      M.useEffect(() => {
        setQuery(selectedLabel)
      }, [value, selectedLabel]);
      M.useEffect(() => {
        const close = event => {
          wrapRef.current && !wrapRef.current.contains(event.target) && (setOpen(!1), setQuery(selectedLabel))
        };
        document.addEventListener("pointerdown", close);
        return () => document.removeEventListener("pointerdown", close)
      }, [selectedLabel]);
      const cleanQuery = query.trim().toLowerCase(),
        isCurrentLabel = cleanQuery === selectedLabel.toLowerCase(),
        filtered = M.useMemo(() => {
          if (!cleanQuery || isCurrentLabel) return Us;
          return Us.filter(item => [item.fa, item.code, item.id, item.group].filter(Boolean).join(" ").toLowerCase().includes(cleanQuery))
        }, [cleanQuery, isCurrentLabel]),
        grouped = M.useMemo(() => {
          const result = [];
          filtered.forEach(item => {
            const groupName = item.group || "سایر";
            let group = result.find(entry => entry[0] === groupName);
            group || (group = [groupName, []], result.push(group));
            group[1].push(item)
          });
          return result
        }, [filtered]),
        choose = item => {
          item && (onChange(item.id), setQuery(item.fa + " (" + item.code + ")"), setOpen(!1), setActiveIndex(0))
        },
        keyDown = event => {
          if (event.key === "ArrowDown") {
            event.preventDefault(), setOpen(!0), setActiveIndex(index => Math.min(filtered.length - 1, index + 1))
          } else if (event.key === "ArrowUp") {
            event.preventDefault(), setOpen(!0), setActiveIndex(index => Math.max(0, index - 1))
          } else if (event.key === "Enter" && open) {
            event.preventDefault(), choose(filtered[activeIndex])
          } else if (event.key === "Escape") {
            event.preventDefault(), setOpen(!1), setQuery(selectedLabel)
          }
        };
      M.useEffect(() => {
        setActiveIndex(0)
      }, [cleanQuery]);
      return d.jsxs("div", {
        className: "pa-symbol-search",
        ref: wrapRef,
        children: [d.jsxs("div", {
          className: "pa-symbol-search-input-wrap" + (open ? " is-open" : ""),
          children: [d.jsx("span", {
            className: "pa-symbol-search-icon",
            "aria-hidden": "true",
            children: "⌕"
          }), d.jsx("input", {
            className: "pa-input pa-symbol-search-input",
            type: "search",
            value: query,
            placeholder: "جستجوی نام یا نماد؛ مثل طلا یا XAUUSD",
            autoComplete: "off",
            role: "combobox",
            "aria-expanded": open,
            "aria-controls": "pa-symbol-search-list",
            "aria-autocomplete": "list",
            onFocus: event => {
              setOpen(!0), event.currentTarget.select()
            },
            onChange: event => {
              setQuery(event.target.value), setOpen(!0)
            },
            onKeyDown: keyDown
          }), d.jsx("button", {
            type: "button",
            className: "pa-symbol-search-toggle",
            tabIndex: -1,
            "aria-label": open ? "بستن فهرست نمادها" : "باز کردن فهرست نمادها",
            onClick: () => setOpen(current => !current),
            children: "⌄"
          })]
        }), open && d.jsx("div", {
          className: "pa-symbol-search-menu",
          id: "pa-symbol-search-list",
          role: "listbox",
          children: filtered.length ? grouped.map(group => d.jsxs("section", {
            className: "pa-symbol-search-group",
            children: [d.jsx("div", {
              className: "pa-symbol-search-group-label",
              children: group[0]
            }), group[1].map(item => {
              const itemIndex = filtered.indexOf(item);
              return d.jsxs("button", {
                type: "button",
                role: "option",
                "aria-selected": item.id === value,
                className: "pa-symbol-search-option" + (itemIndex === activeIndex ? " is-active" : "") + (item.id === value ? " is-selected" : ""),
                onMouseDown: event => event.preventDefault(),
                onMouseEnter: () => setActiveIndex(itemIndex),
                onClick: () => choose(item),
                children: [d.jsx("i", {
                  style: {
                    background: item.color || "#22d3ee"
                  }
                }), d.jsxs("span", {
                  children: [d.jsx("b", {
                    children: item.fa
                  }), d.jsx("small", {
                    children: item.group
                  })]
                }), d.jsx("strong", {
                  dir: "ltr",
                  children: item.code
                })]
              }, item.id)
            })]
          }, group[0])) : d.jsxs("div", {
            className: "pa-symbol-search-empty",
            children: [d.jsx("b", {
              children: "نمادی پیدا نشد"
            }), d.jsx("span", {
              children: "نام فارسی یا کد بازار را بررسی کن."
            })]
          })
        })]
      })
    }
    
    function wZ({
      form: e,
      formTab: t,
      setFormTab: n,
      updateForm: r,
      updatePre: a,
      updatePost: i,
      toggleArr: o,
      onSubmit: l,
      onReset: s,
      onChartFile: u,
      onChartDrop: f,
      chartUploading: c,
      onZoomImage: p,
      activeAccountName: h,
      currentBalance: v,
      errors: b = {},
      accountTrades: m = [],
      editingId: g = null
    }) {
      const [x, y] = M.useState(!1);
    
      function O(_) {
        y(!1), f(_)
      }
      const w = e.riskPercent && v ? Number(e.riskPercent) / 100 * v : null,
        S = w !== null && e.plannedRR ? w * Number(e.plannedRR) : null,
        j = e.entryDate ? Tg(e.entryDate) : null,
        k = M.useMemo(() => {
          const _ = m.map(C => {
            var z;
            return (z = C.setupName) == null ? void 0 : z.trim()
          }).filter(Boolean);
          return [...new Set(_)].slice(0, 20)
        }, [m]),
        P = ["entryDate", "positionSize", "riskPercent", "plannedRR", "setupName", "amount"],
        E = P.filter(_ => e[_] !== "" && e[_] !== null && e[_] !== void 0).length,
        N = Math.round(E / P.length * 100),
        $ = [e.pre.matchesPlan, e.pre.rrAcceptable, e.pre.sizeMatchesRisk, e.pre.newsUpcoming, e.pre.checkedOtherTimeframes],
        L = $.filter(_ => _ !== null).length + (e.pre.emotionBefore ? 1 : 0),
        D = $.length + 1,
        R = (e.post.emotionAfter ? 1 : 0) + (e.post.notes.trim() ? 1 : 0),
        B = 2;
      return d.jsxs("div", {
        className: "pa-form-wrap",
        id: "pa-new-trade-form",
        children: [d.jsxs("header", {
          className: "pa-form-hero",
          children: [d.jsx("span", {
            className: "pa-form-hero-glow",
            "aria-hidden": "true"
          }), d.jsxs("div", {
            className: "pa-form-hero-l",
            children: [d.jsxs("span", {
              className: "pa-form-hero-eyebrow",
              children: [d.jsx(g ? u2 : QE, {
                size: 12
              }), g ? "ویرایش معامله" : "ثبت معامله جدید"]
            }), d.jsx("h2", {
              className: "pa-form-hero-title",
              children: g ? "ویرایش معامله ثبت‌شده" : "معامله‌ات را دقیق ثبت کن"
            }), d.jsx("p", {
              className: "pa-form-hero-desc",
              children: "پنج گام کوتاه تا یک رکورد کامل: اطلاعات معامله، مدیریت ریسک، نتیجه مالی، مستندات و در پایان روانشناسی و بازبینی."
            })]
          }), d.jsxs("div", {
            className: "pa-form-hero-meta",
            children: [d.jsxs("span", {
              className: "pa-hero-pill",
              children: [d.jsx(Sy, {
                size: 12
              }), " ", h]
            }), d.jsxs("span", {
              className: "pa-hero-pill",
              children: [d.jsx(Xa, {
                size: 12
              }), " پنج گام"]
            }), d.jsxs("span", {
              className: "pa-hero-pill",
              children: [d.jsx(Oc, {
                size: 12
              }), " کمتر از دو دقیقه"]
            }), d.jsxs("span", {
              className: "pa-hero-pill pa-autosave-pill",
              children: ["● ", "ذخیره خودکار فعال"]
            })]
          })]
        }), d.jsxs("aside", {
          className: "pa-form-rail",
          children: [d.jsxs("div", {
            className: "pa-rail-top",
            children: [d.jsx("div", {
              className: "pa-rail-ring",
              "data-full": N === 100 ? "1" : "0",
              style: {
                "--pa-p": N
              },
              children: d.jsxs("span", {
                className: "pa-rail-ring-val num",
                children: [N, "٪"]
              })
            }), d.jsxs("div", {
              className: "pa-rail-top-txt",
              children: [d.jsx("span", {
                className: "pa-rail-top-t",
                children: "پیشرفت تکمیل"
              }), d.jsxs("span", {
                className: "pa-rail-top-s num",
                children: [E, " از ", P.length, " فیلد اصلی"]
              })]
            })]
          }), d.jsx("ol", {
            className: "pa-rail-steps",
            children: [d.jsxs("li", {
              className: "pa-rail-step" + ((e.entryDate && e.setupName ? " done" : e.entryDate || e.setupName ? " partial" : "")),
              "data-go": "info",
              children: [d.jsx("span", {
                className: "pa-rail-step-n",
                children: "1"
              }), d.jsxs("span", {
                className: "pa-rail-step-b",
                children: [d.jsx("span", {
                  className: "pa-rail-step-t",
                  children: "اطلاعات معامله"
                }), d.jsx("span", {
                  className: "pa-rail-step-s",
                  children: "نماد، جهت و زمان ورود"
                })]
              })]
            }, "info"), d.jsxs("li", {
              className: "pa-rail-step" + ((e.positionSize && e.riskPercent && e.plannedRR ? " done" : e.positionSize || e.riskPercent || e
                .plannedRR ? " partial" : "")),
              "data-go": "risk",
              children: [d.jsx("span", {
                className: "pa-rail-step-n",
                children: "2"
              }), d.jsxs("span", {
                className: "pa-rail-step-b",
                children: [d.jsx("span", {
                  className: "pa-rail-step-t",
                  children: "مدیریت ریسک"
                }), d.jsx("span", {
                  className: "pa-rail-step-s",
                  children: "حجم، درصد ریسک و R:R"
                })]
              })]
            }, "risk"), d.jsxs("li", {
              className: "pa-rail-step" + ((e.amount ? " done" : "")),
              "data-go": "result",
              children: [d.jsx("span", {
                className: "pa-rail-step-n",
                children: "3"
              }), d.jsxs("span", {
                className: "pa-rail-step-b",
                children: [d.jsx("span", {
                  className: "pa-rail-step-t",
                  children: "نتیجه مالی"
                }), d.jsx("span", {
                  className: "pa-rail-step-s",
                  children: "سود یا ضرر نهایی"
                })]
              })]
            }, "result"), d.jsxs("li", {
              className: "pa-rail-step" + ((e.chartImageData ? " done" : "")),
              "data-go": "docs",
              children: [d.jsx("span", {
                className: "pa-rail-step-n",
                children: "4"
              }), d.jsxs("span", {
                className: "pa-rail-step-b",
                children: [d.jsx("span", {
                  className: "pa-rail-step-t",
                  children: "مستندات"
                }), d.jsx("span", {
                  className: "pa-rail-step-s",
                  children: "تصویر چارت (اختیاری)"
                })]
              })]
            }, "docs"), d.jsxs("li", {
              className: "pa-rail-step" + ((L === D && R === B ? " done" : L || R ? " partial" : "")),
              "data-go": "psy",
              children: [d.jsx("span", {
                className: "pa-rail-step-n",
                children: "5"
              }), d.jsxs("span", {
                className: "pa-rail-step-b",
                children: [d.jsx("span", {
                  className: "pa-rail-step-t",
                  children: "روانشناسی و بازبینی"
                }), d.jsx("span", {
                  className: "pa-rail-step-s",
                  children: "چک‌لیست ذهنی و مرور نهایی"
                })]
              }), d.jsxs("span", {
                className: "pa-rail-step-c num",
                children: [L + R, "/", D + B]
              })]
            }, "psy")]
          }), d.jsxs("div", {
            className: "pa-rail-summary",
            children: [d.jsxs("div", {
              className: "pa-rail-summary-h",
              children: [d.jsx(VE, {
                size: 12
              }), " خلاصه معامله"]
            }), d.jsxs("div", {
              className: "pa-rail-row",
              children: [d.jsx("span", {
                children: "نماد"
              }), d.jsx("span", {
                className: "pa-rail-v",
                children: (Us.find(x => x.id === e.symbol) || {
                  fa: "—"
                }).fa
              })]
            }), d.jsxs("div", {
              className: "pa-rail-row",
              children: [d.jsx("span", {
                children: "جهت"
              }), d.jsx("span", {
                className: "pa-rail-v " + (e.direction === "buy" ? "up" : "down"),
                children: e.direction === "buy" ? "خرید" : "فروش"
              })]
            }), d.jsxs("div", {
              className: "pa-rail-row",
              children: [d.jsx("span", {
                children: "درصد ریسک"
              }), d.jsx("span", {
                className: "pa-rail-v num",
                children: e.riskPercent ? e.riskPercent + "٪" : "—"
              })]
            }), d.jsxs("div", {
              className: "pa-rail-row",
              children: [d.jsx("span", {
                children: "نسبت R:R"
              }), d.jsx("span", {
                className: "pa-rail-v num",
                children: e.plannedRR ? "1 : " + e.plannedRR : "—"
              })]
            }), d.jsxs("div", {
              className: "pa-rail-row",
              children: [d.jsx("span", {
                children: "نتیجه"
              }), d.jsx("span", {
                className: "pa-rail-v num " + (e.amount ? e.resultType === "profit" ? "up" : "down" : ""),
                children: e.amount ? (e.resultType === "profit" ? "+" : "-") + Ke(e.amount) : "—"
              })]
            })]
          })]
        }), g ? d.jsxs("div", {
          className: "pa-account-note pa-edit-note",
          children: [d.jsx(u2, {
            size: 13
          }), " در حال ویرایش یک معامله ثبت‌شده هستی — با ذخیره، نسخه قبلی جایگزین می‌شود"]
        }) : d.jsxs("div", {
          className: "pa-account-note",
          children: [d.jsx(o$, {
            size: 13
          }), " این معامله در حساب «", h, "» ثبت می‌شود"]
        }), d.jsxs("div", {
          className: "pa-card",
          "data-sec": "info",
          "data-state": (e.entryDate && e.setupName ? "done" : e.entryDate || e.setupName ? "partial" : "idle"),
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(JE, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " اطلاعات معامله", d.jsx("span", {
              className: "pa-card-sub",
              children: "نماد، جهت، زمان ورود و ستاپ معامله"
            })]
          }), d.jsxs("div", {
            className: "pa-form-grid",
            children: [d.jsx(Qe, {
              label: "جستجو و انتخاب نماد معاملاتی",
              hint: "نام فارسی یا کد نماد را بنویس و از فهرست کشویی انتخاب کن.",
              children: d.jsx(paSymbolSearchPicker, {
                value: e.symbol,
                onChange: _ => r({
                  symbol: _
                })
              })
            }), d.jsx(Qe, {
              label: "جهت",
              children: d.jsx(Xp, {
                options: [{
                  value: "buy",
                  label: "خرید (Buy)",
                  tone: "green"
                }, {
                  value: "sell",
                  label: "فروش (Sell)",
                  tone: "red"
                }],
                value: e.direction,
                onChange: _ => r({
                  direction: _
                })
              })
            }), d.jsxs(Qe, {
              label: "تاریخ و ساعت ورود",
              required: !0,
              children: [d.jsxs("div", {
                className: "pa-date-row",
                children: [d.jsx("input", {
                  type: "datetime-local",
                  className: "pa-input pa-date-input" + (b.entryDate ? " has-error" : ""),
                  value: e.entryDate,
                  onChange: _ => r({
                    entryDate: _.target.value
                  })
                }), d.jsx("button", {
                  type: "button",
                  className: "pa-btn ghost sm pa-now-btn",
                  onClick: () => r({
                    entryDate: XQ()
                  }),
                  children: "الان"
                })]
              }), j && d.jsxs("div", {
                className: "pa-field-hint pa-session-hint",
                children: [d.jsx(Oc, {
                  size: 11
                }), " سشن: ", j]
              })]
            }), d.jsx(Qe, {
              label: "تایم‌فریم",
              children: d.jsx("select", {
                className: "pa-input",
                value: e.timeframe,
                onChange: _ => r({
                  timeframe: _.target.value
                }),
                children: FQ.map(_ => d.jsx("option", {
                  value: _,
                  children: _
                }, _))
              })
            }), d.jsx(Qe, {
              label: "مدت زمان باز بودن معامله",
              hint: "از لحظه ورود تا لحظه بستن معامله",
              children: d.jsxs("div", {
                className: "pa-date-row",
                children: [d.jsx("input", {
                  type: "number",
                  min: "0",
                  step: "1",
                  className: "pa-input",
                  placeholder: "مثلاً 45",
                  value: e.durationValue,
                  onChange: _ => r({
                    durationValue: _.target.value
                  })
                }), d.jsx("select", {
                  className: "pa-input",
                  style: {
                    maxWidth: 110
                  },
                  value: e.durationUnit,
                  onChange: _ => r({
                    durationUnit: _.target.value
                  }),
                  children: Ov.map(_ => d.jsx("option", {
                    value: _.id,
                    children: _.fa
                  }, _.id))
                })]
              })
            }), d.jsxs(Qe, {
              label: "نام ستاپ / استراتژی",
              children: [d.jsx("input", {
                type: "text",
                list: "pa-setup-suggestions",
                className: "pa-input",
                placeholder: "مثلاً Order Block + BOS",
                value: e.setupName,
                onChange: _ => r({
                  setupName: _.target.value
                })
              }), d.jsx("datalist", {
                id: "pa-setup-suggestions",
                children: k.map(_ => d.jsx("option", {
                  value: _
                }, _))
              })]
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-card",
          "data-sec": "risk",
          "data-state": (e.positionSize && e.riskPercent && e.plannedRR ? "done" : e.positionSize || e.riskPercent || e.plannedRR ? "partial" : "idle"),
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(Qa, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " مدیریت ریسک", d.jsx("span", {
              className: "pa-card-sub",
              children: "حجم پوزیشن، درصد ریسک و نسبت ریسک به ریوارد"
            })]
          }), d.jsxs("div", {
            className: "pa-form-grid",
            children: [d.jsx(Qe, {
              label: "حجم معامله (لات)",
              required: !0,
              children: d.jsx("input", {
                type: "number",
                step: "0.01",
                className: "pa-input" + (b.positionSize ? " has-error" : ""),
                placeholder: "0.00",
                value: e.positionSize,
                onChange: _ => r({
                  positionSize: _.target.value
                })
              })
            }), d.jsx(Qe, {
              label: "درصد ریسک این معامله (%)",
              required: !0,
              hint: w !== null ? `≈ ${Ke(w)} از موجودی فعلی` : "با وارد کردن این عدد، مبلغ ریسک به‌صورت خودکار محاسبه می‌شود",
              children: d.jsx("input", {
                type: "number",
                step: "0.1",
                className: "pa-input" + (b.riskPercent ? " has-error" : ""),
                placeholder: "مثلاً 1",
                value: e.riskPercent,
                onChange: _ => r({
                  riskPercent: _.target.value
                })
              })
            }), d.jsx(Qe, {
              label: "ریسک به ریوارد برنامه‌ریزی‌شده (1 : X)",
              hint: S !== null ? `≈ ${Ke(S)} پاداش هدف‌گذاری‌شده` : null,
              children: d.jsx("input", {
                type: "number",
                step: "0.1",
                className: "pa-input",
                placeholder: "مثلاً 2.5",
                value: e.plannedRR,
                onChange: _ => r({
                  plannedRR: _.target.value
                })
              })
            }), d.jsx(Qe, {
              label: "وضعیت ریسک",
              children: d.jsxs("label", {
                className: "pa-switch-row",
                children: [d.jsx("span", {
                  children: "معامله ریسک‌فری / بدون تاثیر در وین‌ریت است؟"
                }), d.jsx("button", {
                  type: "button",
                  className: "pa-switch" + (e.riskFree ? " on" : ""),
                  onClick: () => r({
                    riskFree: !e.riskFree
                  }),
                  children: d.jsx("span", {
                    className: "pa-switch-dot"
                  })
                })]
              })
            })]
          }), d.jsxs("div", {
            className: "pa-live",
            children: [d.jsxs("div", {
              className: "pa-live-h",
              children: [d.jsx(Yh, {
                size: 12
              }), "محاسبه زنده ریسک"]
            }), d.jsxs("div", {
              className: "pa-metrics",
              children: [d.jsxs("div", {
                className: "pa-metric risk",
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "مبلغ ریسک"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: w !== null ? Ke(w) : "—"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: "از موجودی " + Ke(v)
                })]
              }), d.jsxs("div", {
                className: "pa-metric rew",
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "پاداش هدف"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: S !== null ? Ke(S) : "—"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: e.plannedRR ? "در نسبت 1 : " + e.plannedRR : "نسبت R:R را وارد کن"
                })]
              }), d.jsxs("div", {
                className: "pa-metric",
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "حجم پوزیشن"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: e.positionSize ? e.positionSize + " لات" : "—"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: "حجمی که وارد بازار می‌شود"
                })]
              }), d.jsxs("div", {
                className: "pa-metric " + (e.riskFree ? "ok" : ""),
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "وضعیت ریسک"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: e.riskFree ? "ریسک‌فری" : "ریسک باز"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: e.riskFree ? "بدون تاثیر در وین‌ریت" : "در وین‌ریت محاسبه می‌شود"
                })]
              })]
            }), d.jsxs("div", {
              className: "pa-rr-bar",
              style: {
                "--pa-rr": e.plannedRR ? Math.min(Math.max(Number(e.plannedRR) || 1, .35), 6) : 1
              },
              children: [d.jsxs("span", {
                className: "pa-rr-seg risk",
                children: [d.jsx("b", {
                  children: "ریسک"
                }), d.jsx("i", {
                  className: "num",
                  children: w !== null ? Ke(w) : "—"
                })]
              }), d.jsxs("span", {
                className: "pa-rr-seg rew",
                children: [d.jsx("b", {
                  children: "پاداش"
                }), d.jsx("i", {
                  className: "num",
                  children: S !== null ? Ke(S) : "—"
                })]
              })]
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-card",
          "data-sec": "result",
          "data-state": (e.amount ? "done" : "idle"),
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(Sy, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " نتیجه مالی", d.jsx("span", {
              className: "pa-card-sub",
              children: "سود یا ضرر نهایی به همراه کمیسیون و سواپ"
            })]
          }), d.jsxs("div", {
            className: "pa-form-grid",
            children: [d.jsx(Qe, {
              label: "نتیجه معامله",
              children: d.jsx(Xp, {
                options: [{
                  value: "profit",
                  label: "سود",
                  tone: "green"
                }, {
                  value: "loss",
                  label: "ضرر",
                  tone: "red"
                }],
                value: e.resultType,
                onChange: _ => r({
                  resultType: _
                })
              })
            }), d.jsx(Zp, {
              label: "مقدار سود / ضرر",
              required: !0,
              error: b.amount,
              value: e.amount,
              onChange: _ => r({
                amount: _.target.value
              })
            }), d.jsx(Zp, {
              label: "کمیسیون (اختیاری)",
              value: e.commission,
              onChange: _ => r({
                commission: _.target.value
              })
            }), d.jsx(Zp, {
              label: "سواپ (اختیاری)",
              value: e.swap,
              onChange: _ => r({
                swap: _.target.value
              })
            })]
          }), d.jsxs("div", {
            className: "pa-live",
            children: [d.jsxs("div", {
              className: "pa-live-h",
              children: [d.jsx(VE, {
                size: 12
              }), "خالص این معامله"]
            }), d.jsxs("div", {
              className: "pa-metrics",
              children: [d.jsxs("div", {
                className: "pa-metric " + (e.amount ? e.resultType === "profit" ? "rew" : "risk" : ""),
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "ناخالص"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: e.amount ? (e.resultType === "profit" ? "+" : "-") + Ke(e.amount) : "—"
                })]
              }), d.jsxs("div", {
                className: "pa-metric",
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "کمیسیون و سواپ"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: Number(e.commission || 0) || Number(e.swap || 0) ? Ke(Number(e.swap || 0) - Number(e.commission ||
                    0)) : "—"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: "سواپ منهای کمیسیون"
                })]
              }), d.jsxs("div", {
                className: "pa-metric " + (e.amount ? wr(e) >= 0 ? "rew" : "risk" : ""),
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "خالص نهایی"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: e.amount ? Ke(wr(e)) : "—"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: e.riskFree ? "ریسک‌فری — خنثی" : "پس از کسورات"
                })]
              }), d.jsxs("div", {
                className: "pa-metric " + (w && e.amount ? wr(e) >= 0 ? "rew" : "risk" : ""),
                children: [d.jsx("span", {
                  className: "pa-metric-l",
                  children: "R واقعی"
                }), d.jsx("span", {
                  className: "pa-metric-v num",
                  children: w && e.amount ? (wr(e) / w >= 0 ? "+" : "") + (wr(e) / w).toFixed(2) + "R" : "—"
                }), d.jsx("span", {
                  className: "pa-metric-f",
                  children: w ? "در برابر ریسک " + Ke(w) : "درصد ریسک را وارد کن"
                })]
              })]
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-card pa-form-documentation",
          "data-sec": "docs",
          "data-state": (e.chartImageData || e.afterImageData ? "done" : "idle"),
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(jc, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " مستندات تصویری", d.jsx("span", {
              className: "pa-card-sub",
              children: "چارت قبل از ورود و بعد از خروج؛ حاشیه‌نویسی پیشرفته در استودیوی مستندات"
            })]
          }), d.jsxs("div", {
            className: "pa-form-doc-grid",
            children: [["before", "قبل از ورود", e.chartImageData], ["after", "بعد از خروج", e.afterImageData]].map(_ => d.jsx(Qe, {
              label: _[1] + " (اختیاری)",
              children: d.jsxs("div", {
                className: "pa-chart-upload pa-dropzone" + (c ? " uploading" : ""),
                onDragOver: C => C.preventDefault(),
                onDrop: C => f(C, _[0]),
                children: [d.jsxs("label", {
                  className: "pa-upload-btn",
                  children: [d.jsx(jc, {
                    size: 14
                  }), " ", c ? "در حال پردازش…" : "انتخاب یا رها کردن تصویر", d.jsx("input", {
                    type: "file",
                    accept: "image/*",
                    onChange: C => u(C, _[0]),
                    hidden: !0,
                    disabled: c
                  })]
                }), _[2] && !c && d.jsxs("div", {
                  className: "pa-chart-preview-wrap",
                  children: [d.jsx(eA, {
                    src: _[2],
                    className: "pa-chart-preview",
                    alt: "پیش‌نمایش " + _[1],
                    onZoom: p
                  }), d.jsx("button", {
                    type: "button",
                    className: "pa-btn ghost sm",
                    onClick: () => r(_[0] === "before" ? {
                      chartImageData: null
                    } : {
                      afterImageData: null
                    }),
                    children: "حذف تصویر"
                  })]
                })]
              })
            }, _[0]))
          }), d.jsx(Qe, {
            label: "تگ‌های تصویر",
            children: d.jsx("input", {
              className: "pa-input",
              value: (e.imageTags || []).join("، "),
              placeholder: "مثلاً شکست، پولبک، نقدینگی",
              onChange: _ => r({
                imageTags: _.target.value.split(/[،,]/).map(C => C.trim()).filter(Boolean).slice(0, 12)
              })
            })
          }), d.jsx("div", {
            className: "pa-form-doc-hint",
            children: "بعد از ثبت معامله، از تب «مستندات» برای قلم، پیکان، متن روی چارت، مقایسه قبل/بعد و گالری ستاپ‌ها استفاده کن."
          })]
        }), d.jsxs("div", {
          className: "pa-card",
          "data-sec": "psy",
          "data-state": (L === D && R === B ? "done" : b.pre || b.post ? "error" : L || R ? "partial" : "idle"),
          children: [d.jsxs("div", {
            className: "pa-card-title",
            children: [d.jsx(i2, {
              size: 15,
              style: {
                verticalAlign: "-2px"
              }
            }), " روانشناسی و بازبینی", d.jsx("span", {
              className: "pa-card-sub",
              children: "چک‌لیست ذهنی پیش از ورود، بازخورد پس از خروج و مرور نهایی پیش از ثبت"
            })]
          }), d.jsxs("div", {
            className: "pa-psy-req" + (L === D && R === B ? " done" : "") + (L === D && R === B ? "" : b.pre || b.post ? " err" : ""),
            children: [d.jsxs("div", {
              className: "pa-psy-req-h",
              children: [d.jsxs("span", {
                className: "pa-psy-req-t",
                children: [d.jsx(L === D && R === B ? oa : Ac, {
                  size: 13
                }), d.jsx("span", {
                  children: L === D && R === B ? "همه فیلدهای اجباری روانشناسی تکمیل شده" : "فیلدهای اجباری روانشناسی — بدون این‌ها معامله ثبت نمی‌شود"
                })]
              }), d.jsxs("span", {
                className: "pa-psy-req-c num",
                children: [L + R, " / ", D + B]
              })]
            }), d.jsx("div", {
              className: "pa-psy-req-bar",
              children: d.jsx("span", {
                style: {
                  width: Math.round((L + R) / (D + B) * 100) + "%"
                }
              })
            }), d.jsxs("div", {
              className: "pa-psy-req-chips",
              children: [d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (e.pre.matchesPlan !== null ? " ok" : ""),
                onClick: () => n("pre"),
                children: [e.pre.matchesPlan !== null ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "مطابق پلن مکتوب"
                })]
              }, "مطابق پلن مکتوب"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (e.pre.rrAcceptable !== null ? " ok" : ""),
                onClick: () => n("pre"),
                children: [e.pre.rrAcceptable !== null ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "R:R قابل قبول"
                })]
              }, "R:R قابل قبول"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (e.pre.sizeMatchesRisk !== null ? " ok" : ""),
                onClick: () => n("pre"),
                children: [e.pre.sizeMatchesRisk !== null ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "تناسب حجم با ریسک"
                })]
              }, "تناسب حجم با ریسک"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (e.pre.newsUpcoming !== null ? " ok" : ""),
                onClick: () => n("pre"),
                children: [e.pre.newsUpcoming !== null ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "خبر مهم در پیش"
                })]
              }, "خبر مهم در پیش"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (e.pre.checkedOtherTimeframes !== null ? " ok" : ""),
                onClick: () => n("pre"),
                children: [e.pre.checkedOtherTimeframes !== null ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "چک تایم‌فریم‌ها"
                })]
              }, "چک تایم‌فریم‌ها"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (!!e.pre.emotionBefore ? " ok" : ""),
                onClick: () => n("pre"),
                children: [!!e.pre.emotionBefore ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "احساس قبل از ورود"
                })]
              }, "احساس قبل از ورود"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (!!e.post.emotionAfter ? " ok" : ""),
                onClick: () => n("post"),
                children: [!!e.post.emotionAfter ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "احساس بعد از خروج"
                })]
              }, "احساس بعد از خروج"), d.jsxs("button", {
                type: "button",
                className: "pa-psy-chip" + (!!e.post.notes.trim() ? " ok" : ""),
                onClick: () => n("post"),
                children: [!!e.post.notes.trim() ? d.jsx(oa, {
                  size: 11
                }) : d.jsx("span", {
                  className: "pa-psy-chip-dot"
                }), d.jsx("span", {
                  children: "یادداشت و درس‌آموخته"
                })]
              }, "یادداشت و درس‌آموخته")]
            })]
          }), e.pre.matchesPlan === !1 ? d.jsxs("div", {
            className: "pa-plan-verdict bad",
            children: [d.jsx("span", {
              className: "pa-plan-verdict-i",
              children: d.jsx(Ac, {
                size: 17
              })
            }), d.jsxs("div", {
              className: "pa-plan-verdict-b",
              children: [d.jsx("b", {
                children: "مراقب باش — این معامله خارج از پلن مکتوبت بود"
              }), d.jsx("span", {
                children: "سود یا ضررش مهم نیست؛ چیزی که می‌ماند عادت است. دلیل این تخطی را در یادداشت پایانی بنویس، و تا وقتی پلن را اصلاح نکرده‌ای دوباره همین کار را نکن."
              })]
            })]
          }) : e.pre.matchesPlan === !0 ? d.jsxs("div", {
            className: "pa-plan-verdict good",
            children: [d.jsx("span", {
              className: "pa-plan-verdict-i",
              children: d.jsx(Qa, {
                size: 17
              })
            }), d.jsxs("div", {
              className: "pa-plan-verdict-b",
              children: [d.jsx("b", {
                children: "طبق پلن مکتوب جلو رفتی"
              }), d.jsx("span", {
                children: "همین انضباط است که در بلندمدت حساب را می‌سازد — نتیجه این معامله هرچه باشد، اجرا درست بوده."
              })]
            })]
          }) : null, d.jsxs("div", {
            className: "pa-subtabs",
            children: [d.jsxs("button", {
              className: "pa-subtab" + (t === "pre" ? " active" : "") + (b.pre && L !== D ? " err" : ""),
              onClick: () => n("pre"),
              children: ["قبل از معامله ", L === D ? d.jsx(oa, {
                size: 12,
                className: "pa-subtab-check"
              }) : d.jsxs("span", {
                className: "pa-subtab-count num",
                children: [L, "/", D]
              })]
            }), d.jsxs("button", {
              className: "pa-subtab" + (t === "post" ? " active" : "") + (b.post && R !== B ? " err" : ""),
              onClick: () => n("post"),
              children: ["بعد از معامله ", R === B ? d.jsx(oa, {
                size: 12,
                className: "pa-subtab-check"
              }) : d.jsxs("span", {
                className: "pa-subtab-count num",
                children: [R, "/", B]
              })]
            }), d.jsx("button", {
              className: "pa-subtab" + (t === "basic" ? " active" : ""),
              onClick: () => n("basic"),
              children: "بازبینی نهایی"
            })]
          }), t === "pre" && d.jsxs("div", {
            className: "pa-q-list",
            children: [d.jsx(wi, {
              icon: Xa,
              tone: "pa-q-plan",
              required: !0,
              note: "این معامله بیرون از پلن مکتوبت اجرا شده. حتی اگر سود بدهد، تکرارش یک عادت پرهزینه می‌سازد — دلیل این تخطی را در یادداشت پایانی بنویس و پیش از معامله بعدی پلن را دوباره بخوان.",
              text: "آیا این معامله دقیقاً مطابق پلن مکتوب معاملاتی‌ات بود؟",
              value: e.pre.matchesPlan,
              onChange: _ => a({
                matchesPlan: _,
                followedSetup: _
              })
            }), d.jsx(wi, {
              icon: wy,
              required: !0,
              text: "آیا Risk/Reward قابل قبول است؟",
              value: e.pre.rrAcceptable,
              onChange: _ => a({
                rrAcceptable: _
              })
            }), d.jsx(wi, {
              icon: Qa,
              required: !0,
              text: "آیا حجم پوزیشن متناسب با ریسک است؟",
              value: e.pre.sizeMatchesRisk,
              onChange: _ => a({
                sizeMatchesRisk: _
              })
            }), d.jsx(wi, {
              icon: s2,
              required: !0,
              text: "آیا خبر مهمی در پیش است؟",
              value: e.pre.newsUpcoming,
              onChange: _ => a({
                newsUpcoming: _
              })
            }), d.jsx(wi, {
              icon: Oc,
              required: !0,
              text: "آیا بقیه تایم‌فریم‌ها رو هم قبل از ورود چک کردی؟",
              value: e.pre.checkedOtherTimeframes,
              onChange: _ => a({
                checkedOtherTimeframes: _
              })
            }), d.jsx("div", {
              className: "pa-divider"
            }), d.jsx(Qe, {
              label: "وضعیت احساسی قبل از ورود",
              required: !0,
              err: !!b.pre && !e.pre.emotionBefore,
              children: d.jsx(bl, {
                options: UQ,
                value: e.pre.emotionBefore,
                multi: !1,
                onToggle: _ => a({
                  emotionBefore: _
                })
              })
            }), d.jsx(Qp, {
              label: "سطح انرژی و آمادگی جسمانی",
              lowLabel: "خیلی کم",
              highLabel: "عالی",
              value: e.pre.energyLevel,
              onChange: _ => a({
                energyLevel: _
              })
            }), d.jsx(Qp, {
              label: "اعتماد به ستاپ",
              lowLabel: "خیلی کم",
              highLabel: "خیلی زیاد",
              value: e.pre.setupConfidence,
              onChange: _ => a({
                setupConfidence: _
              })
            }), d.jsx(Qe, {
              label: "انگیزه ورود (چند گزینه‌ای)",
              children: d.jsx(bl, {
                options: HQ,
                value: e.pre.motivations,
                onToggle: _ => a({
                  motivations: o(e.pre.motivations, _)
                })
              })
            }), d.jsx(Qe, {
              label: "وضعیت روانی خاص",
              children: d.jsx(bl, {
                options: VQ,
                value: e.pre.psychStates,
                onToggle: _ => a({
                  psychStates: o(e.pre.psychStates, _)
                })
              })
            })]
          }), t === "post" && d.jsxs("div", {
            className: "pa-q-list",
            children: [d.jsx(Qe, {
              label: "احساس بعد از بستن معامله",
              required: !0,
              err: !!b.post && !e.post.emotionAfter,
              children: d.jsx(bl, {
                options: WQ,
                value: e.post.emotionAfter,
                multi: !1,
                onToggle: _ => i({
                  emotionAfter: _
                })
              })
            }), d.jsx(Qp, {
              label: "کیفیت اجرای معامله نسبت به پلن",
              lowLabel: "خیلی ضعیف",
              highLabel: "عالی",
              value: e.post.executionQuality,
              onChange: _ => i({
                executionQuality: _
              })
            }), d.jsx(Qe, {
              label: "اشتباهات رفتاری این معامله",
              children: d.jsx(bl, {
                options: KQ,
                value: e.post.mistakes,
                onToggle: _ => i({
                  mistakes: o(e.post.mistakes, _)
                })
              })
            }), d.jsx(Qe, {
              label: "یادداشت نهایی و درس‌آموخته",
              required: !0,
              err: !!b.post && !e.post.notes.trim(),
              children: d.jsx("textarea", {
                className: "pa-textarea" + (b.post && !e.post.notes.trim() ? " has-error" : ""),
                rows: 4,
                placeholder: "چه چیزی از این معامله یاد گرفتم؟ چه چیزی را دفعه بعد تغییر می‌دهم؟",
                value: e.post.notes,
                onChange: _ => i({
                  notes: _.target.value
                })
              })
            })]
          }), t === "basic" && d.jsxs("div", {
            className: "pa-review",
            children: [d.jsxs("div", {
              className: "pa-ticket",
              children: [d.jsxs("div", {
                className: "pa-ticket-head",
                children: [d.jsxs("div", {
                  className: "pa-ticket-id",
                  children: [d.jsx("span", {
                    className: "pa-ticket-dir " + (e.direction === "buy" ? "up" : "down"),
                    children: d.jsx(e.direction === "buy" ? is : Pc, {
                      size: 15
                    })
                  }), d.jsxs("div", {
                    className: "pa-ticket-idt",
                    children: [d.jsx("span", {
                      className: "pa-ticket-sym",
                      children: Tf(e.symbol).fa
                    }), d.jsxs("span", {
                      className: "pa-ticket-meta num",
                      children: [Tf(e.symbol).code, " · ", e.direction === "buy" ? "خرید" : "فروش", " · ", e
                        .positionSize ? e.positionSize + " لات" : "بدون حجم"
                      ]
                    })]
                  })]
                }), d.jsxs("div", {
                  className: "pa-ticket-net " + (e.amount ? wr(e) >= 0 ? "pos" : "neg" : "idle"),
                  children: [d.jsx("span", {
                    className: "pa-ticket-net-l",
                    children: "سود / زیان خالص"
                  }), d.jsx("span", {
                    className: "pa-ticket-net-v num",
                    children: e.amount ? Ke(wr(e)) : "—"
                  }), d.jsx("span", {
                    className: "pa-ticket-net-r num",
                    children: w && e.amount ? (wr(e) / w >= 0 ? "+" : "") + (wr(e) / w).toFixed(2) + "R" : "— R"
                  })]
                })]
              }), d.jsxs("div", {
                className: "pa-ticket-flags",
                children: [!!e.entryDate && d.jsxs("span", {
                  className: "pa-ticket-flag",
                  children: [d.jsx(Oc, {
                    size: 11
                  }), " ", Cg(e.entryDate)]
                }), !!e.setupName && d.jsxs("span", {
                  className: "pa-ticket-flag",
                  children: [d.jsx(Za, {
                    size: 11
                  }), " ", e.setupName]
                }), !!e.riskFree && d.jsxs("span", {
                  className: "pa-ticket-flag gold",
                  children: [d.jsx(Qa, {
                    size: 11
                  }), " ", "ریسک‌فری"]
                }), !!e.chartImageData && d.jsxs("span", {
                  className: "pa-ticket-flag",
                  children: [d.jsx(jc, {
                    size: 11
                  }), " ", "چارت پیوست شد"]
                }), L === D && d.jsxs("span", {
                  className: "pa-ticket-flag ok",
                  children: [d.jsx(oa, {
                    size: 11
                  }), " ", "چک‌لیست قبل کامل"]
                }), R === B && d.jsxs("span", {
                  className: "pa-ticket-flag ok",
                  children: [d.jsx(oa, {
                    size: 11
                  }), " ", "بازبینی بعد کامل"]
                }), d.jsxs("span", {
                  className: "pa-ticket-flag " + (N === 100 ? "ok" : "warn"),
                  children: [d.jsx(N === 100 ? oa : Ac, {
                    size: 11
                  }), " ", N, "٪ تکمیل"]
                })]
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "نماد"
              }), d.jsxs("span", {
                children: [Tf(e.symbol).fa, " (", e.symbol, ")"]
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "جهت"
              }), d.jsx("span", {
                children: e.direction === "buy" ? "خرید" : "فروش"
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "تاریخ ورود"
              }), d.jsx("span", {
                className: "num",
                children: e.entryDate ? Cg(e.entryDate) : "ثبت نشده"
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "نتیجه"
              }), d.jsxs("span", {
                className: e.resultType === "profit" ? "pos" : "neg",
                children: [e.resultType === "profit" ? "سود" : "ضرر", " ", e.amount && "· " + Ke(e.amount)]
              })]
            }), d.jsxs("div", {
              className: "pa-review-row pa-review-plan " + (e.pre.matchesPlan === null ? "none" : e.pre.matchesPlan ? "yes" : "no"),
              children: [d.jsx("span", {
                children: "مطابق پلن مکتوب"
              }), d.jsx("span", {
                children: e.pre.matchesPlan === null ? "بی‌پاسخ" : e.pre.matchesPlan ? "بله" : "خیر"
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "چک بقیه تایم‌فریم‌ها"
              }), d.jsx("span", {
                children: e.pre.checkedOtherTimeframes === null ? "—" : e.pre.checkedOtherTimeframes ? "بله" : "خیر"
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "مدت زمان معامله"
              }), d.jsx("span", {
                className: "num",
                children: Ng(e.durationValue, e.durationUnit)
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "احساس قبل / بعد"
              }), d.jsxs("span", {
                children: [e.pre.emotionBefore || "—", " / ", e.post.emotionAfter || "—"]
              })]
            }), d.jsxs("div", {
              className: "pa-review-row",
              children: [d.jsx("span", {
                children: "تصویر چارت"
              }), d.jsx("span", {
                children: e.chartImageData ? "پیوست شد ✓" : "—"
              })]
            }), d.jsxs("div", {
              className: "pa-review-note" + (N === 100 ? " ok" : ""),
              children: [d.jsx(N === 100 ? oa : Ac, {
                  size: 13
                }), N === 100 ? "همه فیلدهای اصلی کامل است — معامله آماده ثبت در ژورنال است." :
                "اطلاعات بالا را یک بار مرور کن، سپس معامله را در ژورنال ثبت کن."
              ]
            })]
          })]
        }), d.jsxs("div", {
          className: "pa-form-actions-bar",
          children: [d.jsxs("div", {
            className: "pa-form-progress",
            children: [d.jsx("div", {
              className: "pa-form-progress-track",
              children: d.jsx("div", {
                className: "pa-form-progress-fill",
                style: {
                  width: N + "%",
                  background: N === 100 ? "var(--green)" : void 0
                }
              })
            }), d.jsxs("span", {
              className: "pa-form-progress-text num",
              style: N === 100 ? {
                color: "var(--green)"
              } : void 0,
              children: [N === 100 ? d.jsx(oa, {
                size: 12,
                style: {
                  verticalAlign: "-2px"
                }
              }) : null, " ", E, " از ", P.length, " فیلد اصلی تکمیل شده"]
            })]
          }), d.jsxs("div", {
            className: "pa-form-actions",
            children: [d.jsx("button", {
              className: "pa-btn ghost",
              onClick: s,
              children: g ? "لغو ویرایش" : "پاک کردن فرم"
            }), d.jsx("button", {
              className: "pa-btn primary",
              onClick: l,
              children: g ? "ذخیره تغییرات" : "ثبت معامله در ژورنال"
            })]
          })]
        })]
      })
    }
    registry["new"] = wZ;
  }
})();
