/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function SZ({
      summary: e
    }) {
      return d.jsxs("div", {
        className: "pa-history-summary-grid",
        children: [d.jsx(Zt, {
          icon: Xa,
          label: "تعداد معاملات",
          value: e.count
        }), d.jsx(Zt, {
          icon: qh,
          label: "وین‌ریت",
          value: ii(e.winRate),
          tone: e.winRate >= 50 ? "green" : "red"
        }), d.jsx(Zt, {
          icon: Sy,
          label: "سود/زیان خالص",
          value: Ke(e.net),
          tone: e.net >= 0 ? "green" : "red"
        }), d.jsx(Zt, {
          icon: Za,
          label: "میانگین R برنامه‌ریزی‌شده",
          value: e.avgRR ? "1 : " + e.avgRR.toFixed(1) : "—"
        })]
      })
    }
    
    function OZ({
      filters: e,
      setFilters: t,
      resultCount: n,
      totalCount: r,
      onExport: a,
      trades: sTrades
    }) {
      function i(o) {
        t(l => ({
          ...l,
          ...o
        }))
      }
      return d.jsxs("div", {
        className: "pa-history-toolbar",
        children: [d.jsxs("div", {
          className: "pa-history-filters",
          children: [d.jsxs("div", {
            className: "pa-history-search-wrap",
            children: [d.jsx(n$, {
              size: 14,
              className: "pa-history-search-icon"
            }), d.jsx("input", {
              className: "pa-input sm pa-history-search",
              placeholder: "جست‌وجو در ستاپ، یادداشت، احساسات…",
              value: e.search,
              onChange: o => i({
                search: o.target.value
              })
            })]
          }), d.jsxs("select", {
            className: "pa-input sm",
            value: e.symbol,
            onChange: o => i({
              symbol: o.target.value
            }),
            children: [d.jsx("option", {
              value: "all",
              children: "همه نمادها"
            }), paSymGroups().map(G => d.jsx("optgroup", {
              label: G[0],
              children: G[1].map(o => d.jsx("option", {
                value: o.id,
                children: o.fa + " (" + o.code + ")"
              }, o.id))
            }, G[0]))]
          }), d.jsxs("select", {
            className: "pa-input sm",
            value: e.result,
            onChange: o => i({
              result: o.target.value
            }),
            children: [d.jsx("option", {
              value: "all",
              children: "برد و باخت"
            }), d.jsx("option", {
              value: "profit",
              children: "فقط بردها"
            }), d.jsx("option", {
              value: "loss",
              children: "فقط باخت‌ها"
            })]
          }), d.jsxs("div", {
            className: "pa-history-daterange",
            children: [d.jsx("input", {
              className: "pa-input sm",
              type: "date",
              value: e.dateFrom,
              onChange: o => i({
                dateFrom: o.target.value
              })
            }), d.jsx("span", {
              className: "pa-period-to",
              children: "تا"
            }), d.jsx("input", {
              className: "pa-input sm",
              type: "date",
              value: e.dateTo,
              onChange: o => i({
                dateTo: o.target.value
              })
            })]
          }), (e.search || e.symbol !== "all" || e.result !== "all" || e.dateFrom || e.dateTo) && d.jsx("button", {
            className: "pa-btn ghost sm",
            onClick: () => t({
              search: "",
              symbol: "all",
              result: "all",
              dateFrom: "",
              dateTo: ""
            }),
            children: "پاک کردن فیلتر"
          })]
        }), d.jsxs("div", {
          className: "pa-history-toolbar-right",
          children: [d.jsxs("span", {
            className: "pa-history-count num",
            children: [n, " از ", r, " معامله"]
          }), d.jsxs("button", {
            className: "pa-btn ghost sm pa-share-summary-btn",
            onClick: () => window.paOpenShareSummaryModal && window.paOpenShareSummaryModal(sTrades),
            children: [d.jsx(Gh, {
              size: 14
            }), " کارت استوری کارنامه"]
          }), d.jsxs("button", {
            className: "pa-btn ghost sm",
            onClick: a,
            children: [d.jsx(Gh, {
              size: 14
            }), " خروجی CSV"]
          })]
        })]
      })
    }
    
    function jZ({
      trades: e,
      expandedId: t,
      setExpandedId: n,
      confirmDeleteId: r,
      setConfirmDeleteId: a,
      onDelete: i,
      chartCache: o,
      loadChartImage: l,
      chartLoadingId: s,
      onZoomImage: u,
      hasAnyTrades: f,
      onEdit: c,
      onOpenDocuments: paOpenDocuments
    }) {
      if (e.length === 0) return d.jsxs("div", {
        className: "pa-empty",
        children: [d.jsx("div", {
          className: "pa-empty-icon",
          children: d.jsx(l2, {
            size: 30
          })
        }), d.jsx("div", {
          className: "pa-empty-title",
          children: f ? "نتیجه‌ای با این فیلترها پیدا نشد" : "تاریخچه‌ای وجود ندارد"
        }), d.jsx("div", {
          className: "pa-empty-sub",
          children: f ? "فیلترها را تغییر بده یا پاک کن تا معاملات دیگر نمایش داده شوند." : "معاملات ثبت‌شده این حساب اینجا نمایش داده می‌شوند."
        })]
      });
      const p = [];
      for (const h of e) {
        const v = h.entryDate && !isNaN(new Date(h.entryDate)) ? YQ(h.entryDate) : "بدون تاریخ";
        let b = p[p.length - 1];
        (!b || b.label !== v) && (b = {
          label: v,
          items: [],
          net: 0
        }, p.push(b)), b.items.push(h), b.net += wr(h)
      }
      return d.jsx("div", {
        className: "pa-history",
        children: p.map(h => d.jsxs("div", {
          className: "pa-history-day-group",
          children: [d.jsxs("div", {
            className: "pa-history-day-head",
            children: [d.jsx("span", {
              className: "pa-history-day-label",
              children: h.label
            }), d.jsxs("span", {
              className: "pa-history-day-count",
              children: [h.items.length, " معامله"]
            }), d.jsx("span", {
              className: "num pa-history-day-net " + (h.net >= 0 ? "pos" : "neg"),
              children: Ke(h.net)
            })]
          }), h.items.map(v => {
            var w, S, j, k, P, E, N, $, L, D, R, B, _, C, z, W, X;
            const b = Tf(v.symbol),
              m = t === v.id,
              g = v.resultType === "profit" ? Number(v.amount || 0) : -Number(v.amount || 0),
              x = v.riskFree ? "riskfree" : v.resultType === "profit" ? "win" : "loss",
              y = ((w = v.pre) == null ? void 0 : w.matchesPlan) === !0,
              O = (((S = v.post) == null ? void 0 : S.mistakes) || []).length > 0;
            return d.jsxs("div", {
              className: "pa-card pa-trade-card " + x,
              "data-trade-id": v.id,
              children: [d.jsxs("div", {
                className: "pa-trade-head",
                onClick: () => {
                  const H = !m;
                  n(H ? v.id : null), H && v.hasChart && l(v.id)
                },
                children: [d.jsxs("div", {
                  className: "pa-trade-head-left",
                  children: [d.jsx("span", {
                    className: "pa-sym-dot",
                    style: {
                      background: b.color
                    }
                  }), d.jsxs("div", {
                    children: [d.jsxs("div", {
                      className: "pa-trade-sym",
                      children: [b.fa, " ", d.jsx("span", {
                        className: "pa-trade-code",
                        children: b.code
                      })]
                    }), d.jsxs("div", {
                      className: "pa-trade-date num",
                      children: [GQ(v.entryDate), v.setupName ? " · " + v.setupName : ""]
                    })]
                  })]
                }), d.jsxs("div", {
                  className: "pa-trade-head-right",
                  children: [y && d.jsx("span", {
                    className: "pa-discipline-icon good",
                    title: "طبق پلن معاملاتی",
                    children: d.jsx(oa, {
                      size: 12
                    })
                  }), O && d.jsx("span", {
                    className: "pa-discipline-icon warn",
                    title: "اشتباه رفتاری ثبت شده",
                    children: d.jsx(Ac, {
                      size: 12
                    })
                  }), d.jsx("span", {
                    className: "pa-badge " + (v.direction === "buy" ? "buy" : "sell"),
                    children: v.direction === "buy" ? "Buy" : "Sell"
                  }), v.riskFree ? d.jsx("span", {
                    className: "pa-badge neutral",
                    children: "ریسک‌فری"
                  }) : d.jsxs("span", {
                    className: "num pa-trade-amount " + (g >= 0 ? "pos" : "neg"),
                    children: [g >= 0 ? d.jsx(is, {
                      size: 13
                    }) : d.jsx(Pc, {
                      size: 13
                    }), Ke(g)]
                  }), m ? d.jsx(XE, {
                    size: 18
                  }) : d.jsx(qE, {
                    size: 18
                  })]
                })]
              }), m && d.jsxs("div", {
                className: "pa-trade-detail",
                children: [d.jsxs("div", {
                  className: "pa-detail-grid",
                  children: [d.jsx(ka, {
                    icon: Oc,
                    label: "تایم‌فریم",
                    value: v.timeframe
                  }), d.jsx(ka, {
                    icon: ZE,
                    label: "مدت باز بودن",
                    value: Ng(v.durationValue, v.durationUnit)
                  }), d.jsx(ka, {
                    icon: Yh,
                    label: "حجم",
                    value: v.positionSize || "—"
                  }), d.jsx(ka, {
                    icon: Qa,
                    label: "ریسک",
                    value: (v.riskPercent || "—") + (v.riskPercent ? "%" : ""),
                    tone: v.riskPercent > 2 ? "red" : v.riskPercent ? "green" : void 0
                  }), d.jsx(ka, {
                    icon: Za,
                    label: "R:R برنامه‌ریزی‌شده",
                    value: v.plannedRR ? "1 : " + v.plannedRR : "—",
                    tone: v.plannedRR >= 2 ? "accent" : void 0
                  }), d.jsx(ka, {
                    icon: Xa,
                    label: "ستاپ",
                    value: v.setupName || "—"
                  }), d.jsx(ka, {
                    icon: Gf,
                    label: "سشن",
                    value: Tg(v.entryDate)
                  })]
                }), v.hasChart && d.jsxs("div", {
                  className: "pa-detail-section",
                  children: [d.jsxs("div", {
                    className: "pa-detail-title",
                    children: [d.jsx(jc, {
                      size: 13,
                      style: {
                        verticalAlign: "-2px"
                      }
                    }), " تصویر چارت"]
                  }), o[v.id] ? d.jsxs("div", {
                    className: "pa-chart-frame",
                    children: [d.jsx(eA, {
                      src: o[v.id],
                      className: "pa-chart-img",
                      alt: "چارت معامله",
                      onZoom: u
                    }), d.jsxs("div", {
                      className: "pa-chart-zoom-hint",
                      children: [d.jsx(l$, {
                        size: 16
                      }), " بزرگ‌نمایی"]
                    })]
                  }) : s === v.id ? d.jsx("div", {
                    className: "pa-chart-loading",
                    children: "در حال بارگذاری تصویر…"
                  }) : d.jsx("button", {
                    className: "pa-btn ghost sm",
                    onClick: () => l(v.id),
                    children: "تلاش مجدد برای نمایش تصویر"
                  })]
                }), d.jsxs("div", {
                  className: "pa-detail-section",
                  children: [d.jsx("div", {
                    className: "pa-detail-title",
                    children: "پیش از معامله"
                  }), d.jsxs("div", {
                    className: "pa-detail-qa",
                    children: [d.jsx(Si, {
                      icon: wy,
                      q: "R:R قابل قبول؟",
                      a: (k = v.pre) == null ? void 0 : k.rrAcceptable
                    }), d.jsx(Si, {
                      icon: Qa,
                      q: "حجم متناسب با ریسک؟",
                      a: (P = v.pre) == null ? void 0 : P.sizeMatchesRisk
                    }), d.jsx(Si, {
                      icon: s2,
                      q: "خبر مهم در پیش؟",
                      a: (E = v.pre) == null ? void 0 : E.newsUpcoming
                    }), d.jsx(Si, {
                      icon: Xa,
                      q: "مطابق پلن مکتوب؟",
                      key: "plan",
                      a: (N = v.pre) == null ? void 0 : N.matchesPlan
                    }), d.jsx(Si, {
                      icon: Oc,
                      q: "چک بقیه تایم‌فریم‌ها؟",
                      a: ($ = v.pre) == null ? void 0 : $.checkedOtherTimeframes
                    })]
                  }), d.jsxs("div", {
                    className: "pa-detail-tags",
                    children: [((L = v.pre) == null ? void 0 : L.emotionBefore) && d.jsxs("span", {
                      className: "pa-tag pa-mood-tag",
                      "data-mood": v.pre.emotionBefore,
                      children: [d.jsx("span", {
                        className: "pa-tag-k",
                        children: "حس قبل"
                      }), d.jsx("span", {
                        className: "pa-tag-v",
                        children: v.pre.emotionBefore
                      })]
                    }), d.jsx(Jp, {
                      label: "انرژی",
                      value: (D = v.pre) == null ? void 0 : D.energyLevel
                    }), d.jsx(Jp, {
                      label: "اعتماد به ستاپ",
                      value: (R = v.pre) == null ? void 0 : R.setupConfidence
                    }), (((B = v.pre) == null ? void 0 : B.motivations) || []).map(H => d.jsx("span", {
                      className: "pa-tag pa-tag-motive",
                      "data-motive": H,
                      children: H
                    }, H)), (((_ = v.pre) == null ? void 0 : _.psychStates) || []).map(H => d.jsx("span", {
                      className: "pa-tag warn pa-tag-psych",
                      "data-psych": H,
                      children: H
                    }, H))]
                  })]
                }), d.jsxs("div", {
                  className: "pa-detail-section",
                  children: [d.jsx("div", {
                    className: "pa-detail-title",
                    children: "پس از معامله"
                  }), d.jsxs("div", {
                    className: "pa-detail-tags",
                    children: [((C = v.post) == null ? void 0 : C.emotionAfter) && d.jsxs("span", {
                      className: "pa-tag pa-mood-tag",
                      "data-mood": v.post.emotionAfter,
                      children: [d.jsx("span", {
                        className: "pa-tag-k",
                        children: "حس بعد"
                      }), d.jsx("span", {
                        className: "pa-tag-v",
                        children: v.post.emotionAfter
                      })]
                    }), d.jsx(Jp, {
                      label: "کیفیت اجرا",
                      value: (z = v.post) == null ? void 0 : z.executionQuality
                    }), (((W = v.post) == null ? void 0 : W.mistakes) || []).map(H => d.jsx("span", {
                      className: "pa-tag warn pa-tag-mistake",
                      "data-mistake": H,
                      children: H
                    }, H))]
                  }), ((X = v.post) == null ? void 0 : X.notes) && d.jsxs("div", {
                    className: "pa-notes",
                    children: ["«", v.post.notes, "»"]
                  })]
                }), d.jsx("div", {
                  className: "pa-trade-footer",
                  children: r === v.id ? d.jsxs("div", {
                    className: "pa-confirm",
                    children: [d.jsx("span", {
                      children: "حذف این معامله قطعی است؟"
                    }), d.jsx("button", {
                      className: "pa-btn danger sm",
                      onClick: () => i(v.id),
                      children: "بله، حذف کن"
                    }), d.jsx("button", {
                      className: "pa-btn ghost sm",
                      onClick: () => a(null),
                      children: "انصراف"
                    })]
                  }) : d.jsxs("div", {
                    className: "pa-confirm",
                    children: [d.jsxs("button", {
                      className: "pa-btn ghost sm pa-history-doc-link",
                      onClick: () => paOpenDocuments && paOpenDocuments(v.id),
                      children: [d.jsx(jc, {
                        size: 14
                      }), " مستندات این معامله"]
                    }), d.jsxs("button", {
                      className: "pa-btn ghost sm pa-share-btn",
                      onClick: () => window.paOpenShareModal && window.paOpenShareModal(v),
                      children: [d.jsx(jc, {
                        size: 14
                      }), " کارت استوری"]
                    }), d.jsxs("button", {
                      className: "pa-btn ghost sm",
                      onClick: () => c(v),
                      children: [d.jsx(u2, {
                        size: 14
                      }), " ویرایش معامله"]
                    }), d.jsxs("button", {
                      className: "pa-btn ghost sm",
                      onClick: () => a(v.id),
                      children: [d.jsx(kc, {
                        size: 14
                      }), " حذف معامله"]
                    })]
                  })
                })]
              })]
            }, v.id)
          })]
        }, h.label + h.items[0].id))
      })
    }
    
    function ka({
      icon: e,
      label: t,
      value: n,
      tone: r
    }) {
      const a = r === "red" ? "var(--red)" : r === "green" ? "var(--green)" : r === "accent" ? "var(--accent)" : null;
      return d.jsxs("div", {
        className: "pa-detail-item",
        children: [e && d.jsx("span", {
          className: "pa-detail-item-icon",
          style: a ? {
            color: a,
            background: a + "22"
          } : void 0,
          children: d.jsx(e, {
            size: 13
          })
        }), d.jsxs("div", {
          className: "pa-detail-item-body",
          children: [d.jsx("div", {
            className: "pa-detail-item-label",
            children: t
          }), d.jsx("div", {
            className: "pa-detail-item-value",
            style: a ? {
              color: a
            } : void 0,
            children: n
          })]
        })]
      })
    }
    
    function Si({
      icon: e,
      q: t,
      a: n
    }) {
      return d.jsxs("div", {
        className: "pa-qa" + (t === "مطابق پلن مکتوب؟" ? " pa-qa-plan " + (n === !0 ? "yes" : n === !1 ? "no" : "none") : ""),
        children: [d.jsxs("span", {
          className: "pa-qa-q",
          children: [e && d.jsx(e, {
            size: 13,
            className: "pa-qa-icon"
          }), " ", t]
        }), n === !0 ? d.jsxs("span", {
          className: "pa-qa-yes",
          children: [d.jsx(oa, {
            size: 13
          }), " بله"]
        }) : n === !1 ? d.jsxs("span", {
          className: "pa-qa-no",
          children: [d.jsx(Oy, {
            size: 13
          }), " خیر"]
        }) : d.jsx("span", {
          className: "pa-qa-none",
          children: "—"
        })]
      })
    }
    
    function Jp({
      label: e,
      value: t
    }) {
      const n = Number(t) || 0;
      if (!n) return null;
      return d.jsxs("span", {
        className: "pa-tag pa-level-tag",
        "data-level": n,
        children: [d.jsx("span", {
          className: "pa-tag-k",
          children: e
        }), d.jsx("span", {
          className: "pa-level-dots",
          children: [1, 2, 3, 4, 5].map(r => d.jsx("span", {
            className: "pa-level-dot" + (r <= n ? " filled" : "")
          }, r))
        }), d.jsxs("span", {
          className: "pa-level-val num",
          children: [n, "/5"]
        })]
      })
    }
    
    function paHistoryCenter({ summary: mA, filters: Xe, setFilters: ya, resultCount, totalCount, filteredTrades: wa, totalTrades: it, onExport: cA, expandedId: O, setExpandedId: w, confirmDeleteId: S, setConfirmDeleteId: j, onDelete: sA, chartCache: $, loadChartImage: uA, chartLoadingId: K, onZoomImage: $e, onEdit: aA, hasAnyTrades, onOpenDocuments }) {
      return d.jsxs(d.Fragment, {
            children: [it.length > 0 && d.jsxs(d.Fragment, {
              children: [d.jsx(SZ, {
                summary: mA
              }), d.jsx(OZ, {
                filters: Xe,
                setFilters: ya,
                resultCount,
                totalCount,
                onExport: cA,
                trades: wa
              })]
            }), d.jsx(jZ, {
              trades: wa,
              expandedId: O,
              setExpandedId: w,
              confirmDeleteId: S,
              setConfirmDeleteId: j,
              onDelete: sA,
              chartCache: $,
              loadChartImage: uA,
              chartLoadingId: K,
              onZoomImage: $e,
              hasAnyTrades,
              onEdit: aA,
              onOpenDocuments: onOpenDocuments
            })]
          });
    }
    registry["history"] = paHistoryCenter;
  }
})();
