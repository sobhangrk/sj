/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */
(function(){
  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};
  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});
  with (runtime) {
    function paAnnotationBounds(action, context) {
      if (!action) return null;
      const pad = Math.max(8, (action.width || 6) * 1.5);
      if (action.type === "pen" && action.points && action.points.length) {
        const xs = action.points.map(point => point.x), ys = action.points.map(point => point.y);
        return {
          minX: Math.min(...xs) - pad,
          minY: Math.min(...ys) - pad,
          maxX: Math.max(...xs) + pad,
          maxY: Math.max(...ys) + pad
        }
      }
      if (action.type === "arrow" || action.type === "rect") return {
        minX: Math.min(action.x1, action.x2) - pad,
        minY: Math.min(action.y1, action.y2) - pad,
        maxX: Math.max(action.x1, action.x2) + pad,
        maxY: Math.max(action.y1, action.y2) + pad
      };
      if (action.type === "text") {
        const fontSize = Math.max(24, (action.width || 6) * 5);
        let textWidth = String(action.text || "").length * fontSize * .62;
        if (context) {
          context.save(), context.font = `700 ${fontSize}px Vazirmatn, sans-serif`;
          textWidth = Math.max(textWidth, context.measureText(action.text || "").width), context.restore()
        }
        return {
          minX: action.x - textWidth / 2 - pad,
          minY: action.y - fontSize - pad,
          maxX: action.x + textWidth / 2 + pad,
          maxY: action.y + fontSize * .3 + pad
        }
      }
      return null
    }
    
    function paPointSegmentDistance(point, start, end) {
      const dx = end.x - start.x, dy = end.y - start.y,
        lengthSquared = dx * dx + dy * dy;
      if (!lengthSquared) return Math.hypot(point.x - start.x, point.y - start.y);
      const ratio = Math.max(0, Math.min(1, ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared)),
        x = start.x + ratio * dx, y = start.y + ratio * dy;
      return Math.hypot(point.x - x, point.y - y)
    }
    
    function paFindAnnotationAt(actions, point, context) {
      for (let index = actions.length - 1; index >= 0; index--) {
        const action = actions[index], tolerance = Math.max(14, (action.width || 6) * 2.3), bounds = paAnnotationBounds(action, context);
        if (!bounds || point.x < bounds.minX - tolerance || point.x > bounds.maxX + tolerance || point.y < bounds.minY - tolerance || point.y > bounds.maxY + tolerance) continue;
        if (action.type === "text") return index;
        if (action.type === "rect") {
          const minX = Math.min(action.x1, action.x2), maxX = Math.max(action.x1, action.x2), minY = Math.min(action.y1, action.y2), maxY = Math.max(action.y1, action.y2);
          if (point.x >= minX - tolerance && point.x <= maxX + tolerance && point.y >= minY - tolerance && point.y <= maxY + tolerance) return index
        } else if (action.type === "arrow") {
          if (paPointSegmentDistance(point, { x: action.x1, y: action.y1 }, { x: action.x2, y: action.y2 }) <= tolerance) return index
        } else if (action.type === "pen" && action.points && action.points.length) {
          if (action.points.length === 1 && Math.hypot(point.x - action.points[0].x, point.y - action.points[0].y) <= tolerance) return index;
          for (let pointIndex = 1; pointIndex < action.points.length; pointIndex++) if (paPointSegmentDistance(point, action.points[pointIndex - 1], action.points[pointIndex]) <= tolerance) return index
        }
      }
      return -1
    }
    
    function paTranslateAnnotation(action, requestedDx, requestedDy, canvas) {
      const bounds = paAnnotationBounds(action, canvas && canvas.getContext("2d"));
      let dx = requestedDx, dy = requestedDy;
      if (bounds && canvas) {
        const minDx = bounds.minX < 0 ? 0 : -bounds.minX,
          maxDx = bounds.maxX > canvas.width ? 0 : canvas.width - bounds.maxX,
          minDy = bounds.minY < 0 ? 0 : -bounds.minY,
          maxDy = bounds.maxY > canvas.height ? 0 : canvas.height - bounds.maxY;
        if (bounds.maxX - bounds.minX <= canvas.width && minDx <= maxDx) dx = Math.max(minDx, Math.min(maxDx, dx));
        if (bounds.maxY - bounds.minY <= canvas.height && minDy <= maxDy) dy = Math.max(minDy, Math.min(maxDy, dy))
      }
      if (action.type === "pen") return {
        ...action,
        points: action.points.map(point => ({ x: point.x + dx, y: point.y + dy }))
      };
      if (action.type === "arrow" || action.type === "rect") return {
        ...action,
        x1: action.x1 + dx,
        y1: action.y1 + dy,
        x2: action.x2 + dx,
        y2: action.y2 + dy
      };
      if (action.type === "text") return {
        ...action,
        x: action.x + dx,
        y: action.y + dy
      };
      return action
    }
    
    function paDrawAnnotation(canvas, image, actions, current, selectedIndex = -1) {
      if (!canvas || !image) return;
      const context = canvas.getContext("2d");
      context.clearRect(0, 0, canvas.width, canvas.height), context.drawImage(image, 0, 0, canvas.width, canvas.height);
      [...actions, current].filter(Boolean).forEach(action => {
        context.save(), context.strokeStyle = action.color || "#22d3ee", context.fillStyle = action.color || "#22d3ee", context.lineWidth = action.width || 6, context.lineCap = "round", context.lineJoin = "round";
        if (action.type === "pen" && action.points.length > 1) {
          context.beginPath(), context.moveTo(action.points[0].x, action.points[0].y), action.points.slice(1).forEach(point => context.lineTo(point.x, point.y)), context.stroke()
        } else if (action.type === "arrow") {
          const dx = action.x2 - action.x1,
            dy = action.y2 - action.y1,
            angle = Math.atan2(dy, dx),
            head = Math.max(18, (action.width || 6) * 4);
          context.beginPath(), context.moveTo(action.x1, action.y1), context.lineTo(action.x2, action.y2), context.stroke(), context.beginPath(), context.moveTo(action.x2, action.y2), context.lineTo(action.x2 - head * Math.cos(angle - Math.PI / 6), action.y2 - head * Math.sin(angle - Math.PI / 6)), context.lineTo(action.x2 - head * Math.cos(angle + Math.PI / 6), action.y2 - head * Math.sin(angle + Math.PI / 6)), context.closePath(), context.fill()
        } else if (action.type === "rect") {
          context.strokeRect(action.x1, action.y1, action.x2 - action.x1, action.y2 - action.y1)
        } else if (action.type === "text") {
          context.font = `700 ${Math.max(24, (action.width || 6) * 5)}px Vazirmatn, sans-serif`, context.textAlign = "center", context.lineWidth = 5, context.strokeStyle = "rgba(0,0,0,.75)", context.strokeText(action.text, action.x, action.y), context.fillStyle = action.color, context.fillText(action.text, action.x, action.y)
        }
        context.restore()
      });
      if (selectedIndex >= 0 && actions[selectedIndex]) {
        const bounds = paAnnotationBounds(actions[selectedIndex], context);
        if (bounds) {
          context.save(), context.setLineDash([10, 7]), context.lineWidth = 2, context.strokeStyle = "#a78bfa", context.fillStyle = "#ffffff";
          context.strokeRect(bounds.minX, bounds.minY, bounds.maxX - bounds.minX, bounds.maxY - bounds.minY);
          [[bounds.minX, bounds.minY], [bounds.maxX, bounds.minY], [bounds.minX, bounds.maxY], [bounds.maxX, bounds.maxY]].forEach(handle => {
            context.beginPath(), context.arc(handle[0], handle[1], 5, 0, Math.PI * 2), context.fill(), context.stroke()
          }), context.restore()
        }
      }
    }
    
    function paChartAnnotator({
      src,
      initialActions = [],
      onSave,
      onCancel
    }) {
      const canvasRef = M.useRef(null),
        imageRef = M.useRef(null),
        drawingRef = M.useRef(!1),
        movingRef = M.useRef(null),
        [actions, setActions] = M.useState(() => Array.isArray(initialActions) ? initialActions : []),
        [current, setCurrent] = M.useState(null),
        [tool, setTool] = M.useState("pen"),
        [color, setColor] = M.useState("#22d3ee"),
        [width, setWidth] = M.useState(7),
        [selectedIndex, setSelectedIndex] = M.useState(-1),
        [isMoving, setIsMoving] = M.useState(!1),
        [ready, setReady] = M.useState(!1);
      M.useEffect(() => {
        const image = new Image;
        image.onload = () => {
          const max = 1600,
            scale = Math.min(1, max / image.width),
            canvas = canvasRef.current;
          canvas.width = Math.max(1, Math.round(image.width * scale)), canvas.height = Math.max(1, Math.round(image.height * scale)), imageRef.current = image, setReady(!0), paDrawAnnotation(canvas, image, [], null)
        }, image.src = src
      }, [src]);
      M.useEffect(() => {
        ready && paDrawAnnotation(canvasRef.current, imageRef.current, actions, current, tool === "move" ? selectedIndex : -1)
      }, [actions, current, ready, tool, selectedIndex]);
      const point = event => {
          const rect = canvasRef.current.getBoundingClientRect();
          return {
            x: (event.clientX - rect.left) * canvasRef.current.width / rect.width,
            y: (event.clientY - rect.top) * canvasRef.current.height / rect.height
          }
        },
        down = event => {
          event.preventDefault();
          const p = point(event), canvas = canvasRef.current;
          if (tool === "move") {
            const index = paFindAnnotationAt(actions, p, canvas.getContext("2d"));
            setSelectedIndex(index);
            if (index >= 0) {
              drawingRef.current = !0, movingRef.current = { index, start: p, original: actions[index] }, setIsMoving(!0), event.currentTarget.setPointerCapture && event.currentTarget.setPointerCapture(event.pointerId)
            }
            return
          }
          setSelectedIndex(-1);
          if (tool === "text") {
            const text = window.prompt("متن یادداشت روی چارت را بنویس:", "");
            text && setActions(items => [...items, {
              type: "text",
              text: text.slice(0, 80),
              x: p.x,
              y: p.y,
              color,
              width
            }]);
            return
          }
          drawingRef.current = !0, event.currentTarget.setPointerCapture && event.currentTarget.setPointerCapture(event.pointerId), setCurrent(tool === "pen" ? {
            type: "pen",
            points: [p],
            color,
            width
          } : {
            type: tool,
            x1: p.x,
            y1: p.y,
            x2: p.x,
            y2: p.y,
            color,
            width
          })
        },
        move = event => {
          if (!drawingRef.current) return;
          const p = point(event);
          if (movingRef.current) {
            const movement = movingRef.current,
              dx = p.x - movement.start.x,
              dy = p.y - movement.start.y;
            setActions(items => items.map((action, index) => index === movement.index ? paTranslateAnnotation(movement.original, dx, dy, canvasRef.current) : action));
            return
          }
          setCurrent(action => action && action.type === "pen" ? {
            ...action,
            points: [...action.points, p]
          } : action ? {
            ...action,
            x2: p.x,
            y2: p.y
          } : action)
        },
        up = () => {
          if (movingRef.current) {
            movingRef.current = null, drawingRef.current = !1, setIsMoving(!1);
            return
          }
          drawingRef.current = !1, setCurrent(action => (action && setActions(items => [...items, action]), null))
        },
        save = () => {
          paDrawAnnotation(canvasRef.current, imageRef.current, actions, null, -1);
          onSave(canvasRef.current.toDataURL(paImgMime(), .92), actions.length, actions)
        },
        selectTool = nextTool => {
          movingRef.current = null, drawingRef.current = !1, setIsMoving(!1), setCurrent(null), setSelectedIndex(-1), setTool(nextTool)
        };
      return M.createElement("div", {
        className: "pa-annotator-modal",
        role: "dialog",
        "aria-modal": "true",
        "aria-labelledby": "pa-annotator-title"
      }, M.createElement("div", {
        className: "pa-annotator-panel"
      }, M.createElement("header", null, M.createElement("div", null, M.createElement("span", null, "ANNOTATION STUDIO"), M.createElement("h2", { id: "pa-annotator-title" }, "یادداشت‌گذاری مستقیم روی چارت")), M.createElement("button", {
        className: "pa-btn ghost sm",
        onClick: onCancel
      }, "بستن")), M.createElement("div", {
        className: "pa-annotator-tools"
      }, [["pen", "قلم"], ["arrow", "پیکان"], ["rect", "کادر"], ["text", "متن"], ["move", "جابجایی"]].map(item => M.createElement("button", {
        className: "pa-tool-btn" + (tool === item[0] ? " active" : ""),
        onClick: () => selectTool(item[0]),
        key: item[0],
        title: item[0] === "move" ? "یک یادداشت را بگیر و روی تصویر جابه‌جا کن" : item[1]
      }, item[1])), ["#22d3ee", "#f87171", "#22c55e", "#facc15", "#ffffff", "#000000"].map(item => M.createElement("button", {
        className: "pa-color-btn" + (color === item ? " active" : ""),
        style: {
          background: item
        },
        title: item === "#000000" ? "مشکی" : item,
        "aria-label": item === "#000000" ? "رنگ مشکی" : "انتخاب رنگ " + item,
        onClick: () => setColor(item),
        key: item
      })), M.createElement("label", null, "ضخامت", M.createElement("input", {
        type: "range",
        min: "3",
        max: "18",
        value: width,
        onChange: event => setWidth(Number(event.target.value))
      })), tool === "move" && selectedIndex >= 0 ? M.createElement("button", {
        className: "pa-btn danger sm",
        onClick: () => {
          setActions(items => items.filter((_, index) => index !== selectedIndex)), setSelectedIndex(-1)
        }
      }, "حذف انتخاب‌شده") : null, M.createElement("button", {
        className: "pa-btn ghost sm",
        disabled: !actions.length,
        onClick: () => {
          setActions(items => items.slice(0, -1)), setSelectedIndex(-1)
        }
      }, "واگرد"), M.createElement("button", {
        className: "pa-btn ghost sm",
        disabled: !actions.length,
        onClick: () => {
          setActions([]), setSelectedIndex(-1)
        }
      }, "پاک‌کردن همه")), M.createElement("div", {
        className: "pa-annotator-canvas-wrap"
      }, M.createElement("canvas", {
        ref: canvasRef,
        className: tool === "move" ? "pa-is-move-tool" + (isMoving ? " is-dragging" : "") : "",
        onPointerDown: down,
        onPointerMove: move,
        onPointerUp: up,
        onPointerCancel: up
      })), M.createElement("footer", null, M.createElement("span", null, tool === "move" ? selectedIndex >= 0 ? "یادداشت انتخاب‌شده را بگیر و به جای دلخواه روی تصویر بکش." : "روی قلم، پیکان، کادر یا متن بزن و آن را روی تصویر جابه‌جا کن." : "قلم، پیکان، کادر یا متن را رسم کن؛ سپس با ابزار «جابجایی» جای آن را تغییر بده."), M.createElement("button", {
        className: "pa-btn primary",
        onClick: save,
        disabled: !ready
      }, "ذخیره تصویر حاشیه‌نویسی‌شده"))))
    }
    
    function paCompareView({
      before,
      after
    }) {
      const [mode, setMode] = M.useState("slider"),
        [split, setSplit] = M.useState(50);
      if (!before || !after) return M.createElement("div", {
        className: "pa-compare-empty"
      }, "برای مقایسه باید تصویر قبل و بعد این معامله ثبت شده باشد.");
      return M.createElement("section", {
        className: "pa-compare"
      }, M.createElement("header", null, M.createElement("h3", null, "مقایسه قبل و بعد"), M.createElement("div", null, M.createElement("button", {
        className: mode === "slider" ? "active" : "",
        onClick: () => setMode("slider")
      }, "اسلایدر"), M.createElement("button", {
        className: mode === "side" ? "active" : "",
        onClick: () => setMode("side")
      }, "کنار هم"))), mode === "slider" ? M.createElement("div", {
        className: "pa-compare-slider"
      }, M.createElement("img", {
        src: after,
        alt: "بعد از خروج"
      }), M.createElement("div", {
        className: "pa-compare-before",
        style: {
          width: split + "%"
        }
      }, M.createElement("img", {
        src: before,
        alt: "قبل از ورود"
      })), M.createElement("span", {
        className: "pa-compare-line",
        style: {
          left: split + "%"
        }
      }), M.createElement("span", {
        className: "pa-compare-label before"
      }, "قبل"), M.createElement("span", {
        className: "pa-compare-label after"
      }, "بعد"), M.createElement("input", {
        type: "range",
        min: "0",
        max: "100",
        value: split,
        "aria-label": "موقعیت مقایسه قبل و بعد",
        onChange: event => setSplit(Number(event.target.value))
      })) : M.createElement("div", {
        className: "pa-compare-side"
      }, M.createElement("figure", null, M.createElement("img", {
        src: before,
        alt: "قبل از ورود"
      }), M.createElement("figcaption", null, "قبل از ورود")), M.createElement("figure", null, M.createElement("img", {
        src: after,
        alt: "بعد از خروج"
      }), M.createElement("figcaption", null, "بعد از خروج"))))
    }
    
    function paDocumentDrop({
      stage,
      item,
      busy,
      onFile,
      onRemove,
      onAnnotate,
      onTags,
      onZoom
    }) {
      const [drag, setDrag] = M.useState(!1),
        before = stage === "before",
        suggestions = before ? ["ورود", "ستاپ", "حمایت", "مقاومت", "نقدینگی"] : ["خروج", "نتیجه", "TP", "SL", "مدیریت معامله"];
      return M.createElement("article", {
        className: "pa-doc-stage " + (item && item.data ? "filled" : "empty") + (drag ? " drag" : ""),
        onDragEnter: event => (event.preventDefault(), setDrag(!0)),
        onDragOver: event => event.preventDefault(),
        onDragLeave: event => (event.preventDefault(), setDrag(!1)),
        onDrop: event => {
          event.preventDefault(), setDrag(!1);
          const file = event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0];
          file && onFile(stage, file)
        }
      }, M.createElement("header", null, M.createElement("div", {
        className: "pa-doc-stage-icon"
      }, before ? "01" : "02"), M.createElement("div", null, M.createElement("h3", null, before ? "قبل از ورود" : "بعد از خروج"), M.createElement("p", null, before ? "ساختار بازار و دلیل ورود" : "نتیجه، مدیریت و نقطه خروج")), item && item.data && M.createElement("span", {
        className: "pa-doc-ready"
      }, "ثبت شده")), item && item.data ? M.createElement(M.Fragment, null, M.createElement("button", {
        className: "pa-doc-image",
        onClick: () => onZoom(item.data)
      }, M.createElement("img", {
        src: item.data,
        alt: before ? "چارت قبل از ورود" : "چارت بعد از خروج"
      }), item.annotationCount ? M.createElement("span", null, item.annotationCount.toLocaleString("fa-IR"), " یادداشت") : null), M.createElement("div", {
        className: "pa-doc-actions"
      }, M.createElement("label", {
        className: "pa-btn ghost sm"
      }, "جایگزینی", M.createElement("input", {
        hidden: !0,
        type: "file",
        accept: "image/*",
        disabled: busy,
        onChange: event => {
          const file = event.target.files && event.target.files[0];
          event.target.value = "", file && onFile(stage, file)
        }
      })), M.createElement("button", {
        className: "pa-btn ghost sm pa-annotate-btn",
        onClick: () => onAnnotate(stage)
      }, "حاشیه‌نویسی"), M.createElement("button", {
        className: "pa-btn ghost sm danger",
        onClick: () => onRemove(stage)
      }, "حذف")), M.createElement("div", {
        className: "pa-doc-tags"
      }, M.createElement("input", {
        className: "pa-input",
        value: (item.tags || []).join("، "),
        placeholder: "تگ‌ها را با ویرگول جدا کن",
        onChange: event => onTags(stage, event.target.value.split(/[،,]/).map(value => value.trim()).filter(Boolean).slice(0, 12))
      }), M.createElement("div", null, suggestions.map(tag => M.createElement("button", {
        className: (item.tags || []).includes(tag) ? "active" : "",
        key: tag,
        onClick: () => {
          const tags = item.tags || [];
          onTags(stage, tags.includes(tag) ? tags.filter(value => value !== tag) : [...tags, tag])
        }
      }, "#", tag))))) : M.createElement("label", {
        className: "pa-doc-upload"
      }, M.createElement("span", {
        className: "pa-doc-upload-mark"
      }, drag ? "↓" : "+"), M.createElement("b", null, busy ? "در حال فشرده‌سازی تصویر…" : drag ? "تصویر را همین‌جا رها کن" : "انتخاب یا رها کردن تصویر"), M.createElement("small", null, "JPG · PNG · WEBP — حداکثر ۲۰ مگابایت"), M.createElement("input", {
        hidden: !0,
        type: "file",
        accept: "image/*",
        disabled: busy,
        onChange: event => {
          const file = event.target.files && event.target.files[0];
          event.target.value = "", file && onFile(stage, file)
        }
      })))
    }
    
    function paTradeDocumentsCenter({
      trades,
      account,
      focusTradeId,
      onOpenHistory,
      onToast
    }) {
      const sortedTrades = M.useMemo(() => [...(trades || [])].sort((a, b) => new Date(b.entryDate) - new Date(a.entryDate)), [trades]),
        [docs, setDocs] = M.useState({}),
        [selectedId, setSelectedId] = M.useState(() => sortedTrades[0] && sortedTrades[0].id || ""),
        [busy, setBusy] = M.useState(""),
        [annotating, setAnnotating] = M.useState(null),
        [zoom, setZoom] = M.useState(null),
        [filter, setFilter] = M.useState(""),
        [galleryTag, setGalleryTag] = M.useState(""),
        migratedRef = M.useRef("");
      M.useEffect(() => {
        if (!focusTradeId || !sortedTrades.some(trade => trade.id === focusTradeId)) return;
        setSelectedId(focusTradeId);
        const timer = setTimeout(() => {
          const target = document.querySelector(".pa-doc-history-link");
          target && target.scrollIntoView({
            behavior: "smooth",
            block: "center"
          })
        }, 100);
        return () => clearTimeout(timer)
      }, [focusTradeId, sortedTrades]);
      M.useEffect(() => {
        let live = !0;
        (async () => {
          let next = {};
          try {
            const saved = await window.storage.get(PA_DOCS_KEY);
            saved && saved.value && (next = paSafeJson(saved.value, {}) || {})
          } catch (_) {}
          if (!live) return;
          const valid = focusTradeId && sortedTrades.some(trade => trade.id === focusTradeId) ? focusTradeId : sortedTrades.some(trade => trade.id === selectedId) ? selectedId : sortedTrades[0] && sortedTrades[0].id || "";
          setDocs(next), setSelectedId(valid)
        })();
        return () => {
          live = !1
        }
      }, [account && account.id]);
      M.useEffect(() => {
        if (!sortedTrades.length || migratedRef.current === (account && account.id)) return;
        migratedRef.current = account && account.id;
        (async () => {
          let next = {},
            changed = !1;
          try {
            const saved = await window.storage.get(PA_DOCS_KEY);
            saved && saved.value && (next = paSafeJson(saved.value, {}) || {})
          } catch (_) {}
          for (const trade of sortedTrades.filter(item => item.hasChart && !(next[item.id] && next[item.id].before && next[item.id].before.data))) try {
            const legacy = await window.storage.get(`pa-chart-${trade.id}`);
            if (legacy && legacy.value) {
              next = {
                ...next,
                [trade.id]: {
                  ...next[trade.id] || {},
                  accountId: trade.accountId,
                  before: {
                    data: legacy.value,
                    originalData: legacy.value,
                    tags: ["نسخه قدیمی"],
                    migratedAt: new Date().toISOString()
                  },
                  updatedAt: new Date().toISOString()
                }
              }, changed = !0
            }
          } catch (_) {}
          changed && await window.storage.set(PA_DOCS_KEY, JSON.stringify(next)), setDocs(next)
        })()
      }, [sortedTrades, account && account.id]);
      const persist = async next => {
          setDocs(next);
          try {
            await window.storage.set(PA_DOCS_KEY, JSON.stringify(next))
          } catch (_) {
            onToast("فضای ذخیره‌سازی تصویر کافی نیست؛ یک تصویر کم‌حجم‌تر انتخاب کن")
          }
        },
        selectedTrade = sortedTrades.find(trade => trade.id === selectedId),
        selectedDoc = docs[selectedId] || {},
        updateStage = (stage, item) => {
          const nextEntry = {
            ...selectedDoc,
            [stage]: item,
            accountId: account && account.id,
            updatedAt: new Date().toISOString()
          };
          persist({
            ...docs,
            [selectedId]: nextEntry
          })
        },
        upload = async (stage, file) => {
          if (!selectedId || !file) return;
          setBusy(stage);
          try {
            const data = await oZ(file, 2400, 5 * 1024 * 1024);
            updateStage(stage, {
              data,
              originalData: data,
              tags: selectedDoc[stage] && selectedDoc[stage].tags || [],
              fileName: file.name,
              updatedAt: new Date().toISOString(),
              annotationCount: 0
            }), onToast(stage === "before" ? "تصویر قبل از ورود ذخیره شد" : "تصویر بعد از خروج ذخیره شد")
          } catch (error) {
            onToast(error && error.message || "پردازش تصویر انجام نشد")
          } finally {
            setBusy("")
          }
        },
        remove = stage => {
          const nextEntry = {
            ...selectedDoc
          };
          delete nextEntry[stage], nextEntry.updatedAt = new Date().toISOString();
          const next = {
            ...docs
          };
          nextEntry.before || nextEntry.after ? next[selectedId] = nextEntry : delete next[selectedId], persist(next)
        },
        setTags = (stage, tags) => updateStage(stage, {
          ...selectedDoc[stage],
          tags
        }),
        allTags = [...new Set(Object.entries(docs).filter(([tradeId]) => sortedTrades.some(trade => trade.id === tradeId)).flatMap(([, item]) => [...item.before && item.before.tags || [], ...item.after && item.after.tags || []]))].slice(0, 30),
        gallery = sortedTrades.filter(trade => {
          const item = docs[trade.id],
            search = filter.trim().toLowerCase(),
            haystack = [trade.setupName, Tf(trade.symbol).fa, Tf(trade.symbol).code, ...item && item.before && item.before.tags || [], ...item && item.after && item.after.tags || []].filter(Boolean).join(" ").toLowerCase();
          return item && (item.before && item.before.data || item.after && item.after.data) && (!search || haystack.includes(search)) && (!galleryTag || [...item.before && item.before.tags || [], ...item.after && item.after.tags || []].includes(galleryTag))
        });
      return M.createElement("div", {
        className: "pa-feature-center pa-docs-center",
        "data-testid": "trade-documents-center"
      }, M.createElement("section", {
        className: "pa-feature-hero pa-docs-hero"
      }, M.createElement("div", null, M.createElement("span", {
        className: "pa-feature-eyebrow"
      }, "VISUAL JOURNAL"), M.createElement("h1", null, "استودیوی مستندات معامله"), M.createElement("p", null, "قبل و بعد چارت را کنار هر معامله نگه دار، مستقیم روی تصویر یادداشت بگذار و ستاپ‌ها را در گالری مرور کن.")), M.createElement("div", {
        className: "pa-docs-hero-stat"
      }, M.createElement("b", {
        className: "num"
      }, gallery.length.toLocaleString("fa-IR")), M.createElement("span", null, "ستاپ مستند"))), !sortedTrades.length ? M.createElement("section", {
        className: "pa-feature-empty"
      }, M.createElement("b", null, "هنوز معامله‌ای برای مستندسازی نداری"), M.createElement("p", null, "ابتدا یک معامله ثبت یا از CSV/MetaTrader وارد کن؛ سپس تصاویر قبل و بعد را به آن متصل کن.")) : M.createElement(M.Fragment, null, M.createElement("section", {
        className: "pa-card pa-doc-trade-picker"
      }, M.createElement("div", null, M.createElement("label", null, "معامله فعال"), M.createElement("select", {
        className: "pa-select",
        value: selectedId,
        onChange: event => setSelectedId(event.target.value),
        "data-testid": "document-trade-select"
      }, sortedTrades.map(trade => M.createElement("option", {
        value: trade.id,
        key: trade.id
      }, Tf(trade.symbol).code, " · ", trade.setupName || "بدون نام ستاپ", " · ", new Date(trade.entryDate).toLocaleDateString("fa-IR"))))), selectedTrade && M.createElement("div", {
        className: "pa-doc-trade-meta"
      }, M.createElement("span", {
        className: "pa-badge " + (selectedTrade.direction === "buy" ? "buy" : "sell")
      }, selectedTrade.direction === "buy" ? "BUY" : "SELL"), M.createElement("b", null, selectedTrade.setupName || "ستاپ بدون نام"), M.createElement("span", {
        className: "num " + (wr(selectedTrade) >= 0 ? "pos" : "neg")
      }, Ke(wr(selectedTrade))))), selectedTrade && M.createElement("section", {
        className: "pa-card pa-doc-history-link",
        children: M.createElement("div", null, M.createElement("span", {
          className: "pa-feature-eyebrow"
        }, "TRADE TIMELINE"), M.createElement("h3", null, "تاریخچه همین معامله"), M.createElement("p", null, "جزئیات ورود، مدیریت ریسک، روانشناسی و نتیجه ثبت‌شده این معامله را در تاریخچه ببین."), M.createElement("button", {
          type: "button",
          className: "pa-btn primary",
          onClick: () => onOpenHistory && onOpenHistory(selectedTrade.id)
        }, M.createElement(l2, {
          size: 15
        }), " مشاهده این معامله در تاریخچه"))
      }), M.createElement("section", {
        className: "pa-doc-stages"
      }, M.createElement(paDocumentDrop, {
        stage: "before",
        item: selectedDoc.before,
        busy: busy === "before",
        onFile: upload,
        onRemove: remove,
        onAnnotate: setAnnotating,
        onTags: setTags,
        onZoom: setZoom
      }), M.createElement(paDocumentDrop, {
        stage: "after",
        item: selectedDoc.after,
        busy: busy === "after",
        onFile: upload,
        onRemove: remove,
        onAnnotate: setAnnotating,
        onTags: setTags,
        onZoom: setZoom
      })), M.createElement(paCompareView, {
        before: selectedDoc.before && selectedDoc.before.data,
        after: selectedDoc.after && selectedDoc.after.data
      }), M.createElement("section", {
        className: "pa-card pa-setup-gallery"
      }, M.createElement("header", null, M.createElement("div", null, M.createElement("span", {
        className: "pa-feature-eyebrow"
      }, "SETUP LIBRARY"), M.createElement("h2", null, "گالری ستاپ‌ها")), M.createElement("input", {
        className: "pa-input",
        value: filter,
        placeholder: "جست‌وجوی ستاپ، نماد یا تگ…",
        onChange: event => setFilter(event.target.value)
      })), allTags.length ? M.createElement("div", {
        className: "pa-gallery-tags"
      }, M.createElement("button", {
        className: !galleryTag ? "active" : "",
        onClick: () => setGalleryTag("")
      }, "همه"), allTags.map(tag => M.createElement("button", {
        className: galleryTag === tag ? "active" : "",
        onClick: () => setGalleryTag(tag),
        key: tag
      }, "#", tag))) : null, gallery.length ? M.createElement("div", {
        className: "pa-gallery-grid"
      }, gallery.map(trade => {
        const item = docs[trade.id],
          cover = item.before && item.before.data || item.after && item.after.data;
        return M.createElement("button", {
          className: "pa-gallery-item",
          key: trade.id,
          onClick: () => {
            setSelectedId(trade.id), document.querySelector(".pa-docs-hero") && document.querySelector(".pa-docs-hero").scrollIntoView({
              behavior: "smooth"
            })
          }
        }, M.createElement("div", {
          className: "pa-gallery-cover"
        }, M.createElement("img", {
          src: cover,
          alt: trade.setupName || "ستاپ معامله"
        }), M.createElement("span", null, item.before && item.before.data ? "قبل ✓" : "قبل —", " · ", item.after && item.after.data ? "بعد ✓" : "بعد —")), M.createElement("div", {
          className: "pa-gallery-info"
        }, M.createElement("b", null, trade.setupName || "ستاپ بدون نام"), M.createElement("span", null, Tf(trade.symbol).code, " · ", new Date(trade.entryDate).toLocaleDateString("fa-IR"))), M.createElement("div", {
          className: "pa-gallery-chips"
        }, [...item.before && item.before.tags || [], ...item.after && item.after.tags || []].slice(0, 4).map(tag => M.createElement("i", {
          key: tag
        }, "#", tag))))
      })) : M.createElement("div", {
        className: "pa-compare-empty"
      }, "با فیلتر انتخاب‌شده تصویری پیدا نشد."))), annotating && selectedDoc[annotating] && M.createElement(paChartAnnotator, {
        src: Array.isArray(selectedDoc[annotating].annotationActions) ? selectedDoc[annotating].originalData || selectedDoc[annotating].data : selectedDoc[annotating].data,
        initialActions: selectedDoc[annotating].annotationActions || [],
        onCancel: () => setAnnotating(null),
        onSave: (data, count, savedActions) => {
          updateStage(annotating, {
            ...selectedDoc[annotating],
            data,
            originalData: Array.isArray(selectedDoc[annotating].annotationActions) ? selectedDoc[annotating].originalData || selectedDoc[annotating].data : selectedDoc[annotating].data,
            annotationActions: savedActions,
            annotationCount: count,
            annotatedAt: new Date().toISOString()
          }), setAnnotating(null), onToast("حاشیه‌نویسی ذخیره شد و برای جابجایی بعدی قابل ویرایش است")
        }
      }), zoom && M.createElement("div", {
        className: "pa-lightbox",
        onClick: () => setZoom(null)
      }, M.createElement("button", {
        className: "pa-lightbox-close",
        onClick: () => setZoom(null)
      }, "×"), M.createElement("img", {
        src: zoom,
        className: "pa-lightbox-img",
        alt: "نمای کامل مستند معامله",
        onClick: event => event.stopPropagation()
      })))
    }
    registry["documents"] = paTradeDocumentsCenter;
  }
})();
