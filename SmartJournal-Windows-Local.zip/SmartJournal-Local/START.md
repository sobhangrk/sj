# چطور سایت را اجرا کنم؟ (ویندوز)

> این سایت یک **برنامه سرور** است، نه یک فایل HTML.
> تا وقتی سرور را اجرا نکنید، مرورگر می‌گوید **«This site can't be reached»**.
> این طبیعی است — یعنی هنوز چیزی پشت آدرس `localhost:3000` وجود ندارد.

---

## ⚠️ سه اشتباه رایج

| ❌ کار اشتباه | چه می‌بینید |
|---|---|
| دوبار کلیک روی `public/index.html` | ظاهر بدون عملکرد، آدرس `file:///…` |
| باز کردن `localhost:3000` بدون اجرای سرور | **This site can't be reached** |
| بستن پنجره ترمینال بعد از اجرا | سایت قطع می‌شود |

آدرس درست همیشه `http://localhost:3000` است و **پنجره سرور باید باز بماند**.

---

## گام‌به‌گام (ویندوز)

### گام ۱ — Node.js را نصب کنید (فقط یک‌بار در عمر سیستم)

1. به [nodejs.org](https://nodejs.org) بروید
2. دکمه بزرگ **LTS** را دانلود کنید (`.msi`)
3. نصب کنید — همه‌جا Next / Next / Install
4. **کامپیوتر را ری‌استارت نکنید، ولی حتماً پنجره‌های ترمینال باز را ببندید**

برای اطمینان، `cmd` را باز کنید و بزنید:

```
node -v
```

باید نسخهٔ `v20` یا جدیدتر چاپ شود. اگر گفت `'node' is not recognized`
یعنی نصب کامل نشده یا ترمینال را نبسته‌اید.

### گام ۲ — فایل zip را از حالت فشرده خارج کنید

روی `SmartJournal-Windows-Local.zip` راست‌کلیک → **Extract All**.

⚠️ **مستقیم از داخل zip اجرا نکنید.** ویندوز فایل‌ها را در یک پوشه موقت باز
می‌کند و نصب وابستگی‌ها شکست می‌خورد.

بعد از خارج کردن، باید پوشه‌ای به این شکل داشته باشید:

```
SmartJournal-Local\
   ├── start.bat        ← این
   ├── server.js
   ├── package.json
   └── public\
```

### گام ۳ — روی `start.bat` دوبار کلیک کنید

یک پنجره مشکی باز می‌شود و مرحله‌به‌مرحله می‌گوید چه می‌کند:

```
[OK] Node v20.x
Installing runtime dependencies - first run only, may take a few minutes.
[OK] dependencies ready
Starting server...
Waiting for http://localhost:3000 ...
[OK] server is UP

   Site        http://localhost:3000
   Journal     http://localhost:3000/journal
   Local mode  no phone / no SMS; data stays in this browser
```

بار اول برای نصب وابستگی‌های Node به اینترنت نیاز است و ممکن است چند دقیقه طول بکشد. **صبر کنید** — پنجره را نبندید.

بعد از `server is UP` مرورگر خودکار باز می‌شود.

> اگر ویندوز پیام «Windows protected your PC» داد:
> **More info** → **Run anyway**.

### گام ۴ — دو پنجره باز می‌ماند

| پنجره | کارش |
|---|---|
| `SmartJournal server - do not close` | خودِ سایت. **باز بماند.** |
| پنجره اول | فقط راهنما؛ می‌توانید ببندید. |

**برای خاموش کردن سایت:** پنجره `SmartJournal server` را ببندید.

---

## اگر باز هم «This site can't be reached» دیدید

پنجره `SmartJournal server` را نگاه کنید. متن خطا همان‌جاست.

### حالت ۱ — پنجره بسته شده / اصلاً باز نشد

یعنی Node نصب نیست یا `start.bat` را از داخل zip اجرا کرده‌اید.
گام ۱ و ۲ را دوباره انجام دهید.

### حالت ۲ — `Error: listen EADDRINUSE ... :3000`

پورت اشغال است (یک نسخه قبلی هنوز اجراست). در `cmd` بزنید:

```
netstat -ano | findstr :3000
taskkill /PID <عددی که آخر خط دیدید> /F
```

یا با پورت دیگر اجرا کنید — در `cmd` داخل همان پوشه:

```
set PORT=3001
start.bat
```

### حالت ۳ — `Cannot find module 'express'`

نصب وابستگی‌ها کامل نشده. در `cmd` داخل پوشه `SmartJournal-Local`:

```
npm ci --omit=dev
set NODE_ENV=development
set HOST=127.0.0.1
set LOCAL_NO_PHONE=true
set SEED_DEMO_DATA=false
npm start
```

### حالت ۴ — `npm ci` خطای شبکه / timeout می‌دهد

```
npm config set registry https://registry.npmmirror.com
npm ci --omit=dev --no-audit --no-fund
```

اگر باز هم نشد، فیلترشکن را روشن کنید و همین دستور `npm ci` را دوباره بزنید.
(این فقط برای دانلود کتابخانه‌هاست؛ بعدش برای استفادهٔ روزانه اینترنت لازم نیست.)

### حالت ۵ — سرور بالاست ولی مرورگر باز نمی‌کند

آدرس را **دستی** در مرورگر تایپ کنید:

```
http://localhost:3000
```

نه `https`، نه `www`، نه `file://`.

---

## راه دستی (اگر `start.bat` را دوست ندارید)

`cmd` را باز کنید، بروید داخل پوشه، سه دستور:

```
cd C:\مسیر\به\SmartJournal-Local
npm ci --omit=dev
set NODE_ENV=development
set HOST=127.0.0.1
set LOCAL_NO_PHONE=true
set SEED_DEMO_DATA=false
npm start
```

وقتی این خط را دیدید یعنی آماده است:

```json
{"event":"server_started","port":3000,"databaseEngine":"sqlite", ...}
```

حالا `http://localhost:3000` را باز کنید. **پنجره cmd را نبندید.**
برای توقف: `Ctrl + C`.

---

## استفاده بدون شماره و پیامک

در نسخهٔ ویندوزی، `start.bat` حالت محلی را فعال می‌کند. در سایت روی **ساخت حساب محلی**
بزنید و فقط نام، یک نام کاربری انگلیسی و رمز عبور بسازید؛ شماره موبایل، پیامک و کد تأیید لازم نیست.

- ژورنال و پروفایل محلی در همان مرورگر ویندوز ذخیره می‌شوند؛ حساب ابری یا همگام‌سازی بین دستگاه‌ها نیست.
- هر بار از همان مرورگر و همان آدرس `http://localhost:3000` استفاده کنید.
- پاک‌کردن داده‌های مرورگر می‌تواند اطلاعات ژورنال را حذف کند؛ از خروجی/پشتیبان داخل برنامه استفاده کنید.
- این حالت فقط برای استفادهٔ شخصی روی همین کامپیوتر است و سرور فقط روی `127.0.0.1` گوش می‌دهد؛ آن را برای سایت عمومی deploy نکنید.
- پنل `/admin` جداست و برای ثبت معامله و استفاده از ژورنال لازم نیست.

---

## اگر نسخه قدیمی سایت را دیدید

سرویس‌ورکر مرورگر نسخه کهنه را نگه داشته. یک‌بار این آدرس را باز کنید:

```
http://localhost:3000/?fresh=1
```

برای اطمینان از نسخه، در کنسول مرورگر (کلید `F12`):

```js
document.querySelector('meta[name=pa-build]').content
```

---

## لینوکس / مک

```bash
cd SmartJournal-Local
bash start.sh
```

این اجرا هم محلی، loopback و بدون شماره/پیامک است. برای اجرای دستی، دستورهای ویندوز را
با متغیرهای `NODE_ENV=development HOST=127.0.0.1 LOCAL_NO_PHONE=true SEED_DEMO_DATA=false` اجرا کنید.

---

## اجرا روی سرور واقعی (هاست ایران)

این راهنما فقط برای اجرای محلی روی کامپیوتر خودتان است.
برای production — PostgreSQL، Nginx، HTTPS، systemd، بک‌آپ — به
**`DEPLOY.md`** و **`HOSTING.md`** مراجعه کنید.

```bash
npm ci --omit=dev
cp .env.production.example .env      # مقادیرش را پر کنید
npm run preflight:production         # چک‌لیست آمادگی
NODE_ENV=production npm start
```

> 🔴 قبل از راه‌اندازی واقعی حتماً **درگاه پیامک** را تنظیم کنید
> (پنل → پیامک → Kavenegar یا ملی‌پیامک). بدون آن هیچ کاربری نمی‌تواند
> ثبت‌نام یا ورود کند و `POST /api/auth/signup` خطای ۵۰۳ می‌دهد.

---

## دستورهای مفید

```bash
npm start                   # اجرای سایت
npm run dev                 # اجرا با ری‌استارت خودکار هنگام تغییر کد
npm run check               # بررسی نحوی همه فایل‌ها
npm run build:index         # ساخت دوباره public/index.html
npm run smoke:journal-open  # تست باز شدن ژورنال با مرورگر واقعی
npm run preflight:production
```
