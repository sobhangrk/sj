#!/usr/bin/env node
'use strict';
/* ============================================================================
   آزمون جداسازی باندل لندینگ — npm run smoke:split

   مطمئن می‌شود که:
     • صفحهٔ اصلی دیگر باندل ۱.۵ مگابایتی را داخل خودش ندارد و زیر سقف وزن است،
     • فایل‌های chunk با نام hashدار و نسخهٔ فشرده وجود دارند و از نظر نحوی سالم‌اند،
     • لودر و همهٔ اسکریپت‌های لازم هنوز در HTML هستند،
     • سرور chunk را با کش immutable و brotli می‌دهد،
     • / بدون باندل بارگذاری می‌شود ولی /journal دارای modulepreload است.

   اگر سرور بالا باشد (BASE=http://127.0.0.1:3000) آزمون‌های شبکه هم اجرا می‌شوند؛
   وگرنه فقط آزمون‌های فایلی انجام و بقیه رد می‌شوند.
========================================================================== */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');
const BASE = process.env.BASE || '';
const LANDING_LIMIT_KB = Number(process.env.LANDING_LIMIT_KB || 250);

let pass = 0, fail = 0, skip = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✅ ${name}${extra ? ' — ' + extra : ''}`); }
  else { fail++; console.log(`  ❌ ${name}${extra ? ' — ' + extra : ''}`); }
};
const skipped = (name, why) => { skip++; console.log(`  ⏭  ${name} — ${why}`); };

(async () => {
  console.log('\n— جداسازی باندل لندینگ —\n');

  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const sizeKb = Buffer.byteLength(html) / 1024;
  ok('صفحهٔ اصلی سبک است', sizeKb < LANDING_LIMIT_KB, `${sizeKb.toFixed(1)} KB (سقف ${LANDING_LIMIT_KB} KB)`);
  ok('باندل React دیگر inline نیست', !html.includes('createRoot'));
  ok('اسکریپت ورود دیگر inline نیست', !html.includes('id="pa-premium-auth-motion"'));
  ok('لودر ژورنال در HTML هست', html.includes('id="pa-journal-loader"'));
  ok('لندینگ هنوز کامل است', html.includes('id="pa-landing"') && html.includes('id="root"') && html.includes('id="pa-auth"'));
  for (const src of ['/journal-cloud.js', '/journal-ux-runtime.js', '/site-content.js']) {
    ok(`اسکریپت ${src} هنوز لود می‌شود`, html.includes(`src="${src}"`));
  }
  ok('لودر اسکریپت‌های جانبی وجود دارد', html.includes('id="pa-journal-optional-loader"'));
  for (const src of ['/journal-plan-support.js', '/journal-card-payment.js', '/journal-share-card.js', '/support-widget.js']) {
    ok(`اسکریپت سنگین ${src} eager نیست`, !html.includes(`src="${src}"`));
  }

  const manifest = JSON.parse(fs.readFileSync(path.join(PUBLIC, 'app', 'chunks.json'), 'utf8'));
  const optional = manifest.optional || {};
  ok('اسکریپت‌های جانبی manifest دارند', ['plan', 'card', 'share', 'support'].every(key => optional[key]));
  for (const key of ['app', 'auth']) {
    const rel = manifest[key];
    ok(`نام chunk ${key} hash دارد`, /^\/app\/journal-(app|auth)\.[0-9a-f]{8}\.js$/.test(rel), rel);
    const file = path.join(PUBLIC, rel.replace(/^\//, ''));
    ok(`فایل ${key} ساخته شده`, fs.existsSync(file));
    ok(`نسخهٔ brotli ${key} ساخته شده`, fs.existsSync(file + '.br'));
    ok(`نسخهٔ gzip ${key} ساخته شده`, fs.existsSync(file + '.gz'));
    ok(`${key} در HTML صدا زده می‌شود`, html.includes(rel));
    /* با vm.Script بررسی می‌شود نه new Function: بلوک inline اجازهٔ `return`
       سطح‌بالا دارد ولی فایل مستقل ندارد — همان باگ قدیمی journal-cloud-auth. */
    try { new vm.Script(fs.readFileSync(file, 'utf8'), { filename: rel }); ok(`${key} به‌عنوان فایل مستقل معتبر است`, true); }
    catch (error) { ok(`${key} به‌عنوان فایل مستقل معتبر است`, /import|export/.test(String(error.message)), 'ماژول ES'); }
  }
  ok('باندل واقعاً همان برنامه است',
    fs.readFileSync(path.join(PUBLIC, manifest.app.replace(/^\//, '')), 'utf8').includes('createRoot'));

  for (const [name, rel] of Object.entries(optional)) {
    ok(`نام chunk اختیاری ${name} hash دارد`, /^\/app\/journal-optional-[a-z0-9-]+\.[0-9a-f]{8}\.js$/.test(rel), rel);
    const file = path.join(PUBLIC, rel.replace(/^\//, ''));
    ok(`فایل chunk اختیاری ${name} ساخته شده`, fs.existsSync(file));
    ok(`نسخهٔ brotli chunk اختیاری ${name} ساخته شده`, fs.existsSync(file + '.br'));
    ok(`نسخهٔ gzip chunk اختیاری ${name} ساخته شده`, fs.existsSync(file + '.gz'));
    try { new vm.Script(fs.readFileSync(file, 'utf8'), { filename: rel }); ok(`chunk اختیاری ${name} از نظر نحوی معتبر است`, true); }
    catch (error) { ok(`chunk اختیاری ${name} از نظر نحوی معتبر است`, false, error.message); }
  }

  const tabs = manifest.tabs || {};
  ok('تب‌های ژورنال manifest دارند', Object.keys(tabs).length >= 8, `${Object.keys(tabs).length} تب`);
  for (const [tab, rel] of Object.entries(tabs)) {
    ok(`نام chunk تب ${tab} hash دارد`, /^\/app\/journal-tab-[a-z0-9-]+\.[0-9a-f]{8}\.js$/.test(rel), rel);
    const file = path.join(PUBLIC, rel.replace(/^\//, ''));
    ok(`فایل تب ${tab} ساخته شده`, fs.existsSync(file));
    ok(`نسخهٔ brotli تب ${tab} ساخته شده`, fs.existsSync(file + '.br'));
    ok(`نسخهٔ gzip تب ${tab} ساخته شده`, fs.existsSync(file + '.gz'));
    try { new vm.Script(fs.readFileSync(file, 'utf8'), { filename: rel }); ok(`تب ${tab} از نظر نحوی معتبر است`, true); }
    catch (error) { ok(`تب ${tab} از نظر نحوی معتبر است`, false, error.message); }
  }

  const sw = fs.readFileSync(path.join(PUBLIC, 'service-worker.js'), 'utf8');
  ok('service worker مسیر /app را می‌شناسد', sw.includes('/app/journal-'));

  if (!BASE) {
    skipped('آزمون‌های HTTP', 'سرور اجرا نیست (BASE تنظیم نشده)');
  } else {
    const get = async (url, headers = {}) => {
      const response = await fetch(BASE + url, { headers, redirect: 'manual' });
      return { status: response.status, headers: response.headers, body: await response.text() };
    };
    const home = await get('/');
    ok('GET / پاسخ ۲۰۰ می‌دهد', home.status === 200, String(home.status));
    ok('GET / باندل را inline نمی‌فرستد', !home.body.includes('createRoot'));
    ok('GET / لودر را دارد', home.body.includes('id="pa-journal-loader"'));
    ok('GET / حجم کمی دارد', Buffer.byteLength(home.body) / 1024 < LANDING_LIMIT_KB,
      (Buffer.byteLength(home.body) / 1024).toFixed(1) + ' KB');

    const journal = await get('/journal');
    ok('GET /journal پاسخ ۲۰۰ می‌دهد', journal.status === 200, String(journal.status));
    ok('GET /journal باندل را modulepreload می‌کند', journal.body.includes('rel="modulepreload"') && journal.body.includes(manifest.app));

    const chunk = await get(manifest.app, { 'accept-encoding': 'br' });
    ok('chunk با ۲۰۰ سرو می‌شود', chunk.status === 200, String(chunk.status));
    ok('chunk کش immutable دارد', String(chunk.headers.get('cache-control') || '').includes('immutable'),
      String(chunk.headers.get('cache-control')));
    ok('chunk نوع محتوای درست دارد', String(chunk.headers.get('content-type') || '').includes('javascript'));
    for (const [name, rel] of Object.entries(optional)) {
      const optionalChunk = await get(rel, { 'accept-encoding': 'br' });
      ok(`chunk اختیاری ${name} با ۲۰۰ سرو می‌شود`, optionalChunk.status === 200, String(optionalChunk.status));
      ok(`chunk اختیاری ${name} کش immutable دارد`, String(optionalChunk.headers.get('cache-control') || '').includes('immutable'), String(optionalChunk.headers.get('cache-control')));
      ok(`chunk اختیاری ${name} نوع محتوای درست دارد`, String(optionalChunk.headers.get('content-type') || '').includes('javascript'));
    }

    const missing = await get('/app/journal-app.deadbeef.js');
    ok('chunk ناموجود ۴۰۴ می‌دهد', missing.status === 404, String(missing.status));
    for (const [tab, rel] of Object.entries(tabs)) {
      const route = await get(rel, { 'accept-encoding': 'br' });
      ok(`chunk تب ${tab} با ۲۰۰ سرو می‌شود`, route.status === 200, String(route.status));
      ok(`chunk تب ${tab} کش immutable دارد`, String(route.headers.get('cache-control') || '').includes('immutable'), String(route.headers.get('cache-control')));
      ok(`chunk تب ${tab} نوع محتوای درست دارد`, String(route.headers.get('content-type') || '').includes('javascript'));
    }
  }

  console.log(`\n  ${pass} قبول · ${fail} رد · ${skip} رد‌شده\n`);
  process.exit(fail ? 1 : 0);
})().catch(error => { console.error('❌ ' + error.stack); process.exit(1); });
