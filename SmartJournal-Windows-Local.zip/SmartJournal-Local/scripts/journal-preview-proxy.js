'use strict';
const http = require('node:http');

const upstream = { host: '127.0.0.1', port: 3000 };
const server = http.createServer((req, res) => {
  if (req.url === '/') {
    res.writeHead(302, { location: '/journal', 'cache-control': 'no-store' });
    res.end();
    return;
  }
  const path = req.url;
  const headers = { ...req.headers, host: `${upstream.host}:${upstream.port}` };
  const proxy = http.request({ ...upstream, method: req.method, path, headers }, upstreamResponse => {
    res.writeHead(upstreamResponse.statusCode || 502, upstreamResponse.headers);
    upstreamResponse.pipe(res);
  });
  proxy.on('error', error => {
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain; charset=utf-8' });
    res.end(`Journal preview upstream error: ${error.message}`);
  });
  req.pipe(proxy);
});

server.listen(3001, '0.0.0.0', () => {
  console.log('Journal preview proxy listening on 0.0.0.0:3001; / opens /journal');
});
