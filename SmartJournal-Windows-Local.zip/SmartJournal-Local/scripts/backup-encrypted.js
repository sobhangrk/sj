'use strict';
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {pipeline}=require('node:stream/promises');
const Database=require('better-sqlite3');
const {S3Client,ListObjectsV2Command,GetObjectCommand}=require('@aws-sdk/client-s3');
const {Upload}=require('@aws-sdk/lib-storage');
const appRoot=path.resolve(process.env.BACKUP_SOURCE_DIR||path.join(__dirname,'..'));
const root=path.resolve(process.env.BACKUP_DIR||path.join(__dirname,'..','backups'));
const secret=String(process.env.BACKUP_ENCRYPTION_KEY||(process.env.BACKUP_ENCRYPTION_KEY_FILE?fs.readFileSync(process.env.BACKUP_ENCRYPTION_KEY_FILE,'utf8').trim():'')||'');
if(Buffer.byteLength(secret)<32)throw new Error('BACKUP_ENCRYPTION_KEY must contain at least 32 bytes.');
const stamp=new Date().toISOString().replace(/[:.]/g,'-'),staging=fs.mkdtempSync(path.join(os.tmpdir(),'pa-journal-backup-')),archiveBase=`pa-journal-${stamp}`,plainTar=path.join(root,archiveBase+'.tar.gz'),encrypted=path.join(root,archiveBase+'.tar.gz.enc');
fs.mkdirSync(root,{recursive:true});
function exec(command,args,options={}){return new Promise((resolve,reject)=>{const child=spawn(command,args,{stdio:['ignore','ignore','pipe'],...options});let stderr='';child.stderr.on('data',data=>stderr+=data);child.on('error',reject);child.on('close',code=>code===0?resolve():reject(new Error(`${command} exited ${code}: ${stderr.slice(-1000)}`)))})}
function sha256(file){const hash=crypto.createHash('sha256'),fd=fs.openSync(file,'r'),buffer=Buffer.alloc(1024*1024);let read=0,position=0;while((read=fs.readSync(fd,buffer,0,buffer.length,position))>0){hash.update(buffer.subarray(0,read));position+=read}fs.closeSync(fd);return hash.digest('hex')}
function treeStats(target){let files=0,bytes=0;if(!fs.existsSync(target))return {files,bytes};const walk=current=>{for(const entry of fs.readdirSync(current,{withFileTypes:true})){const full=path.join(current,entry.name);if(entry.isDirectory())walk(full);else if(entry.isFile()){files++;bytes+=fs.statSync(full).size}}};walk(target);return {files,bytes}}
function copySiteFiles(staging){
  const target=path.join(staging,'site');
  const excludedTop=new Set(['node_modules','data','backups','.git','.tmp','coverage','logs','drill-reports','secrets','.secrets','credentials','private']);
  fs.cpSync(appRoot,target,{recursive:true,filter(source){
    const relative=path.relative(appRoot,source),parts=relative?relative.split(path.sep):[];
    if(parts.length&&excludedTop.has(parts[0].toLowerCase()))return false;
    const name=path.basename(source),lower=name.toLowerCase();
    if(/^\.env(?:$|\.)/i.test(name)&&!name.toLowerCase().endsWith('.example'))return false;
    if(/\.(pem|key|p12|pfx|crt|log|db|sqlite|sqlite3)$/i.test(lower))return false;
    if(/^(?:secrets?|credentials?|runtime-secrets?)\.(?:json|ya?ml|toml|js|cjs)$/i.test(lower))return false;
    return true;
  }});
  return {...treeStats(target),included:true,excluded:['node_modules','data','backups','.git','.tmp','coverage','logs','drill-reports','secrets/.secrets/credentials/private','dotenv files except .example','*.pem/*.key/*.p12/*.pfx/*.crt/*.log/*.db/*.sqlite*','secret/credential config files']};
}
async function createDatabaseBackup(){const databaseUrl=String(process.env.DATABASE_URL||''),postgres=String(process.env.DB_ENGINE||'').toLowerCase()==='postgres'||/^postgres(ql)?:\/\//i.test(databaseUrl);if(postgres){const target=path.join(staging,'database.dump'),schema=String(process.env.PA_PG_SCHEMA||'pa_journal');if(!/^[a-z][a-z0-9_]{0,62}$/.test(schema))throw new Error('PA_PG_SCHEMA must be a safe PostgreSQL identifier.');const args=['--format=custom','--no-owner','--no-acl','--schema',schema,'--file',target],env={...process.env},password=process.env.PGPASSWORD||(process.env.PGPASSWORD_FILE?fs.readFileSync(process.env.PGPASSWORD_FILE,'utf8').trim():'');if(databaseUrl)args.push(databaseUrl);else{if(!process.env.PGHOST||!process.env.PGDATABASE||!process.env.PGUSER)throw new Error('PostgreSQL backup requires DATABASE_URL or PGHOST/PGDATABASE/PGUSER.');args.push('--host',process.env.PGHOST,'--port',String(process.env.PGPORT||5432),'--username',process.env.PGUSER,'--dbname',process.env.PGDATABASE);env.PGPASSWORD=password}await exec('pg_dump',args,{env});return {engine:'postgresql',schema,file:'database.dump',sha256:sha256(target)}}const source=path.resolve(process.env.DATABASE_PATH||path.join(__dirname,'..','data','admin.db')),target=path.join(staging,'admin.db');const db=new Database(source,{readonly:true});try{await db.backup(target)}finally{db.close()}const verify=new Database(target,{readonly:true});try{const result=verify.pragma('integrity_check',{simple:true});if(result!=='ok')throw new Error(`SQLite integrity_check failed: ${result}`)}finally{verify.close()}return {engine:'sqlite',file:'admin.db',sha256:sha256(target)}}
function trimSlashes(value){let result=String(value||'');while(result.startsWith('/'))result=result.slice(1);while(result.endsWith('/'))result=result.slice(0,-1);return result}
function s3Client(){const bucket=String(process.env.S3_BUCKET||'');if(!bucket)throw new Error('S3_BUCKET is required for a full backup when STORAGE_BACKEND is s3 or hybrid.');const accessKeyId=process.env.S3_ACCESS_KEY_ID,secretAccessKey=process.env.S3_SECRET_ACCESS_KEY||(process.env.S3_SECRET_ACCESS_KEY_FILE?fs.readFileSync(process.env.S3_SECRET_ACCESS_KEY_FILE,'utf8').trim():'');return {bucket,client:new S3Client({region:process.env.S3_REGION||'us-east-1',endpoint:process.env.S3_ENDPOINT||undefined,forcePathStyle:String(process.env.S3_FORCE_PATH_STYLE||'false')==='true',credentials:accessKeyId?{accessKeyId,secretAccessKey}:undefined})}}
async function copyRemoteUploads(staging,mode='s3'){
  const {bucket,client}=s3Client();
  const prefix=trimSlashes(process.env.S3_PREFIX||'journal-media');
  const target=path.join(staging,'uploads');
  const stats={mode,prefix,files:0,bytes:0,included:true};
  fs.mkdirSync(target,{recursive:true});
  let continuationToken;
  do{
    const page=await client.send(new ListObjectsV2Command({Bucket:bucket,Prefix:prefix?`${prefix}/`:undefined,ContinuationToken:continuationToken}));
    for(const object of page.Contents||[]){
      const key=String(object.Key||'');
      const relative=prefix&&key.startsWith(`${prefix}/`)?key.slice(prefix.length+1):key;
      if(!relative)continue;
      const parts=relative.split('/');
      if(parts.some(part=>part==='..'||part===''))throw new Error(`Unsafe S3 object key encountered during backup: ${key}`);
      const destination=path.resolve(target,relative);
      if(destination!==target&&!destination.startsWith(`${target}${path.sep}`))throw new Error('Unsafe S3 object key encountered during backup.');
      fs.mkdirSync(path.dirname(destination),{recursive:true});
      const response=await client.send(new GetObjectCommand({Bucket:bucket,Key:key}));
      if(!response.Body)throw new Error(`S3 object ${key} returned no body.`);
      await pipeline(response.Body,fs.createWriteStream(destination,{flags:'wx',mode:0o600}));
      stats.files++;
      stats.bytes+=Number(object.Size||fs.statSync(destination).size);
    }
    if(page.IsTruncated&&!page.NextContinuationToken)throw new Error('S3 object listing was truncated without a continuation token.');
    continuationToken=page.IsTruncated?page.NextContinuationToken:undefined;
  }while(continuationToken);
  return stats;
}
async function encryptTar(){const salt=crypto.randomBytes(16),iv=crypto.randomBytes(12),key=crypto.scryptSync(secret,salt,32),cipher=crypto.createCipheriv('aes-256-gcm',key,iv),magic=Buffer.from('PAJBAK1\0'),header=Buffer.concat([magic,salt,iv,Buffer.alloc(16)]),output=fs.createWriteStream(encrypted,{flags:'wx',mode:0o600});await new Promise((resolve,reject)=>output.write(header,error=>error?reject(error):resolve()));await pipeline(fs.createReadStream(plainTar),cipher,output);const tag=cipher.getAuthTag(),fd=fs.openSync(encrypted,'r+');try{fs.writeSync(fd,tag,0,tag.length,36)}finally{fs.closeSync(fd)}return sha256(encrypted)}
async function uploadRemote(files){const bucket=String(process.env.BACKUP_REMOTE_S3_BUCKET||'');if(!bucket)return {enabled:false};const accessKeyId=process.env.BACKUP_S3_ACCESS_KEY_ID||process.env.S3_ACCESS_KEY_ID,secretAccessKey=process.env.BACKUP_S3_SECRET_ACCESS_KEY||(process.env.BACKUP_S3_SECRET_ACCESS_KEY_FILE?fs.readFileSync(process.env.BACKUP_S3_SECRET_ACCESS_KEY_FILE,'utf8').trim():process.env.S3_SECRET_ACCESS_KEY||(process.env.S3_SECRET_ACCESS_KEY_FILE?fs.readFileSync(process.env.S3_SECRET_ACCESS_KEY_FILE,'utf8').trim():''));const client=new S3Client({region:process.env.BACKUP_S3_REGION||process.env.S3_REGION||'us-east-1',endpoint:process.env.BACKUP_S3_ENDPOINT||process.env.S3_ENDPOINT||undefined,forcePathStyle:String(process.env.BACKUP_S3_FORCE_PATH_STYLE||process.env.S3_FORCE_PATH_STYLE||'false')==='true',credentials:accessKeyId?{accessKeyId,secretAccessKey}:undefined}),prefix=String(process.env.BACKUP_REMOTE_S3_PREFIX||'encrypted-backups').replace(/^\/+|\/+$/g,'');for(const file of files){const key=[prefix,path.basename(file)].filter(Boolean).join('/');await new Upload({client,params:{Bucket:bucket,Key:key,Body:fs.createReadStream(file),ContentType:file.endsWith('.json')?'application/json':'application/octet-stream',ServerSideEncryption:process.env.BACKUP_S3_SERVER_SIDE_ENCRYPTION||'AES256'},queueSize:2,partSize:8*1024*1024,leavePartsOnError:false}).done()}return {enabled:true,bucket,prefix,files:files.length}}
function applyRetention(){const days=Math.max(1,Number(process.env.BACKUP_RETENTION_DAYS||30)),cutoff=Date.now()-days*86400000;for(const name of fs.readdirSync(root)){if(!/^pa-journal-.*\.tar\.gz\.enc(\.sha256|\.json)?$/.test(name))continue;const full=path.join(root,name);if(fs.statSync(full).mtimeMs<cutoff)fs.rmSync(full,{force:true})}}
(async()=>{try{const database=await createDatabaseBackup(),storageMode=String(process.env.STORAGE_BACKEND||process.env.OBJECT_STORAGE_DRIVER||'local').toLowerCase(),uploadsSource=path.resolve(process.env.UPLOAD_DIR||path.join(__dirname,'..','data','uploads'));let uploads={mode:storageMode,files:0,bytes:0,included:false};if(storageMode==='local'&&fs.existsSync(uploadsSource)){const target=path.join(staging,'uploads');fs.cpSync(uploadsSource,target,{recursive:true,errorOnExist:true});uploads={mode:'local',...treeStats(target),included:true}}else if(storageMode==='s3'||storageMode==='hybrid'){uploads=await copyRemoteUploads(staging,storageMode)}else if(storageMode!=='local')throw new Error(`Unsupported storage backend for full backup: ${storageMode}`);const includeSite=String(process.env.BACKUP_INCLUDE_SITE||'false').toLowerCase()==='true',site=includeSite?copySiteFiles(staging):{included:false,note:'Site files were not requested for this backup.'};const manifest={formatVersion:2,createdAt:new Date().toISOString(),service:'pa-journal',appVersion:require('../package.json').version,database,uploads,site,encryptedWith:'AES-256-GCM+scrypt'};fs.writeFileSync(path.join(staging,'manifest.json'),JSON.stringify(manifest,null,2),{mode:0o600});await exec('tar',['-C',staging,'-czf',plainTar,'.']);const encryptedSha=await encryptTar();const checksumFile=encrypted+'.sha256',metadataFile=encrypted+'.json';fs.writeFileSync(checksumFile,`${encryptedSha}  ${path.basename(encrypted)}\n`,{mode:0o600});fs.writeFileSync(metadataFile,JSON.stringify({...manifest,encryptedArchive:path.basename(encrypted),encryptedSha256:encryptedSha},null,2),{mode:0o600});const remote=await uploadRemote([encrypted,checksumFile,metadataFile]);applyRetention();console.log(JSON.stringify({event:'encrypted_backup_created',file:encrypted,sha256:encryptedSha,database:database.engine,uploads,remote},null,2))}finally{fs.rmSync(staging,{recursive:true,force:true});fs.rmSync(plainTar,{force:true})}})().catch(error=>{console.error(JSON.stringify({event:'encrypted_backup_failed',message:error.message}));process.exitCode=1});
