#!/usr/bin/env node
'use strict';
/*
 * Split the self-contained journal bundle into a small core plus route chunks.
 *
 * The journal app is intentionally kept as a generated browser bundle. This
 * post-build step extracts the tab-only React declarations into classic script
 * chunks and leaves the shared runtime plus dashboard in the core. Each route
 * chunk executes in a `with(runtime)` scope so the generated declarations can
 * continue to use the shared React/helpers without duplicating them.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const { parseModule } = require('meriyah');

const ROOT = path.join(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');
const APP_DIR = path.join(PUBLIC, 'app');
const MANIFEST_FILE = path.join(APP_DIR, 'chunks.json');

const routeNames = {
  history: [
    'SZ', 'OZ', 'jZ', 'ka', 'Si', 'Jp',
  ],
  calendar: [
    'paDayTradeMap', 'paSessionHeatmap', 'paCalendarCenter',
  ],
  import: [
    'paImportFields', 'paHeaderScore', 'paTableFromMatrix', 'paSplitReportSections',
    'paPickReportSection', 'paSectionHeader', 'paDealsLedger', 'paApplyDealCharges',
    'paMergeEntryCharges', 'paParseImportText', 'paGuessMap', 'paDirection',
    'paResultSign', 'paTradeSignature', 'paBuildImportedTrade', 'paImportCenter',
  ],
  risk: [
    'paClamp', 'paGroupPerformance', 'paSmartInsights', 'paRiskMeter', 'paRiskCenter',
  ],
  prop: [
    'paRuleCard', 'paPropFirmCenter',
  ],
  documents: [
    'paAnnotationBounds', 'paPointSegmentDistance', 'paFindAnnotationAt',
    'paTranslateAnnotation', 'paDrawAnnotation', 'paChartAnnotator', 'paCompareView',
    'paDocumentDrop', 'paTradeDocumentsCenter',
  ],
  pwa: [
    'paMobilePwaCenter',
  ],
  checklist: [
    'cZ',
  ],
  settings: [
    'PA_THEMES', 'paSetHero', 'paSetNav', 'paAccCard', 'paThemeCard', 'PZ',
  ],
  new: [
    'paSymbolSearchPicker', 'wZ',
  ],
};

const routeRoots = {
  history: 'paHistoryCenter',
  calendar: 'paCalendarCenter',
  import: 'paImportCenter',
  risk: 'paRiskCenter',
  prop: 'paPropFirmCenter',
  documents: 'paTradeDocumentsCenter',
  pwa: 'paMobilePwaCenter',
  checklist: 'cZ',
  settings: 'PZ',
  new: 'wZ',
};

const sha8 = value => crypto.createHash('sha256').update(value).digest('hex').slice(0, 8);
const banner = '/* SmartJournal — route chunk ساخته‌شده با scripts/split-journal-tabs.js. */\n';

function writeCompressed(file, body) {
  const buffer = Buffer.from(body, 'utf8');
  fs.writeFileSync(file, buffer);
  fs.writeFileSync(file + '.gz', zlib.gzipSync(buffer, { level: 9 }));
  fs.writeFileSync(file + '.br', zlib.brotliCompressSync(buffer, {
    params: {
      [zlib.constants.BROTLI_PARAM_QUALITY]: 10,
      [zlib.constants.BROTLI_PARAM_SIZE_HINT]: buffer.length,
    },
  }));
  return buffer;
}

function declaredNames(node) {
  if (node.type === 'FunctionDeclaration' || node.type === 'ClassDeclaration') return node.id ? [node.id.name] : [];
  if (node.type !== 'VariableDeclaration') return [];
  const names = [];
  for (const item of node.declarations) {
    if (item.id.type === 'Identifier') names.push(item.id.name);
  }
  return names;
}

function replaceFirst(source, needle, replacement) {
  const index = source.indexOf(needle);
  if (index < 0) throw new Error(`عبارت لازم پیدا نشد: ${needle.slice(0, 100)}`);
  return source.slice(0, index) + replacement + source.slice(index + needle.length);
}

function build() {
  const manifest = JSON.parse(fs.readFileSync(MANIFEST_FILE, 'utf8'));
  const currentAppPath = path.join(PUBLIC, manifest.app.replace(/^\//, ''));
  const appSource = fs.readFileSync(currentAppPath, 'utf8');
  const ast = parseModule(appSource, { ranges: true, next: true, module: true });
  const declarations = new Map();
  const allNodes = [];
  for (const node of ast.body) {
    const names = declaredNames(node);
    if (!names.length) continue;
    allNodes.push({ node, names });
    for (const name of names) {
      if (!declarations.has(name)) declarations.set(name, { node, names });
    }
  }

  const selected = new Map();
  for (const [route, names] of Object.entries(routeNames)) {
    for (const name of names) {
      const info = declarations.get(name);
      if (!info) throw new Error(`اعلان ${name} برای route ${route} پیدا نشد.`);
      const existing = selected.get(info.node.range[0]);
      if (existing && existing.route !== route) throw new Error(`اعلان مشترک بین routeها: ${name}`);
      selected.set(info.node.range[0], { ...info, route });
      if (info.names.some(item => !names.includes(item))) {
        throw new Error(`اعلان چندتایی ${name} شامل نام‌های دیگری است: ${info.names.join(', ')}`);
      }
    }
  }

  const historyBodyStart = appSource.indexOf('children: p ?');
  const historyNeedle = 'e === "history" ?';
  const historyStart = appSource.indexOf(historyNeedle, historyBodyStart);
  const historyEnd = appSource.indexOf(' : e === "calendar"', historyStart);
  if (historyBodyStart < 0 || historyStart < 0 || historyEnd < 0) throw new Error('شاخهٔ تاریخچه برای lazy load پیدا نشد.');
  let historyExpression = appSource.slice(historyStart + historyNeedle.length, historyEnd).trim();
  historyExpression = historyExpression.replace(/resultCount: wa\.length/g, 'resultCount')
    .replace(/totalCount: it\.length/g, 'totalCount')
    .replace(/hasAnyTrades: it\.length > 0/g, 'hasAnyTrades')
    .replace(/onOpenDocuments: tradeId => \{[\s\S]*?\n\s*\}\n\s*\}\)/, 'onOpenDocuments: onOpenDocuments\n        })');
  const historyWrapper = `function paHistoryCenter({ summary: mA, filters: Xe, setFilters: ya, resultCount, totalCount, filteredTrades: wa, totalTrades: it, onExport: cA, expandedId: O, setExpandedId: w, confirmDeleteId: S, setConfirmDeleteId: j, onDelete: sA, chartCache: $, loadChartImage: uA, chartLoadingId: K, onZoomImage: $e, onEdit: aA, hasAnyTrades, onOpenDocuments }) {\n  return ${historyExpression};\n}`;

  const routeBodies = {};
  for (const [route, names] of Object.entries(routeNames)) {
    const nodes = [...selected.values()]
      .filter(item => item.route === route)
      .sort((a, b) => a.node.range[0] - b.node.range[0]);
    let declarationsText = nodes.map(item => appSource.slice(item.node.range[0], item.node.range[1])).join('\n\n');
    if (route === 'history') declarationsText += `\n\n${historyWrapper}`;
    routeBodies[route] = `${banner}(function(){\n  var runtime = window.__PA_JOURNAL_RUNTIME__ || {};\n  var registry = window.__PA_JOURNAL_ROUTES__ || (window.__PA_JOURNAL_ROUTES__ = {});\n  with (runtime) {\n${declarationsText.split('\n').map(line => '    ' + line).join('\n')}\n    registry[${JSON.stringify(route)}] = ${routeRoots[route]};\n  }\n})();\n`;
  }

  const routeManifest = {};
  for (const [route, body] of Object.entries(routeBodies)) {
    const fileName = `journal-tab-${route}.${sha8(body)}.js`;
    const file = path.join(APP_DIR, fileName);
    writeCompressed(file, body);
    routeManifest[route] = `/app/${fileName}`;
  }

  const selectedRanges = [...selected.keys()].sort((a, b) => b - a);
  let core = appSource;
  for (const start of selectedRanges) {
    const item = selected.get(start);
    core = core.slice(0, item.node.range[0]) + '\n' + core.slice(item.node.range[1]);
  }

  const originalHistoryBranch = appSource.slice(historyStart, historyEnd);
  const historyReplacement = `e === "history" ? d.jsx(paLazyTab, { name: "history",
        summary: mA,
        filters: Xe,
        setFilters: ya,
        resultCount: wa.length,
        totalCount: it.length,
        filteredTrades: wa,
        totalTrades: it,
        onExport: cA,
        expandedId: O,
        setExpandedId: w,
        confirmDeleteId: S,
        setConfirmDeleteId: j,
        onDelete: sA,
        chartCache: $, 
        loadChartImage: uA,
        chartLoadingId: K,
        onZoomImage: $e,
        onEdit: aA,
        hasAnyTrades: it.length > 0,
        onOpenDocuments: tradeId => {
          setPaLinkedTradeId(tradeId), t("documents"), paLoadJournalTab("documents").then(() => setTimeout(() => {
            const target = document.querySelector(".pa-doc-trade-picker");
            target && target.scrollIntoView({ behavior: "smooth", block: "start" })
          }, 120))
        }
      })`;
  core = replaceFirst(core, originalHistoryBranch, historyReplacement);

  const routeCalls = {
    calendar: 'paCalendarCenter',
    import: 'paImportCenter',
    risk: 'paRiskCenter',
    prop: 'paPropFirmCenter',
    documents: 'paTradeDocumentsCenter',
    pwa: 'paMobilePwaCenter',
    checklist: 'cZ',
    settings: 'PZ',
    new: 'wZ',
  };
  for (const [route, component] of Object.entries(routeCalls)) {
    const source = `e === ${JSON.stringify(route)} ? d.jsx(${component}, {`;
    const replacement = `e === ${JSON.stringify(route)} ? d.jsx(paLazyTab, { name: ${JSON.stringify(route)},`;
    core = replaceFirst(core, source, replacement);
  }
  const docsHistoryOpen = `setPaLinkedTradeId(tradeId), ya({
            search: "",
            symbol: "all",
            result: "all",
            dateFrom: "",
            dateTo: ""
          }), w(tradeId), t("history"), setTimeout(() => {`;
  const docsHistoryOpenReplacement = `setPaLinkedTradeId(tradeId), ya({
            search: "",
            symbol: "all",
            result: "all",
            dateFrom: "",
            dateTo: ""
          }), w(tradeId), t("history"), paLoadJournalTab("history").then(() => setTimeout(() => {`;
  core = replaceFirst(core, docsHistoryOpen, docsHistoryOpenReplacement);
  core = replaceFirst(core, `          }, 140)
        }
      }) : e === "pwa"`, `          }, 140))
        }
      }) : e === "pwa"`);

  const marker = 'const paReminderBootTimer = setInterval(paCheckReminder, 6e4);';
  const originalMarkerIndex = appSource.indexOf(marker);
  const markerIndex = core.indexOf(marker);
  if (originalMarkerIndex < 0 || markerIndex < 0) throw new Error('نقطهٔ تزریق route loader پیدا نشد.');

  const runtimeNames = new Set();
  for (const item of allNodes) {
    if (item.node.range[1] <= originalMarkerIndex && !selected.has(item.node.range[0])) {
      item.names.forEach(name => runtimeNames.add(name));
    }
  }
  const runtimeEntries = [...runtimeNames].sort().join(',\n    ');
  const loader = `/* route-level code splitting */\nconst PA_JOURNAL_TABS = ${JSON.stringify(routeManifest)};\nwindow.__PA_JOURNAL_ROUTES__ = window.__PA_JOURNAL_ROUTES__ || {};\nconst paJournalTabLoads = window.__PA_JOURNAL_TAB_LOADS__ = window.__PA_JOURNAL_TAB_LOADS__ || {};\nfunction paLoadJournalTab(name) {\n  if (window.__PA_JOURNAL_ROUTES__[name]) return Promise.resolve(window.__PA_JOURNAL_ROUTES__[name]);\n  if (paJournalTabLoads[name]) return paJournalTabLoads[name];\n  const src = PA_JOURNAL_TABS[name];\n  if (!src) return Promise.reject(new Error('Unknown journal tab: ' + name));\n  paJournalTabLoads[name] = new Promise((resolve, reject) => {\n    const script = document.createElement('script');\n    script.src = src;\n    script.async = true;\n    script.onload = () => window.__PA_JOURNAL_ROUTES__[name] ? resolve(window.__PA_JOURNAL_ROUTES__[name]) : reject(new Error('Journal tab did not register: ' + name));\n    script.onerror = () => reject(new Error('Journal tab failed to load: ' + name));\n    document.head.appendChild(script);\n  });\n  return paJournalTabLoads[name];\n}\nfunction paLazyTab({ name, ...props }) {\n  const [Component, setComponent] = M.useState(() => window.__PA_JOURNAL_ROUTES__[name] || null);\n  M.useEffect(() => {\n    let alive = true;\n    const loaded = window.__PA_JOURNAL_ROUTES__[name];\n    if (loaded) { setComponent(() => loaded); return () => { alive = false; }; }\n    setComponent(null);\n    paLoadJournalTab(name).then(route => { if (alive) setComponent(() => route); }).catch(error => {\n      console.error('[SmartJournal] journal tab load failed', error);\n      if (alive) {\n        const retry = () => {\n          delete paJournalTabLoads[name];\n          setComponent(null);\n          paLoadJournalTab(name).then(route => { if (alive) setComponent(() => route); }).catch(() => {});\n        };\n        setComponent(() => function JournalTabError() { return d.jsx('button', { type: 'button', className: 'pa-route-error', onClick: retry, children: 'بارگذاری این بخش ناموفق بود؛ برای تلاش دوباره کلیک کن.' }); });\n      }\n    });\n    return () => { alive = false; };\n  }, [name]);\n  return Component ? d.jsx(Component, props) : d.jsx('div', { className: 'pa-route-loading', children: 'در حال آماده‌سازی این بخش…' });\n}\nwindow.__PA_JOURNAL_RUNTIME__ = {\n    ${runtimeEntries}\n  };\n`;
  core = core.slice(0, markerIndex) + loader + core.slice(markerIndex);

  const coreName = `journal-app.${sha8(core)}.js`;
  const coreFile = path.join(APP_DIR, coreName);
  writeCompressed(coreFile, core);

  const publicIndex = path.join(PUBLIC, 'index.html');
  let indexHtml = fs.readFileSync(publicIndex, 'utf8');
  indexHtml = indexHtml.replace(new RegExp(manifest.app.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), `/app/${coreName}`);
  fs.writeFileSync(publicIndex, indexHtml);

  const nextManifest = {
    ...manifest,
    app: `/app/${coreName}`,
    tabs: routeManifest,
    appBytes: Buffer.byteLength(core, 'utf8'),
    appBrotliBytes: fs.statSync(coreFile + '.br').size,
    tabBytes: Object.fromEntries(Object.entries(routeBodies).map(([route, body]) => [route, Buffer.byteLength(body, 'utf8')])),
  };
  fs.writeFileSync(MANIFEST_FILE, JSON.stringify(nextManifest, null, 2) + '\n');

  const keep = new Set([coreName, `${coreName}.gz`, `${coreName}.br`, manifest.auth.replace(/^\/app\//, '')]);
  for (const file of fs.readdirSync(APP_DIR)) {
    if (file === 'chunks.json' || keep.has(file)) continue;
    if (Object.values(routeManifest).some(url => {
      const name = url.replace(/^\/app\//, '');
      return file === name || file === name + '.gz' || file === name + '.br';
    })) continue;
    if (/^journal-(?:app|tab-[a-z0-9-]+)\.[0-9a-f]{8}\.js(?:\.gz|\.br)?$/.test(file)) fs.unlinkSync(path.join(APP_DIR, file));
  }

  console.log(`  · باندل اصلی ژورنال → ${nextManifest.app} (${(nextManifest.appBytes / 1024).toFixed(1)} KB)`);
  for (const [route, url] of Object.entries(routeManifest)) console.log(`  · تب ${route} → ${url} (${(nextManifest.tabBytes[route] / 1024).toFixed(1)} KB)`);
}

try { build(); console.log('✅ تقسیم باندل ژورنال انجام شد.'); }
catch (error) { console.error('❌ ' + (error.stack || error.message)); process.exit(1); }
