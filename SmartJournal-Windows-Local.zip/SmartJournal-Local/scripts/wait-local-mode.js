'use strict';

const http = require('node:http');

const port = Number(process.env.PORT || 3000);
const deadline = Date.now() + 120_000;
let retryTimer = null;

function retry() {
  if (Date.now() >= deadline) process.exit(1);
  if (retryTimer) return;
  retryTimer = setTimeout(() => {
    retryTimer = null;
    probe();
  }, 700);
}

function probe() {
  const request = http.get({
    hostname: '127.0.0.1',
    port,
    path: '/local-mode.js',
    timeout: 2_000,
  }, (response) => {
    let body = '';
    response.setEncoding('utf8');
    response.on('data', (chunk) => { body += chunk; });
    response.on('end', () => {
      if (response.statusCode === 200 && body.includes('PA_LOCAL_MODE=true')) {
        process.exit(0);
      }
      retry();
    });
  });

  request.on('timeout', () => request.destroy(new Error('Request timed out')));
  request.on('error', retry);
}

probe();
